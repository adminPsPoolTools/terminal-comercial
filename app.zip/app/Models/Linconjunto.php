<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Linconjunto extends Model
{
    use HasFactory;

    protected $table = "LINCONJUNTOS";

    public function articulo()
    {
        return $this->belongsTo(Articulo::class, "ARTICULO", "CODIGO");
    }

    public function eans()
    {
        return Ean::selectRaw("EAN, UDSVENTA, FECHA_ALTA_EAN AS FECHA")
                  ->where('ARTICULO', $this->ARTICULO)
                  ->get();
    }
}
