<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tarifa extends Model
{
    use HasFactory;

    protected $table = "TARIFAS";

    public function familias()
    {
        if ($this->TIPO <> 6 && $this->TIPO <> 7) return [];

        $result = [];

        $lintarifasF = LintarifaF::where("TARIFA", $this->CODIGO)->get();

        foreach ($lintarifasF as $lintarifa)
        {
            array_push($result, array(
                "codigo"    => $lintarifa->FAMILIA,
                "precio"    => ($this->TIPO == "6") ? round($lintarifa->CANTIDAD, 2) : null,
                "descuento" => ($this->TIPO == "7") ? round($lintarifa->CANTIDAD, 2) : null
            ));
        }

        return $result;
    }

    public function articulos()
    {
        if ($this->TIPO <> 5 && $this->TIPO <> 4) return [];

        $result = [];

        $lintarifas = Lintarifa::where("TARIFA", $this->CODIGO)->get();

        foreach ($lintarifas as $lintarifa)
        {
            $articulo = $lintarifa->articulo;
            array_push($result, array(
                "codigo"    => $articulo->CODIGO,
                "precio"    => ($this->TIPO == "5") ? round($lintarifa->CANTIDAD, 2) : null,
                "descuento" => ($this->TIPO == "4") ? round($lintarifa->CANTIDAD, 2) : null,
                "conjunto"  => $articulo->esConjunto()
            ));
        }

        return $result;
    }
}
