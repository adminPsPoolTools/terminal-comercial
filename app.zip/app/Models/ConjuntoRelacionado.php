<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConjuntoRelacionado extends Model
{
    use HasFactory;

    protected $table = "CONJUNTOS_RELACIONADOS";
}
