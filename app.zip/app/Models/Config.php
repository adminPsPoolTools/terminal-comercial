<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Config extends Model
{
    use HasFactory;

    protected $table = "CONFIGCENTRAL";

    public static function directorioImagenes()
    {
        return Config::first()->DIRECTORIOIMAGENES;
    }

    public static function obtenerAPIEnviarDatosWeb()
    {
        $proyecto = Proyectos::find(env('PROYECTO', 1));

        //dd($proyecto);

        return ($proyecto) ? ($proyecto->API_ENVIAR_DATOS_WEB == "S") : false;
    }
}
