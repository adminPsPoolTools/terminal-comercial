<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;


class ConjuntoArticulos extends Model
{
    use HasFactory;

    protected $table = "CONJUNTO_ARTICULOS";

    protected $primaryKey = 'CODIGO';

    public $lineas;

    public function linconjuntos()
    {
        $resLinconjuntos = Linconjunto::selectRaw("LINCONJUNTOS.MULTIPLICADOR1 AS MULTI1, LINCONJUNTOS.MULTIPLICADOR2 AS MULTI2, LINCONJUNTOS.MULTIPLICADOR3 AS MULTI3, 
                                                   LINCONJUNTOS.PREDETERMINADO, 

                                                   ARTICULOS.CODIGO AS ARTICULO, ARTICULOS.PRECIO, COALESCE(ARTICULOS.DESCATALOGADO, 'N') AS DESCATALOGADO, 
                                                   COALESCE(ARTICULOS.OCULTO, 'N') AS OCULTO, ARTICULOS.REFERENCIA_FABRICANTE, ARTICULOS.UNIDADESCAJA, ARTICULOS.PESO, 
                                                   ARTICULOS.MEDIDA, ARTICULOS.UDS_PACK, ARTICULOS.FAMILIA, 

                                                   SUM(P_STOCK.STOCK) AS STOCK, 
                                                   PROYECTO.BLOQUEADO, PROYECTO.PVP, PROYECTO.PVP_CAJA, PROYECTO.PVP_PACK, PROYECTO.PVP_RECOMENDADO, PROYECTO.PVP_MINIMO, 

                                                   IMPUESTOS.IVA AS IMPUESTO, CODIGOS_CATWEB, MARCAS.DESCRIPCION AS MARCA")
                                      ->leftJoin("ARTICULOS", "ARTICULOS.CODIGO", "LINCONJUNTOS.ARTICULO")
                                      ->leftJoin("EANS", "EANS.ARTICULO", "ARTICULOS.CODIGO")
                                      ->leftJoin("IMPUESTOS", "ARTICULOS.IMPUESTO", "IMPUESTOS.CODIGO")
                                      ->leftJoin("MARCAS", "MARCAS.CODIGO", "ARTICULOS.MARCA")
                                      ->leftJoin("PROYECTO as P_STOCK", function ($join){

                                            $join->on("LINCONJUNTOS.ARTICULO", "=", "P_STOCK.ARTICULO");
                                            $join->where(function ($join){

                                                $proyectos = explode(',', config("app.proyecto_stock", 1));
    
                                                foreach ($proyectos as $proyecto)
                                                {
                                                    $join->orWhere("P_STOCK.PROYECTO", "=", $proyecto);
                                                }

                                            });
                                      })
                                      ->leftJoin("PROYECTO", function ($join){
                                              $join->on("LINCONJUNTOS.ARTICULO", "=", "PROYECTO.ARTICULO")
                                                  ->where("PROYECTO.PROYECTO", "=", env("PROYECTO"));
                                      })
                                      ->leftJoin(DB::raw('CODIGOS_CATWEB_ARTICULO(PROYECTO.PROYECTO, LINCONJUNTOS.ARTICULO)'), "LINCONJUNTOS.PREDETERMINADO", DB::raw("'S'"))
                                      /* ->where(function($query){
                                              return $query->where("LINCONJUNTOS.PREDETERMINADO", "=", 'S');
                                                          //->orWhere("P_STOCK.STOCK", ">", "0");
                                      }) */
                                      ->where("CONJUNTO", $this->CODIGO);

        if (config('app.con_categoriasweb'))
        {
            $resLinconjuntos = $resLinconjuntos->leftJoin("CATEGORIASWEB_ARTICULO", "CATEGORIASWEB_ARTICULO.ARTICULO", "ARTICULOS.CODIGO")
                                               ->whereNotNull("CATEGORIASWEB_ARTICULO.ARTICULO");
        }

        if (!config('app.mostrar_bloqueados'))
        {
            $resLinconjuntos = $resLinconjuntos->whereRaw("PROYECTO.BLOQUEADO <> 'S'")
                                               ->whereRaw("P_STOCK.BLOQUEADO  <> 'S'");
        }

        //->toSQL()->dd();
        $resLinconjuntos = $resLinconjuntos->groupBy(
            "MULTI1", "MULTI2", "MULTI3", "LINCONJUNTOS.PREDETERMINADO", 
            "ARTICULO", "ARTICULOS.PRECIO", "DESCATALOGADO", "OCULTO", 
            "ARTICULOS.REFERENCIA_FABRICANTE", "ARTICULOS.UNIDADESCAJA", "ARTICULOS.PESO", "ARTICULOS.MEDIDA", "ARTICULOS.UDS_PACK", "ARTICULOS.FAMILIA",
            /* "P_STOCK.STOCK", */ "PROYECTO.BLOQUEADO", "PROYECTO.PVP", "PROYECTO.PVP_CAJA", "PROYECTO.PVP_PACK", "PROYECTO.PVP_RECOMENDADO", "PROYECTO.PVP_MINIMO", 
            "IMPUESTO", "CODIGOS_CATWEB", "MARCA", "LINCONJUNTOS.LINEA"
        );

        $resLinconjuntos = $resLinconjuntos->orderBy("LINCONJUNTOS.LINEA");

        Log::notice("SQL Lineas: ". $resLinconjuntos->toSql());

        $resLinconjuntos = $resLinconjuntos->get();

        return $resLinconjuntos;               
    }

    public function predeterminado()
    {
        $linconjunto = Linconjunto::where("CONJUNTO", $this->CODIGO)
                                  ->orderByDesc("PREDETERMINADO")
                                  ->first();

        return $linconjunto->articulo;
    }

    public function descripcionIngles(){

        $conjuntoIdioma = ConjuntoArticulosIdioma::where("CONJUNTO", $this->CODIGO)
                                                 ->where("IDIOMA", 1)  
                                                 ->first();

        return ($conjuntoIdioma) ? $conjuntoIdioma->TRADUCCION_DESCRIPCION : "";  
    }

    public function existeSlug()
    {
        if (!$this->SLUG) return false;

        $articulo = Articulo::leftJoin("LINCONJUNTOS", "LINCONJUNTOS.ARTICULO", "ARTICULOS.CODIGO")
                            ->where("LINCONJUNTOS.CONJUNTO", $this->CODIGO)
                            ->first();

        return !empty($articulo->SLUG); 
    }

    public function productosRelacionados()
    {
        $result = array();

        $conjuntosRelacionados = ConjuntoRelacionado::where("CONJUNTO", $this->CODIGO)->get();

        foreach ($conjuntosRelacionados as $conjunto) array_push($result, (string) $conjunto->CONJUNTO_RELACIONADO);

        $articulosRelacionados = ConjuntoArticuloRelacion::where("CONJUNTO", $this->CODIGO)->get();

        foreach ($articulosRelacionados as $articulo) array_push($result, $articulo->ARTICULO_RELACIONAR);

        return $result;
    }

    public function articulosRelacionados()
    {
        $result = array();

        $articulosRelacionados = ConjuntoArticuloRelacion::where("CONJUNTO", $this->CODIGO)->get();

        foreach ($articulosRelacionados as $articulo) array_push($result, $articulo->ARTICULO_RELACIONAR);

        return $result;
    }

    public function conjuntosRelacionados()
    {
        $result = array();

        $conjuntosRelacionados = ConjuntoRelacionado::where("CONJUNTO", $this->CODIGO)->get();

        foreach ($conjuntosRelacionados as $conjunto) array_push($result, (string) $conjunto->CONJUNTO_RELACIONADO);

        return $result;
    }
}
