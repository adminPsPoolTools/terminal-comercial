<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EstadoAgendaPSPOOL extends Model
{
    protected $table = "ESTADOS_AGENDA";
    protected $primaryKey = 'CODIGO';
    use HasFactory;

    public function agendas()
    {
        return $this->hasMany(AgendaPSPOOL::class, 'ESTADO');
    }
}
