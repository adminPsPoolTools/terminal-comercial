<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use Illuminate\Support\Facades\DB;

class Cliente extends Model
{
    use HasFactory;

    protected $table = "CLIENTES";

    public function direcciones()
    {
        return DireccionCliente::selectRaw("LINEA, NOMBRE, CONTACTO, CIF, DIRECCION, CP, POBLACION AS LOCALIDAD, PROVINCIA, PAIS_DIRECCIONES_CLIENTES AS PAIS, 
                                            TELEFONOFIJO AS TELEFONO, TELEFONOMOVIL AS TELEFONO_MOVIL")
                               ->where("CLIENTE", $this->CODIGO)
                               ->get();

        //return $this->hasMany(DireccionCliente::class, "CLIENTE", "CODIGO");
    }

    public function riesgo()
    {
        //return round(DB::select('SELECT RIESGO_DISPONIBLE FROM CALCULAR_RIESGO('.$this->CODIGO.', \''.date("m-d-Y").'\')')[0]->RIESGO_DISPONIBLE); 

        //Revisamos si tiene registros en los riesgos por razon social.
        $reg_riesgos = DB::select('SELECT COUNT(CLIENTE) AS N_REG FROM CLIENTES_RAZON_SOCIAL WHERE CLIENTE = ?', [$this->CODIGO]);

        //Si tiene algun registro por razon social vamos al nuevo procedure que calcula el riesgo de la razon social 1 ps pool para la web
        if ($reg_riesgos[0]->N_REG > 0) {
            return round(DB::select('SELECT RIESGO_DISPONIBLE FROM CALCULAR_RIESGO_RAZON(' . 1 . ', \'' . $this->CODIGO . '\', \'' . date("m-d-Y") . '\')')[0]->RIESGO_DISPONIBLE);
        } else {
            return round(DB::select('SELECT RIESGO_DISPONIBLE FROM CALCULAR_RIESGO(' . $this->CODIGO . ', \'' . date("m-d-Y") . '\')')[0]->RIESGO_DISPONIBLE);
        }
    }

    public function tarifas()
    {
        $tarifas = array();

        if (!empty($this->TARIFA)) array_push($tarifas, $this->TARIFA);

        $tarifasCliente = TarifaCliente::select("TARIFA")->where("CLIENTE", $this->CODIGO)->orderBy("LINEA", "ASC")->get();

        foreach ($tarifasCliente as $tarifa) array_push($tarifas, $tarifa->TARIFA);

        return $tarifas;

        //return $this->hasMany(TarifaCliente::class, "CLIENTE", "CODIGO");
    }

    public function obtenerContacto()
    {
        //PRIMERO MIRO EN LOS CONTACTOS ASOCIADOS AL CLIENTE, SI NO HAY NINGUNO DEVUELVO EL CONTACTO WEB
        $contacto = ClienteContacto::where("CLIENTE", $this->CODIGO)->first();

        return ($contacto) ? utf8_encode($contacto->NOMBRE) : "Contacto WEB";
    }
}
