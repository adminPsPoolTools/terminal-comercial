<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Albaran extends Model
{
    use HasFactory;

    protected $table = "TIQUETS";

    public $timestamps   = false;    
    public $incrementing = false;

    protected $primaryKey = 'CODIGO';

    public function urlTracking()
    {
        $agencia = AgenciaTransporte::where("CODIGO", $this->AGENCIA)->first();

        return ($agencia) ? $agencia->LINK_SEGUIMIENTO : "";
    }
}
