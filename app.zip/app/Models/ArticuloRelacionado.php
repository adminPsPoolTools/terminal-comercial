<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ArticuloRelacionado extends Model
{
    use HasFactory;

    protected $table = "ARTICULOS_RELACIONADOS";
}
