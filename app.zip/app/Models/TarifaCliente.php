<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TarifaCliente extends Model
{
    use HasFactory;

    protected $table = "TARIFASCLIENTES";
}
