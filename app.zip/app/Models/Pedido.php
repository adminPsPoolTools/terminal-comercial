<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pedido extends Model
{
    use HasFactory;

    protected $table = "PEDCLI";

    public $timestamps   = false;    
    public $incrementing = false;

    protected $primaryKey = "CODIGO";

    protected $fillable = ["CODIGO", "CLIENTE", "FECHA", "TITULO", "LINEADIRECCIONENVIO", "PROYECTO","COMENTARIO_ENVIO"];

    public function getmaxLineaAttribute()
    {
        $linpedcli = Linpedcli::where("PEDIDO", $this->CODIGO)->orderByDesc("LINEA")->first();

        //dd($linpedcli);
        
        return ($linpedcli) ? $linpedcli->LINEA : 0;
    }

    public function obtenerTrackings()
    {
        $result = [];

        //VOY A BUSCAR LOS TRACKING DEL PEDIDO
        //$albaranes = $this->albaranes;
        $albaranes = Albaran::where('PEDIDO', $this->CODIGO)->get();

        foreach ($albaranes as $albaran)
        {
            array_push($result, array(
                "NUMERO_EXPEDICION" => $albaran->NEXPEDICION,
                "URL_SEGUIMIENTO" => $albaran->urlTracking() . $albaran->NEXPEDICION
            ));
        }

        return $result;
    }

    public function cliente()
    {
        return $this->hasOne(User::class, 'CODIGO', 'CLIENTE');
    }

    /* public function albaranes()
    {
        return $this->hasMany(Albaran::class, 'PEDIDO', 'CODIGO');
    } */
}
