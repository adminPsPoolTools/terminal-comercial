<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConjuntoArticuloRelacion extends Model
{
    use HasFactory;

    protected $table = "CONJUNTO_ARTICULO_RELACION";
}
