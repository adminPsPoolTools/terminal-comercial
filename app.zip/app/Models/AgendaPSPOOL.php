<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AgendaPSPOOL extends Model
{
    protected $table = "AGENDA";
    protected $primaryKey = 'CODIGO';
    
    use HasFactory;

    public function usuario()
    {
        return $this->belongsTo(UsuarioPSPOOL::class, 'USUARIO', 'CODIGO');
    }

    public function estado()
    {
        return $this->belongsTo(EstadoAgendaPSPOOL::class, 'ESTADO');
    }

    public function usuarioOrigen()
    {
        return $this->belongsTo(UsuarioPSPOOL::class, 'USUARIO_ORIGEN');
    }
}
