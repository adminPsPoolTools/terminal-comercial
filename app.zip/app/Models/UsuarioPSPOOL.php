<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UsuarioPSPOOL extends Model
{
    protected $table = "USUARIOS";
    protected $primaryKey = 'CODIGO';
    use HasFactory;

    public function agenda()
    {
        return $this->hasOne(AgendaPSPOOL::class, 'USUARIO');
    }
}
