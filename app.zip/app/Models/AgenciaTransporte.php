<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AgenciaTransporte extends Model
{
    use HasFactory;

    protected $table = "AGENCIAT";
}
