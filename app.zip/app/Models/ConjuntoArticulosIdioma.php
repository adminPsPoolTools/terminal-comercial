<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConjuntoArticulosIdioma extends Model
{
    use HasFactory;

    protected $table = "CONJUNTO_ARTICULOS_IDIOMAS";
}
