<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DireccionCliente extends Model
{
    use HasFactory;

    protected $table = "DIRECCIONESCLIENTES";

    public $timestamps = false;  
    public $incrementing = false;

    protected $fillable = ["CLIENTE", "LINEA", "DIRECCION", "POBLACION", "CP", "PROVINCIA", "TELEFONOFIJO", "TELEFONOMOVIL", "NOMBRE", "PAIS_DIRECCIONES_CLIENTES"];
   

    static function siguienteLinea($cliente)
    {
        $dirLinea = DireccionCliente::select("LINEA")->where("CLIENTE", $cliente)->orderByDesc("LINEA")->first();

        return ($dirLinea) ? ($dirLinea->LINEA + 1) : 1;
    }
}
