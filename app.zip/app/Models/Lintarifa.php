<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Lintarifa extends Model
{
    use HasFactory;

    protected $table = "LINTARIFAS";

    public function articulo()
    {
        return $this->belongsTo(Articulo::class, "ARTICULO", "CODIGO");
    }
}
