<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class Articulo extends Model
{
    use HasFactory;

    protected $table = "ARTICULOS";

    protected $primaryKey = 'CODIGO';

    /* public function proyecto(){
        return $this->hasOne(Proyecto::class, "");
    } */

    public function stock()
    {
        $stock = 0;

        $proyectos = explode(',', config('app.proyectos_stock', 1));

        foreach ($proyectos as $proyecto)
        {
            $p = Proyecto::where('PROYECTO', $proyecto)
                         ->where('ARTICULO', $this->CODIGO)
                         ->first();

            $stock += ($p) ? $p->STOCK : 0;
        }

        return $stock;
    }

    public function stockVendible()
    {
        $coleccion = $this->coleccion();
        
        //SI LA COLECCION ESTÁ BLOQUEADA DEVUELVO EL STOCK A 0
        if (!$coleccion || $coleccion->BLOQUEADO_API == 'S') return 0;

        $stock = 0;

        $proyectos = explode(',', config('app.proyecto_stock', 1));

        foreach ($proyectos as $proyecto)
        {
            $sql = 'SELECT STOCK_VENDIBLE FROM CALCULAR_STOCK_VENDIBLE_ARTI('.$proyecto.','.$this->CODIGO.')';

            $stock += round(DB::select($sql)[0]->STOCK_VENDIBLE);
        }

        return $stock; 
    }

    public function descripcionIngles()
    {
        $articuloIdioma = ArticuloIdioma::where("ARTICULO", $this->CODIGO)
                                        ->where("IDIOMA", 1)
                                        ->first();

        return ($articuloIdioma) ? $articuloIdioma->TRADUCCION_DESCRIPCION : "";
    }

    public function eans()
    {
        return Ean::selectRaw("EAN, UDSVENTA, FECHA_ALTA_EAN AS FECHA")
                  ->where('ARTICULO', $this->CODIGO)
                  ->get();
    }

    public function marca()
    {
        $marca = Marca::select('DESCRIPCION')
                      ->where("CODIGO", $this->MARCA)
                      ->first();

        return ($marca) ? $marca->DESCRIPCION : "";
    }

    public function coleccion()
    {
        if(empty($this->COLECCION) || empty($this->marca())) return null;

        return Coleccion::where("COLECCION", $this->COLECCION)
                        ->where("MARCA", $this->marca())
                        ->first();
    }

    public function imagenes()
    {
        $result = array();
    
        $DIRECTORIO_IMAGENES = Config::directorioImagenes(); 
    
        $carpetaImagenes = $DIRECTORIO_IMAGENES."carpeta_articulos\\".$this->CODIGO."\\fotos\\";
        //die($carpetaImagenes);
    
        if(file_exists($carpetaImagenes))
        {
            $dirImagenes = scandir($carpetaImagenes, SCANDIR_SORT_DESCENDING);
    
            foreach ($dirImagenes as $img)
            {
                if ($img != '.' && $img != '..' && $img != 'Thumbs.db' && !is_dir($img))
                {
                    $extension = pathinfo($carpetaImagenes.$img, PATHINFO_EXTENSION);
    
                    if($extension == "jpg" || $extension == "png" || $extension == "jpeg")
                    {
                        //echo $carpetaImagenes.$img;
                        $filename  = pathinfo($carpetaImagenes.$img, PATHINFO_FILENAME);
                        $extension = pathinfo($carpetaImagenes.$img, PATHINFO_EXTENSION);

                        array_push($result, $this->obtenerURLBase() . $filename.config('app.url_imagenes_extra') .'.'. $extension);
                    }        
                }
            }
        }
    
        return $result;
    }

    public function obtenerURLBase()
    {
        $result = config('app.url_imagenes');
        $result = str_replace(':id_articulo', $this->CODIGO, $result);

        return $result;
    }

    public function bloqueado()
    {
        $proyect = explode(',', config("app.proyecto_stock", 1));

        $proyecto = Proyecto::where("ARTICULO", $this->CODIGO)
                            ->where("PROYECTO", $proyect)
                            ->first();
                            
        return $proyecto ? ($proyecto->BLOQUEADO == 'S') : false;
    }

    public function esConjunto()
    {
        $res = Linconjunto::where('ARTICULO', $this->CODIGO)->first();

        return $res <> null;
    }

    public function disponibilidad()
    {
        $proyecto = explode(',', config('app.proyecto_pedidos', 1))[0];

        $res = DB::select("SELECT DISPONIBILIDAD, PROVEEDOR, FECHA_REFERENCIA, MINIMO_DIAS_DISPONIBILIDAD, FECHA_PROXIMA_DISPONIBILIDAD, STOCK_DISPONIBLE, NO_CONTROLAR_STOCK 
                             FROM DISPONIBILIDAD_ARTICULO(".$proyecto.", '".$this->CODIGO."', 1)");
        //dd($res);
        return $res[0];
    }

    public function proximoStockDisponible($stock = null)
    {
        $stock = (($stock) ? $stock : $this->stockVendible()) + 1;

        $proyecto = explode(',', config('app.proyecto_pedidos', 1))[0];

        return DB::select("SELECT FECHA_DISPONIBILIDAD, STOCK_DISPONIBLE
                             FROM DISPONIBILIDAD_FECHA_PROXIMA(".$proyecto.", ".$this->CODIGO.", 1, ".$stock.")")[0];
    }

    public function fechaProximaDisponibilidadProveedor()
    {
        $semanasProveedor = (!empty($this->proveedor->LIBRE5_PROVEEDOR)) ? $this->proveedor->LIBRE5_PROVEEDOR : 0;
                
        $fechaProximaDisp = new \DateTime();
        $fechaProximaDisp->modify("+ ".$semanasProveedor." weeks");

        return $fechaProximaDisp->format('d-m-Y');
    }

    public function productosRelacionados()
    {
        $result = array();

        $articulosRelacionados = ArticuloRelacionado::where("ARTICULO", $this->CODIGO)->get();

        foreach ($articulosRelacionados as $articulo) array_push($result, $articulo->ARTICULO_RELACIONADO);

        $conjuntosRelacionados = ArticuloConjuntoRelacion::where("ARTICULO", $this->CODIGO)->get();

        foreach ($conjuntosRelacionados as $conjunto) array_push($result, (string) $conjunto->CONJUNTO_RELACIONAR);

        return $result;
    }

    public function articulosRelacionados()
    {
        $result = array();

        $articulosRelacionados = ArticuloRelacionado::where("ARTICULO", $this->CODIGO)->get();

        foreach ($articulosRelacionados as $articulo) array_push($result, $articulo->ARTICULO_RELACIONADO);

        return $result;
    }

    public function conjuntosRelacionados()
    {
        $result = array();

        $conjuntosRelacionados = ArticuloConjuntoRelacion::where("ARTICULO", $this->CODIGO)->get();

        foreach ($conjuntosRelacionados as $conjunto) array_push($result, (string) $conjunto->CONJUNTO_RELACIONAR);

        return $result;
    }

    public function proveedor()
    {
        return $this->belongsTo(Proveedor::class, 'PROVEEDOR', 'CODIGO');
    }
}
