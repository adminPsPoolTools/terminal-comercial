<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

use App\Models\Articulo;
use App\Models\Cliente;
use App\Models\Categoria;
use App\Models\ConjuntoArticulos;
use App\Models\DireccionCliente;
use App\Models\EstadoPedido;
use App\Models\Linconjunto;
use App\Models\Pedido;
use App\Models\Tarifa;

use App\Observers\ArticuloObserver;
use App\Observers\CategoriaObserver;
use App\Observers\ClienteObserver;
use App\Observers\ConjuntoArticuloObserver;
use App\Observers\DireccionClienteObserver;
use App\Observers\EstadoPedidoObserver;
use App\Observers\LinconjuntoObserver;
use App\Observers\PedidoObserver;
use App\Observers\TarifaObserver;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Articulo::observe(ArticuloObserver::class);
        Categoria::observe(CategoriaObserver::class);
        Cliente::observe(ClienteObserver::class);
        ConjuntoArticulos::observe(ConjuntoArticuloObserver::class);
        DireccionCliente::observe(DireccionClienteObserver::class);
        EstadoPedido::observe(EstadoPedidoObserver::class);
        Pedido::observe(PedidoObserver::class);
        Linconjunto::observe(LinconjuntoObserver::class);
        Tarifa::observe(TarifaObserver::class);

        ini_set('max_execution_time', -1);
    }
}
