<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Carbon;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The path to the "home" route for your application.
     *
     * This is used by Laravel authentication to redirect users after login.
     *
     * @var string
     */
    public const HOME = '/home';

    /**
     * Define your route model bindings, pattern filters, etc.
     *
     * @return void
     */
    public function boot()
    {
        $this->configureRateLimiting();

        $this->routes(function () {
            Route::middleware('web')
                ->group(base_path('routes/web.php'));

            Route::prefix('api')
                ->middleware('api')
                ->group(base_path('routes/api.php'));
        });
    }

    /**
     * Configure the rate limiters for the application.
     *
     * @return void
     */
    protected function configureRateLimiting()
    {
        RateLimiter::for('api', function (Request $request) {
            //VOY A LIMITAR EL OBTENER CATALOGO
            if($request->path() == 'api/catalogo')
            {
                if ($request->has('sku') && !empty($request->query('sku')))
                {
                    return Limit::perMinute(60)->by($request->ip());        
                }

                if ($request->has('fechahora') && strtotime($request->query('fechahora')) >= strtotime("-2 days"))
                {
                    return Limit::perHour(0.5)->by($request->ip());        
                }

                //return Limit::perDay(1)->by($request->ip());
            }

            //return Limit::perMinute(60)->by($request->ip());
            //return Limit::perHour(60)->by($request->ip());
        });
    }
}
