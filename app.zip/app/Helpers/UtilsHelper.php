<?php

namespace App\Helpers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

use App\Models\Articulo;
use App\Models\ConjuntoArticulos;
use App\Models\Linconjunto;
use App\Models\Config;

use Illuminate\Support\Facades\Storage;

class UtilsHelper
{
    public static function verificarURL($url)
    {
        $headers = @get_headers($url);

        return ($headers && strpos($headers[0], '404') !== false);
    }


    public static function utf8ize($dat)
    {
        if (is_string($dat)) {
            /* if (mb_detect_encoding($dat, 'Windows-1252', true)) {
                $res = mb_convert_encoding($dat, 'UTF-8', 'Windows-1252');
                return $res;
            } */
            //$dat = str_replace('Ã±', 'ñ', $dat);

            /* if (mb_detect_encoding($dat, 'ISO-8859-15', true)) {
                $res = mb_convert_encoding($dat, 'UTF-8', 'ISO-8859-15');
                return $res;
            }

            else if (mb_detect_encoding($dat, 'ISO-8859-1', true)) {
                $res = mb_convert_encoding($dat, 'UTF-8', 'ISO-8859-1');
                return $res;
            }

            else if (!mb_detect_encoding($dat, 'UTF-8', true)) {
                $res = mb_convert_encoding($dat, 'UTF-8');
                return $res;
            } */

            $dat = Encoding::toUTF8($dat);
            $dat = str_replace('¤', '€', $dat);

            return $dat;
        } elseif (is_array($dat)) {
            $ret = [];
            foreach ($dat as $i => $d) $ret[$i] = self::utf8ize($d);
            return $ret;
        } elseif (is_object($dat)) {
            foreach ($dat as $i => $d) $dat->$i = self::utf8ize($d);
            return $dat;
        } else {
            return $dat;
        }
    }



    public static function isoize($dat)
    {
        if (is_string($dat)) {
            //Transformar euros

            //$dat = str_replace("€", "eur", $dat);
            /* if (mb_detect_encoding($dat, 'Windows-1252', true)) {
                $res = mb_convert_encoding($dat, 'ISO-8859-15', 'Windows-1252');
                return $res;
            } */
            /* if (mb_detect_encoding($dat, 'ISO-8859-15', true)) return $dat; */

            if (mb_detect_encoding($dat, 'UTF-8', true)) {
                $res = mb_convert_encoding($dat, 'ISO-8859-15', 'UTF-8');
                return $res;
            } else if (mb_detect_encoding($dat, 'ISO-8859-1', true)) {
                $res = mb_convert_encoding($dat, 'ISO-8859-15', 'ISO-8859-1');
                return $res;
            }

            return $dat;
        } elseif (is_array($dat)) {
            $ret = [];
            foreach ($dat as $i => $d) $ret[$i] = self::isoize($d);
            return $ret;
        } elseif (is_object($dat)) {
            foreach ($dat as $i => $d) $dat->$i = self::isoize($d);
            return $dat;
        } else {
            return $dat;
        }
    }

    //formatear una fecha en formato m/d/y a y/m/d
    public static function formatearFechaDesdeFB($fecha)
    {
        $fechaFormateada = $fecha;
        if (strpos($fecha, '/') != false) {
            $arrayFecha = explode("/", $fecha);
            $fechaFormateada = "$arrayFecha[2]-$arrayFecha[0]-$arrayFecha[1]";
        }

        return $fechaFormateada;
    }

    //formatear una fecha en formato y/m/d a m/d/y
    public static function formatearFechaAFB($fecha)
    {
        $fechaFormateada = $fecha;
        if (strpos($fecha, '-') != false) {
            $arrayFecha = explode("-", $fecha);
            $fechaFormateada = "$arrayFecha[1]/$arrayFecha[2]/$arrayFecha[0]";
        }

        return $fechaFormateada;
    }



    public static function buscarArticulo($codigo, $proyecto)
    {
        $articulo = Articulo::find($codigo);

        if ($articulo) return $articulo; //SI HE ENCONTRADO EL ARTÍCULO LO DEVUELVO Y YA ESTA

        //SI NO PUEDE SER UN CONJUNTO
        $conjunto = ConjuntoArticulos::find($codigo);

        if (!$conjunto) return null; //SI TAMPOCO ENCUENTRA EL CONJUNTO DEVUELVO NULL

        $compraConjunta = $conjunto->COMPRA_CONJUNTA;


        if ($compraConjunta) //SI ES COMPRA CONJUNTA DEVUELVO EL QUE MAS STOCK TIENE
        {
            $linconjunto = Linconjunto::where("LINCONJUNTOS.CONJUNTO", $conjunto->CODIGO);

            $proyectos = explode(",", $proyecto); //$proyecto puede ser un array de proyectos

            $orderBy = "";

            foreach ($proyectos as $proyecto) {
                $linconjunto = $linconjunto->leftJoin(DB::raw("CALCULAR_STOCK_VENDIBLE_ARTI($proyecto, LINCONJUNTOS.ARTICULO) AS CSVA_$proyecto"), function ($join) {
                    $join->on(DB::raw('0'), '=', DB::raw('0')); // Esto depende de la lógica de tu unión
                });

                if (empty($orderBy)) $orderBy  = "   CSVA_$proyecto.STOCK_VENDIBLE";
                else                 $orderBy .= " + CSVA_$proyecto.STOCK_VENDIBLE";
            }

            $linconjunto = $linconjunto->orderByDesc($orderBy)
                ->first();

            if ($linconjunto) $articulo = $linconjunto->articulo;

            //dump($linconjunto);
        } else // SI NO DEVUELVO EL POR DEFECTO
        {
            $articulo = $conjunto->predeterminado();
        }

        return $articulo;
    }

    public static function removeAccents($string)
    {
        return strtr(utf8_decode($string), utf8_decode('áéíóúÁÉÍÓÚ'), 'aeiouAEIOU');
    }

    public static function removeAccentsv2($string)
    {
        return strtr($string, mb_convert_encoding('àáâãäçèéêëìíîïñòóôõöùúûüýÿÀÁÂÃÄÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝ²º€', 'ISO-8859-15'), 'aaaaaceeeeiiiinooooouuuuyyAAAAACEEEEIIIINOOOOOUUUUY2gE');
    }

    public static function webUrl($slug, $codigo = "")
    {
        $url = str_replace(':id_articulo', $codigo, utf8_encode(config("app.web_url") . $slug)) . config('app.web_url_extra');

        return $url;
    }

    public static function obtenerListaArchivosCarpeta($ruta)
    {
        $res = [];
        $dirs = [];

        //Primero borro las carpetas de los archivos que sean mas antiguos de x dias
        //cojo la primera carpeta de $ruta
        $base = explode('/', $ruta)[0];

        $dirs = scandir("storage/$base");
        foreach ($dirs as $dir) {
            if ($dir == "." || $dir == "..") continue;

            //Obtener la fecha de modificacion del directorio
            $fechaModificacion = filemtime("storage/$base/$dir");

            //Si la fecha de modificacion es mas antigua que 7 dias, lo borro
            if (time() - $fechaModificacion > config('app.dias_archivos') * 24 * 60 * 60) {
                Log::info("Borrando carpeta antigua: " . "storage/$base/$dir");
                File::cleanDirectory("storage/$base/$dir");
            }
        }

        //Ahora tengo que mover los archivos de la carpeta de $ruta a la de storage
        $directorioCarpetaCompartida = Config::directorioImagenes();

        if (!is_dir("storage/$ruta")) mkdir("storage/$ruta", 0775, true);

        //ANTES DE COPIAR LOS ARCHIVOS BORRO TODOS LOS QUE HUBIESE DE ANTES
        if (File::exists($ruta)) {
            Log::info("Limpiando archivos de la ruta $ruta");
            File::cleanDirectory($ruta);
        }

        UtilsHelper::copiarArchivos($directorioCarpetaCompartida, $ruta);

        //obtener lista de archivos almacenados en la ruta recibida
        if (Storage::disk('public')->exists($ruta)) {
            $files = Storage::disk('public')->allFiles($ruta);

            //Log::info(print_r($files, true));

            foreach ($files as $file) {
                //obtener nombre del archivo, sin ruta
                /* $arrayRutaArchivoDividida = explode('/', $file);
                $res[] = end($arrayRutaArchivoDividida); */
                $res[] = $file;
            }
        }

        return $res;
    }

    public static function copiarArchivos($directorioCarpetaCompartida, $ruta)
    {
        Log::info('DirectorioCarpCompartida ' . $directorioCarpetaCompartida);
        Log::info('Ruta ' . $ruta);

        if (!file_exists($directorioCarpetaCompartida . $ruta)) return;

        $dirs = scandir($directorioCarpetaCompartida . $ruta);

        foreach ($dirs as $dir) {
            if ($dir == "." || $dir == "..") continue;

            //Log::info("File: " . $directorioCarpetaCompartida.$ruta."/".$dir);

            if (is_dir($directorioCarpetaCompartida . $ruta . "/" . $dir)) {
                //Log::info("Dir: " . $dir);

                if (!file_exists("storage/$ruta/$dir")) mkdir("storage/$ruta/$dir");

                UtilsHelper::copiarArchivos($directorioCarpetaCompartida, $ruta . '/' . $dir);
            } else {
                if (!file_exists("storage/$ruta/$dir")) copy("$directorioCarpetaCompartida$ruta/" . $dir, "storage/$ruta/$dir");
            }
        }
    }

    public static function obtenerURLAsset($ruta)
    {
        //return url(Config::directorioImagenes().$ruta);
        $url = url('storage/' . $ruta);
        return $url;
    }

    public static function archivoEsImagen($archivo)
    {
        $imageExtensions = ['jpg', 'jpeg', 'gif', 'png', 'bmp', 'svg', 'svgz', 'cgm', 'djv', 'djvu', 'ico', 'ief', 'jpe', 'pbm', 'pgm', 'pnm', 'ppm', 'ras', 'rgb', 'tif', 'tiff', 'wbmp', 'xbm', 'xpm', 'xwd', 'pdf'];

        $explodeImage = explode('.', $archivo);
        $extension    = end($explodeImage);

        return (in_array($extension, $imageExtensions));
    }
}
