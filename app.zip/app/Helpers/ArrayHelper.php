<?php

namespace App\Helpers;

class ArrayHelper
{
    public static function filtrar($array, $arrayCampos)
    {
        $result = array();

        // Iterar sobre el array asociativo original
        foreach ($array as $elemento) {
            $nuevoElemento = [];
    
            foreach ($arrayCampos as $campo) {
                if (array_key_exists($campo, $elemento)) {
                    $nuevoElemento[$campo] = $elemento[$campo];
                }
            }
    
            if (!empty($nuevoElemento)) {
                array_push($result, $nuevoElemento);
                //$result[] = $nuevoElemento;
            }
        }

        return $result;
    }

    public static function pasarAArrayNumerico($array)
    {
        $result = [];

        foreach ($array as $item) {
            $values = array_values($item);
            $result[] = $values[0];
        }

        return $result;
    }
}