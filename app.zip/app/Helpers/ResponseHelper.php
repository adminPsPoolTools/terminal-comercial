<?php

namespace App\Helpers;

class ResponseHelper
{
    public static function error($msg = "", $status_code = 200)
    {
        $response = array(
            "error" => true,
            "message" => $msg
        );

        //dd($response);

        return response(json_encode($response), $status_code)
                ->header('Content-Type', 'application/json');
    }

    public static function send($arrayResponse, $extraString = ""){

        $response = array(
            "error" => false
        );

        if (!empty($extraString)) $response["info"] = $extraString;

        $response = array_merge($response, $arrayResponse);
        $response = json_encode($response);
        $response = preg_replace('/[[:^print:]]/', '', $response);

        /* print_r($response);
        dd(); */

        return response($response, 200)
                ->header('Content-Type', 'application/json');
    }
}