<?php

namespace App\Observers;

use app\Models\Tarifa;

class TarifaObserver
{
    /**
     * Handle the Tarifa "created" event.
     *
     * @param  \App\Models\Tarifa  $Tarifa
     * @return void
     */
    public function created(Tarifa $Tarifa)
    {
        /* dd($Tarifa);
        if($Tarifa->Tarifa) $Tarifa->Tarifa = round($Tarifa->Tarifa);

        return $Tarifa; */
    }

    public function retrieved(Tarifa $tarifa)
    {    
        $tarifa->TIPO = round($tarifa->TIPO);

        return $tarifa;
    }

    /**
     * Handle the Tarifa "updated" event.
     *
     * @param  \App\Models\Tarifa  $Tarifa
     * @return void
     */
    public function updated(Tarifa $Tarifa)
    {
        //
    }

    /**
     * Handle the Tarifa "deleted" event.
     *
     * @param  \App\Models\Tarifa  $Tarifa
     * @return void
     */
    public function deleted(Tarifa $Tarifa)
    {
        //
    }

    /**
     * Handle the Tarifa "restored" event.
     *
     * @param  \App\Models\Tarifa  $Tarifa
     * @return void
     */
    public function restored(Tarifa $Tarifa)
    {
        //
    }

    /**
     * Handle the Tarifa "force deleted" event.
     *
     * @param  \App\Models\Tarifa  $Tarifa
     * @return void
     */
    public function forceDeleted(Tarifa $Tarifa)
    {
        //
    }
}
