<?php

namespace App\Observers;

use app\Models\Cliente;

class ClienteObserver
{
    /**
     * Handle the Cliente "created" event.
     *
     * @param  \App\Models\Cliente  $Cliente
     * @return void
     */
    public function created(Cliente $Cliente)
    {
        /* dd($Cliente);
        if($Cliente->CLIENTE) $Cliente->CLIENTE = round($Cliente->CLIENTE);

        return $Cliente; */
    }

    public function retrieved(Cliente $Cliente){
        
        $Cliente->DESCRIPCION = utf8_encode($Cliente->DESCRIPCION);
        $Cliente->ALIAS       = utf8_encode($Cliente->ALIAS);
        $Cliente->CONTACTO    = utf8_encode($Cliente->CONTACTO);
        $Cliente->CORREO      = utf8_encode($Cliente->CORREO);
        $Cliente->CIF         = utf8_encode($Cliente->CIF);
        $Cliente->POBLACION   = utf8_encode($Cliente->POBLACION);
        $Cliente->PROVINCIA   = utf8_encode($Cliente->PROVINCIA);
        $Cliente->PAIS        = utf8_encode($Cliente->PAIS);
        $Cliente->DIRECCION   = utf8_encode($Cliente->DIRECCION);

        return $Cliente;
    }

    /**
     * Handle the Cliente "updated" event.
     *
     * @param  \App\Models\Cliente  $Cliente
     * @return void
     */
    public function updated(Cliente $Cliente)
    {
        //
    }

    /**
     * Handle the Cliente "deleted" event.
     *
     * @param  \App\Models\Cliente  $Cliente
     * @return void
     */
    public function deleted(Cliente $Cliente)
    {
        //
    }

    /**
     * Handle the Cliente "restored" event.
     *
     * @param  \App\Models\Cliente  $Cliente
     * @return void
     */
    public function restored(Cliente $Cliente)
    {
        //
    }

    /**
     * Handle the Cliente "force deleted" event.
     *
     * @param  \App\Models\Cliente  $Cliente
     * @return void
     */
    public function forceDeleted(Cliente $Cliente)
    {
        //
    }
}
