<?php

namespace App\Observers;

use App\Models\EstadoPedido;

class EstadoPedidoObserver
{
    /**
     * Handle the EstadoPedido "created" event.
     *
     * @param  \App\Models\EstadoPedido  $EstadoPedido
     * @return void
     */
    public function created(EstadoPedido $estadoPedido)
    {
        //
    }

    public function retrieved(EstadoPedido $estadoPedido){
        
        if(isset($estadoPedido->DESCRIPCION)) $estadoPedido->DESCRIPCION = utf8_encode($estadoPedido->DESCRIPCION);

        return $estadoPedido;
    }

    /**
     * Handle the EstadoPedido "updated" event.
     *
     * @param  \App\Models\EstadoPedido  $EstadoPedido
     * @return void
     */
    public function updated(EstadoPedido $EstadoPedido)
    {
        //
    }

    /**
     * Handle the EstadoPedido "deleted" event.
     *
     * @param  \App\Models\EstadoPedido  $EstadoPedido
     * @return void
     */
    public function deleted(EstadoPedido $EstadoPedido)
    {
        //
    }

    /**
     * Handle the EstadoPedido "restored" event.
     *
     * @param  \App\Models\EstadoPedido  $EstadoPedido
     * @return void
     */
    public function restored(EstadoPedido $EstadoPedido)
    {
        //
    }

    /**
     * Handle the EstadoPedido "force deleted" event.
     *
     * @param  \App\Models\EstadoPedido  $EstadoPedido
     * @return void
     */
    public function forceDeleted(EstadoPedido $EstadoPedido)
    {
        //
    }
}
