<?php

namespace App\Observers;

use App\Models\ConjuntoArticulos;

class ConjuntoArticuloObserver
{
     /**
     * Handle the ConjuntoArticulo "created" event.
     *
     * @param  \App\Models\ConjuntoArticulos  $ConjuntoArticulo
     * @return void
     */
    public function created(ConjuntoArticulos $ConjuntoArticulo)
    {
        /* dd($ConjuntoArticulo);
        if($ConjuntoArticulo->CLIENTE) $ConjuntoArticulo->CLIENTE = round($ConjuntoArticulo->CLIENTE);

        return $ConjuntoArticulo; */
    }

    public function retrieved(ConjuntoArticulos $conjunto){
        
        $conjunto->DESCRIPCION                    = ($conjunto->DESCRIPCION)                    ? utf8_encode($conjunto->DESCRIPCION)                    : "";
        $conjunto->DESCRIPCION_CONJUNTO_WEB       = ($conjunto->DESCRIPCION_CONJUNTO_WEB)       ? utf8_encode($conjunto->DESCRIPCION_CONJUNTO_WEB)       : "";
        //$conjunto->COMENTARIO_CONJUNTO_WEB        = ($conjunto->COMENTARIO_CONJUNTO_WEB)        ? utf8_encode($conjunto->COMENTARIO_CONJUNTO_WEB)        : "";
        $conjunto->COMENTARIO_CONJUNTO_WEB_CORTO  = ($conjunto->COMENTARIO_CONJUNTO_WEB_CORTO)  ? utf8_encode($conjunto->COMENTARIO_CONJUNTO_WEB_CORTO)  : "";
        $conjunto->REFERENCIA_FABRICANTE_CONJUNTO = ($conjunto->REFERENCIA_FABRICANTE_CONJUNTO) ? utf8_encode($conjunto->REFERENCIA_FABRICANTE_CONJUNTO) : "";
        $conjunto->DESC_MULTI1                    = ($conjunto->DESC_MULTI1)                    ? utf8_encode($conjunto->DESC_MULTI1)                    : "";  
        $conjunto->DESC_MULTI2                    = ($conjunto->DESC_MULTI2)                    ? utf8_encode($conjunto->DESC_MULTI2)                    : "";  
        $conjunto->DESC_MULTI3                    = ($conjunto->DESC_MULTI3)                    ? utf8_encode($conjunto->DESC_MULTI3)                    : "";  
        $conjunto->MARCA                          = ($conjunto->MARCA)                          ? utf8_encode($conjunto->MARCA)                          : "";  

        return $conjunto;
    }

    /**
     * Handle the ConjuntoArticulo "updated" event.
     *
     * @param  \App\Models\ConjuntoArticulo  $ConjuntoArticulo
     * @return void
     */
    public function updated(ConjuntoArticulos $ConjuntoArticulo)
    {
        //
    }

    /**
     * Handle the ConjuntoArticulo "deleted" event.
     *
     * @param  \App\Models\ConjuntoArticulo  $ConjuntoArticulo
     * @return void
     */
    public function deleted(ConjuntoArticulos $ConjuntoArticulo)
    {
        //
    }

    /**
     * Handle the ConjuntoArticulo "restored" event.
     *
     * @param  \App\Models\ConjuntoArticulo  $ConjuntoArticulo
     * @return void
     */
    public function restored(ConjuntoArticulos $ConjuntoArticulo)
    {
        //
    }

    /**
     * Handle the ConjuntoArticulo "force deleted" event.
     *
     * @param  \App\Models\ConjuntoArticulo  $ConjuntoArticulo
     * @return void
     */
    public function forceDeleted(ConjuntoArticulos $ConjuntoArticulo)
    {
        //
    }
}
