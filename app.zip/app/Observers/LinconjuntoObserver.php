<?php

namespace App\Observers;

use App\Models\Linconjunto;

class LinconjuntoObserver
{
    /**
     * Handle the Linconjunto "created" event.
     *
     * @param  \App\Models\Linconjunto  $Linconjunto
     * @return void
     */
    public function created(Linconjunto $Linconjunto)
    {
        /* dd($Linconjunto);
        if($Linconjunto->CLIENTE) $Linconjunto->CLIENTE = round($Linconjunto->CLIENTE);

        return $Linconjunto; */
    }

    public function retrieved(Linconjunto $linconjunto){
        
        $linconjunto->MULTI1 = ($linconjunto->MULTI1) ? utf8_encode($linconjunto->MULTI1) : "";
        $linconjunto->MULTI2 = ($linconjunto->MULTI2) ? utf8_encode($linconjunto->MULTI2) : "";
        $linconjunto->MULTI3 = ($linconjunto->MULTI3) ? utf8_encode($linconjunto->MULTI3) : "";

        return $linconjunto;
    }

    /**
     * Handle the Linconjunto "updated" event.
     *
     * @param  \App\Models\Linconjunto  $Linconjunto
     * @return void
     */
    public function updated(Linconjunto $Linconjunto)
    {
        //
    }

    /**
     * Handle the Linconjunto "deleted" event.
     *
     * @param  \App\Models\Linconjunto  $Linconjunto
     * @return void
     */
    public function deleted(Linconjunto $Linconjunto)
    {
        //
    }

    /**
     * Handle the Linconjunto "restored" event.
     *
     * @param  \App\Models\Linconjunto  $Linconjunto
     * @return void
     */
    public function restored(Linconjunto $Linconjunto)
    {
        //
    }

    /**
     * Handle the Linconjunto "force deleted" event.
     *
     * @param  \App\Models\Linconjunto  $Linconjunto
     * @return void
     */
    public function forceDeleted(Linconjunto $Linconjunto)
    {
        //
    }
}
