<?php

namespace App\Observers;

use App\Models\Articulo;

class ArticuloObserver
{
    /**
     * Handle the Articulo "created" event.
     *
     * @param  \App\Models\Articulo  $Articulo
     * @return void
     */
    public function created(Articulo $Articulo)
    {
        /* dd($Articulo);
        if($Articulo->CLIENTE) $Articulo->CLIENTE = round($Articulo->CLIENTE);

        return $Articulo; */
    }

    public function retrieved(Articulo $articulo){
        
        $articulo->DESCRIPCION           = utf8_encode($articulo->DESCRIPCION);
        $articulo->DESCRIPCION_WEB       = utf8_encode($articulo->DESCRIPCION_WEB);
        //$articulo->COMENTARIO_WEB        = utf8_encode($articulo->COMENTARIO_WEB);
        $articulo->COMENTARIO_WEB_CORTO  = utf8_encode($articulo->COMENTARIO_WEB_CORTO);
        $articulo->REFERENCIA_FABRICANTE = utf8_encode($articulo->REFERENCIA_FABRICANTE);
        $articulo->SLUG                  = utf8_encode($articulo->SLUG);

        return $articulo;
    }

    /**
     * Handle the Articulo "updated" event.
     *
     * @param  \App\Models\Articulo  $Articulo
     * @return void
     */
    public function updated(Articulo $Articulo)
    {
        //
    }

    /**
     * Handle the Articulo "deleted" event.
     *
     * @param  \App\Models\Articulo  $Articulo
     * @return void
     */
    public function deleted(Articulo $Articulo)
    {
        //
    }

    /**
     * Handle the Articulo "restored" event.
     *
     * @param  \App\Models\Articulo  $Articulo
     * @return void
     */
    public function restored(Articulo $Articulo)
    {
        //
    }

    /**
     * Handle the Articulo "force deleted" event.
     *
     * @param  \App\Models\Articulo  $Articulo
     * @return void
     */
    public function forceDeleted(Articulo $Articulo)
    {
        //
    }
}
