<?php

namespace App\Observers;

use App\Models\Categoria;

class CategoriaObserver
{
     /**
     * Handle the Categoria "created" event.
     *
     * @param  \App\Models\Categoria  $Categoria
     * @return void
     */
    public function created(Categoria $Categoria)
    {
        /* dd($Categoria);
        if($Categoria->CLIENTE) $Categoria->CLIENTE = round($Categoria->CLIENTE);

        return $Categoria; */
    }

    public function retrieved(Categoria $categoria){
        
        $categoria->CODIGO               = round($categoria->CODIGO); 
        $categoria->CATEGORIA_PADRE      = round($categoria->CATEGORIA_PADRE);
        $categoria->DESCRIPCION          = utf8_encode($categoria->DESCRIPCION);
        //$categoria->DESCRIPCION_COMPLETA = utf8_encode($categoria->DESCRIPCION_COMPLETA);

        return $categoria;
    }

    /**
     * Handle the Categoria "updated" event.
     *
     * @param  \App\Models\Categoria  $Categoria
     * @return void
     */
    public function updated(Categoria $Categoria)
    {
        //
    }

    /**
     * Handle the Categoria "deleted" event.
     *
     * @param  \App\Models\Categoria  $Categoria
     * @return void
     */
    public function deleted(Categoria $Categoria)
    {
        //
    }

    /**
     * Handle the Categoria "restored" event.
     *
     * @param  \App\Models\Categoria  $Categoria
     * @return void
     */
    public function restored(Categoria $Categoria)
    {
        //
    }

    /**
     * Handle the Categoria "force deleted" event.
     *
     * @param  \App\Models\Categoria  $Categoria
     * @return void
     */
    public function forceDeleted(Categoria $Categoria)
    {
        //
    }
}
