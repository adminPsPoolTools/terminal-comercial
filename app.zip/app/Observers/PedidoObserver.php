<?php

namespace App\Observers;

use App\Models\Pedido;

use function PHPUnit\Framework\objectHasAttribute;

class PedidoObserver
{
    /**
     * Handle the Pedido "created" event.
     *
     * @param  \App\Models\Pedido  $Pedido
     * @return void
     */
    public function created(Pedido $Pedido)
    {
        //
    }

    public function retrieved(Pedido $pedido){
        
        if(isset($pedido->CLIENTE)) $pedido->CLIENTE = (int) round($pedido->CLIENTE);
        if(isset($pedido->ESTADO))  $pedido->ESTADO  = utf8_encode($pedido->ESTADO);

        return $pedido;
    }

    /**
     * Handle the Pedido "updated" event.
     *
     * @param  \App\Models\Pedido  $Pedido
     * @return void
     */
    public function updated(Pedido $Pedido)
    {
        //
    }

    /**
     * Handle the Pedido "deleted" event.
     *
     * @param  \App\Models\Pedido  $Pedido
     * @return void
     */
    public function deleted(Pedido $Pedido)
    {
        //
    }

    /**
     * Handle the Pedido "restored" event.
     *
     * @param  \App\Models\Pedido  $Pedido
     * @return void
     */
    public function restored(Pedido $Pedido)
    {
        //
    }

    /**
     * Handle the Pedido "force deleted" event.
     *
     * @param  \App\Models\Pedido  $Pedido
     * @return void
     */
    public function forceDeleted(Pedido $Pedido)
    {
        //
    }
}
