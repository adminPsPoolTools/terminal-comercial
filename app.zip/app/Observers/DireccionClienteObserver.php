<?php

namespace App\Observers;

use App\Models\DireccionCliente;

class DireccionClienteObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = false;

    /**
     * Handle the DireccionCliente "created" event.
     *
     * @param  \App\Models\DireccionCliente  $DireccionCliente
     * @return void
     */
    public function created(DireccionCliente $direccionCliente)
    {
        if(!$direccionCliente->LINEA)
        {
            $dirCliente = DireccionCliente::where("CLIENTE", $direccionCliente->CLIENTE)
                                          ->orderByDesc("LINEA")
                                          ->first();

            $direccionCliente->LINEA = ($dirCliente) ? ($dirCliente->LINEA + 1) : 1;
        }

        return $direccionCliente; 
    }

    public function retrieved(DireccionCliente $direccionCliente)
    {
        $direccionCliente->NOMBRE                    = utf8_encode($direccionCliente->NOMBRE);
        $direccionCliente->DIRECCION                 = utf8_encode($direccionCliente->DIRECCION);
        $direccionCliente->LOCALIDAD                 = utf8_encode($direccionCliente->LOCALIDAD);
        $direccionCliente->PROVINCIA                 = utf8_encode($direccionCliente->PROVINCIA);
        $direccionCliente->POBLACION                 = utf8_encode($direccionCliente->POBLACION);
        $direccionCliente->PAIS_DIRECCIONES_CLIENTES = utf8_encode($direccionCliente->PAIS_DIRECCIONES_CLIENTES);
        $direccionCliente->PAIS                      = utf8_encode($direccionCliente->PAIS);
        $direccionCliente->CONTACTO                  = utf8_encode($direccionCliente->CONTACTO);

        return $direccionCliente;
    }

    /**
     * Handle the DireccionCliente "updated" event.
     *
     * @param  \App\Models\DireccionCliente  $DireccionCliente
     * @return void
     */
    public function updated(DireccionCliente $DireccionCliente)
    {
        //
    }

    /**
     * Handle the DireccionCliente "deleted" event.
     *
     * @param  \App\Models\DireccionCliente  $DireccionCliente
     * @return void
     */
    public function deleted(DireccionCliente $DireccionCliente)
    {
        //
    }

    /**
     * Handle the DireccionCliente "restored" event.
     *
     * @param  \App\Models\DireccionCliente  $DireccionCliente
     * @return void
     */
    public function restored(DireccionCliente $DireccionCliente)
    {
        //
    }

    /**
     * Handle the DireccionCliente "force deleted" event.
     *
     * @param  \App\Models\DireccionCliente  $DireccionCliente
     * @return void
     */
    public function forceDeleted(DireccionCliente $DireccionCliente)
    {
        //
    }
}
