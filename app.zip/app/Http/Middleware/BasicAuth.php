<?php

namespace App\Http\Middleware;

use Illuminate\Http\Request;

use App\Models\User;

use Closure;
//use Auth;
use App\Helpers\ResponseHelper as Response;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;


class BasicAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        //dd($request->headers['authorization']);

        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $uri  = $_SERVER['REQUEST_URI'];

        $fullUrl = $protocol . '://' . $host . $uri;

        Log::notice(date("Y-m-d H:i:s")." - ". $fullUrl);

        return $next($request);

        $username = $request->header('php-auth-user');
        $password = $request->header('php-auth-pw');

        Log::notice('Username: '.$username);

        if(!$username || !$password) return Response::error("Faltan las credenciales de autenticación", 401);

        $user = User::whereRaw("CORREO  = '$username'")
                    ->whereRaw("PASWORD = '$password'")
                    ->first();

        if($user)
        {
            Auth::login($user);

            return $next($request);
        }
        else
        {
            return Response::error("Usuario y/o contraseña incorrectos", 401);
        }
    }
}
