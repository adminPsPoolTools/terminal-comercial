<?php

namespace App\Http\Middleware;

use App\Helpers\UtilsHelper;
use Closure;
use Illuminate\Http\Request;

class UTF8ToIsoEncode
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        

        //Si es un get o delete no es necesario cambiar la codificación
        if($request->isMethod("GET") || $request->isMethod("DELETE")) {
            return $next($request);
        }

        //Modificar codificación
        $input = $request->all();
        $encodedInput = UtilsHelper::isoize($input);
        $request->replace($encodedInput);

        return $next($request);
    }
}
