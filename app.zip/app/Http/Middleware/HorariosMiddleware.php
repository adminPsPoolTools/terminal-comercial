<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

use App\Helpers\ResponseHelper as Response;

class HorariosMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $horaActual = now()->hour;

        // Verificar si la hora actual está dentro del rango permitido (entre las 00:00 y las 07:00)
        if ($horaActual >= 0 && $horaActual <= 6) {
            // La solicitud está dentro del rango horario permitido
            return $next($request);
        }

        if (($request->has('sku') && !empty($request->query('sku'))) || ($request->has('fechahora') && strtotime($request->query('fechahora')) >= strtotime("-2 days")))
        {
            return $next($request);
        }

        // La solicitud está fuera del rango horario permitido
        return Response::error("Acceso no autorizado. El acceso está permitido solo entre las 00:00 y las 07:00", 403);
    }
}
