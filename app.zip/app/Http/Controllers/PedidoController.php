<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

use App\Helpers\ResponseHelper as Response;
use App\Helpers\UtilsHelper as Utils;

use App\Models\Articulo;
use App\Models\ConjuntoArticulos;
use App\Models\DireccionCliente;
use App\Models\EstadoPedido;
use App\Models\Impuesto;
use App\Models\Linconjunto;
use App\Models\Linpedcli;
use App\Models\Pais;
use App\Models\Pedido;
use App\Models\User;

class PedidoController extends Controller
{
    public function index()
    {
        $posiblesEstados = [
            "Preparando",
            "Solicitud Cancelación",
            "Pendiente",
            "Completado",
            "Enviado",
            "Cancelado",
            "Devolución",
            "Albaranado",
            "Devolución aceptada",
            "Listo para preparar",
            "Incidencia"
        ];

        $cliente = auth()->user();

        if(!$cliente) Response::error("Error con el cliente", 400);

        $fechaDesde = (isset($_GET['fechaDesde'])) ? $_GET['fechaDesde'] : null;
        $fechaHasta = (isset($_GET['fechaHasta'])) ? $_GET['fechaHasta'] : null;
        $estado     = (isset($_GET['estado']))     ? $_GET['estado']     : null;    

        if ($fechaDesde && !strtotime($fechaDesde)) 
            return Response::error("La fecha desde no es válida", 400);

        if ($fechaHasta && !strtotime($fechaHasta))
            return Response::error("La fecha hasta no es válida", 400);

        if ($estado && !in_array(strtolower(Utils::removeAccents($estado)), array_map('strtolower', array_map([Utils::class, 'removeAccents'], $posiblesEstados)))) 
            return Response::error("El estado no es válido", 400);
        

        $pedidos = Pedido::selectRaw("CODIGO, CODIGO_PEDIDO_WEB AS ID_WEB, ESTADO, FECHA, CLIENTE")
                         ->where("CLIENTE", $cliente->CODIGO);
                         
        if ($fechaDesde) $pedidos = $pedidos->where("FECHA", ">=", $fechaDesde);
        if ($fechaHasta) $pedidos = $pedidos->where("FECHA", "<=", $fechaHasta);
        if ($estado)     $pedidos = $pedidos->whereRaw("UPPER(ESTADO) = UPPER('$estado')");
                         
        $pedidos = $pedidos->orderByDesc("FECHA")->get();

        $result = ["pedidos" => $pedidos];

        //dd($result);

        return Response::send($result);
    }

    public function create(Request $request)
    {
        $json = $request->json()->all();

        //print_r($json);
        Log::info(print_r($json, true));

        try
        {
            //VALIDACIÓN A MANO
            if(!isset($json["DIRECCION_ENVIO"])) return Response::error("Falta la dirección de envio", 400);
            if(!isset($json["LINEAS"]))          return Response::error("Faltan las lineas del pedido", 400);
            if( count($json["LINEAS"]) == 0)     return Response::error("Lineas sin artículos", 400);

            $cliente = auth()->user();

            //dd($cliente);
            //SI ME VIENE UN ID DE CLIENTE, VOY A COMPROBAR QUE EXISTE
            if(isset($json["ID_CLIENTE"]))
            {
                $tmpCliente = User::find($json["ID_CLIENTE"]);

                if ($tmpCliente) $cliente = $tmpCliente;
            }

            //$cCliente = isset($json["ID_CLIENTE"]) ? $json["ID_CLIENTE"] : auth()->user()->CODIGO;

            //VALIDO QUE EL CODIGO DEL PEDIDO NO ESTE REPETIDO
            if(isset($json["ID_PEDIDO"]) && !empty($json["ID_PEDIDO"]))
            {
                $pedido = Pedido::where('CODIGO_PEDIDO_WEB', $json["ID_PEDIDO"])
                                ->where('PROYECTO', env("PROYECTO_PEDIDOS", 1))
                                ->where('CLIENTE', $cliente->CODIGO)
                                ->first();

                if($pedido) return Response::send([
                    "Message" => "El pedido ya fué creado anteriormente",
                    "Numero de pedido" => $pedido->CODIGO
                ]);
            }

            /* $nombre    = isset($json["DIRECCION_ENVIO"]["NOMBRE"])        ? utf8_decode($json["DIRECCION_ENVIO"]["NOMBRE"])        : "";
            $apellidos = isset($json["DIRECCION_ENVIO"]["APELLIDOS"])     ? utf8_decode($json["DIRECCION_ENVIO"]["APELLIDOS"])     : "";
            $direccion = isset($json["DIRECCION_ENVIO"]["DIRECCION"])     ? utf8_decode($json["DIRECCION_ENVIO"]["DIRECCION"])     : "";
            $poblacion = isset($json["DIRECCION_ENVIO"]["POBLACION"])     ? utf8_decode($json["DIRECCION_ENVIO"]["POBLACION"])     : "";
            $cp        = isset($json["DIRECCION_ENVIO"]["CODIGO_POSTAL"]) ?             $json["DIRECCION_ENVIO"]["CODIGO_POSTAL"]  : "";
            $provincia = isset($json["DIRECCION_ENVIO"]["PROVINCIA"])     ? utf8_decode($json["DIRECCION_ENVIO"]["PROVINCIA"])     : "";
            $telefono  = isset($json["DIRECCION_ENVIO"]["TELEFONO"])      ?             $json["DIRECCION_ENVIO"]["TELEFONO"]       : ""; */

            $nombre        = (!empty($json["DIRECCION_ENVIO"]["NOMBRE"])         && isset($json["DIRECCION_ENVIO"]["NOMBRE"]))         ? $json["DIRECCION_ENVIO"]["NOMBRE"]         : "";
            $apellidos     = (!empty($json["DIRECCION_ENVIO"]["APELLIDOS"])      && isset($json["DIRECCION_ENVIO"]["APELLIDOS"]))      ? $json["DIRECCION_ENVIO"]["APELLIDOS"]      : "";
            $direccion     = (!empty($json["DIRECCION_ENVIO"]["DIRECCION"])      && isset($json["DIRECCION_ENVIO"]["DIRECCION"]))      ? $json["DIRECCION_ENVIO"]["DIRECCION"]      : "";
            $poblacion     = (!empty($json["DIRECCION_ENVIO"]["POBLACION"])      && isset($json["DIRECCION_ENVIO"]["POBLACION"]))      ? $json["DIRECCION_ENVIO"]["POBLACION"]      : "";
            $cp            = (!empty($json["DIRECCION_ENVIO"]["CODIGO_POSTAL"])  && isset($json["DIRECCION_ENVIO"]["CODIGO_POSTAL"]))  ? $json["DIRECCION_ENVIO"]["CODIGO_POSTAL"]  : "";
            $provincia     = (!empty($json["DIRECCION_ENVIO"]["PROVINCIA"])      && isset($json["DIRECCION_ENVIO"]["PROVINCIA"]))      ? $json["DIRECCION_ENVIO"]["PROVINCIA"]      : "";
            $telefonoFijo  = (!empty($json["DIRECCION_ENVIO"]["TELEFONO"])       && isset($json["DIRECCION_ENVIO"]["TELEFONO"]))       ? $json["DIRECCION_ENVIO"]["TELEFONO"]       : "";
            $telefonoMovil = (!empty($json["DIRECCION_ENVIO"]["TELEFONO_MOVIL"]) && isset($json["DIRECCION_ENVIO"]["TELEFONO_MOVIL"])) ? $json["DIRECCION_ENVIO"]["TELEFONO_MOVIL"] : "";
            $pais          = (!empty($json["DIRECCION_ENVIO"]["PAIS"])           && isset($json["DIRECCION_ENVIO"]["PAIS"]))           ? $json["DIRECCION_ENVIO"]["PAIS"]           : "";
            $ISOPais       = (!empty($json["DIRECCION_ENVIO"]["ISO_PAIS"])       && isset($json["DIRECCION_ENVIO"]["ISO_PAIS"]))       ? $json["DIRECCION_ENVIO"]["ISO_PAIS"]       : null;

            if (isset($ISOPais)) //SI TENGO LA ISO VAMOS A PRIORIZAR USAR EL PAIS DE LA TABLA PAISES
            {
                $objPais = Pais::where("ISO_PAIS", $ISOPais)->first();   

                if ($objPais) $pais = $objPais->DESCRIPCION;
            }


            //PRIMERO BUSCO LA LINEA DE LA DIRECCION DEL CLIENTE
            $dirCliente = DireccionCliente::where("CLIENTE", $cliente->CODIGO)
                                          //->whereRaw("UPPER(NOMBRE)                    = UPPER('". str_replace("'", "''", $nombre .' '. $apellidos) ."')")
                                          ->where("NOMBRE", utf8_decode(str_replace("'", "''", $nombre .' '. $apellidos)))
                                          //->whereRaw("UPPER(DIRECCION)                 = UPPER('". str_replace("'", "''", $direccion) ."')")
                                          ->where("DIRECCION", utf8_decode(str_replace("'", "''", $direccion)))
                                          //->whereRaw("UPPER(PROVINCIA)                 = UPPER('". str_replace("'", "''", $provincia) ."')")
                                          ->where("PROVINCIA", utf8_decode(str_replace("'", "''", $provincia)))
                                          //->whereRaw("UPPER(POBLACION)                 = UPPER('". str_replace("'", "''", $poblacion) ."')")
                                          ->where("POBLACION", utf8_decode(str_replace("'", "''", $poblacion)))
                                          //->whereRaw("UPPER(PAIS_DIRECCIONES_CLIENTES) = UPPER('". str_replace("'", "''", $pais) ."')")
                                          ->where("PAIS_DIRECCIONES_CLIENTES", utf8_decode(str_replace("'", "''", $pais)))
                                          ->where("CP", $cp)
                                          ->where("TELEFONOFIJO",  $telefonoFijo)
                                          ->where("TELEFONOMOVIL", $telefonoMovil);
                                          /* ->toSQL()->dd(); */
                                          /* ->first(); */
            //$dirCliente->toSQL()->dd();
            //dump($dirCliente->toSql());

            $dirCliente = $dirCliente->first();

            //dd($dirCliente);

            //SI NO LA ENCUENTRO LA CREO
            if(!$dirCliente)
            {
                $dirCliente = DireccionCliente::create([
                    "CLIENTE"                   => $cliente->CODIGO,
                    "LINEA"                     => DireccionCliente::siguienteLinea($cliente->CODIGO), 
                    "DIRECCION"                 => utf8_decode($direccion),
                    "POBLACION"                 => utf8_decode($poblacion),
                    "PAIS_DIRECCIONES_CLIENTES" => utf8_decode($pais),
                    "CP"                        => $cp,
                    "PROVINCIA"                 => utf8_decode($provincia),
                    "TELEFONOFIJO"              => $telefonoFijo,
                    "TELEFONOMOVIL"             => $telefonoMovil,
                    "NOMBRE"                    => utf8_decode($nombre .' '. $apellidos) 
                ]);

                //dd($dirCliente);
            }

            //GENERO UN CODIGO DE PEDIDO
            $res = DB::select('SELECT GEN_ID(PEDCLI_CODIGO_GEN, 1) as N_CODIGO FROM RDB$DATABASE')[0];

            $cPedido = $res->N_CODIGO;

            $pvpTotal = 0;

            //INSERTAMOS EL PEDIDO
            $pedido = new Pedido;

            $pedido->CODIGO   = $cPedido;
            $pedido->CLIENTE  = $cliente->CODIGO;
            $pedido->FECHA    = date("m-d-Y");
            $pedido->TITULO   = "Pedido WEB (".$json["ID_PEDIDO"].")";
            $pedido->PROYECTO = env("PROYECTO_PEDIDOS", 1); 
            $pedido->LINEADIRECCIONENVIO = $dirCliente->LINEA;
            $pedido->COMENTARIO_ENVIO = utf8_decode(isset($json["COMENTARIO_ENVIO"]) ? $json["COMENTARIO_ENVIO"] : "");
            $pedido->FORMADEPAGO = $cliente->FORMADEPAGO;

            if(isset($json["ESTADO"]))                                  $pedido->ESTADO = utf8_decode($json["ESTADO"]);
            if(isset($json["ID_PEDIDO"]) && !empty($json["ID_PEDIDO"])) $pedido->CODIGO_PEDIDO_WEB = $json["ID_PEDIDO"];

            if (config('app.b2b') && isset($json["IMPUESTO"]))
            {
                $iva = $json["IMPUESTO"];
                $impuesto = null;

                if(is_numeric($iva)) $impuesto = Impuesto::where("IVA", $iva)->first(); 
    
                if (!$impuesto || $json["IMPUESTO"] == "0") $impuesto = Impuesto::find("99");

                $pedido->IMPUESTO = $impuesto->CODIGO;
            }

            $pedido->save();

            if (config('app.asignar_agencia_auto')) $this->asignarAgencia($cPedido);

            //INSERTAMOS LAS LINEAS DEL PEDIDO
            foreach ($json["LINEAS"] as $linea)
            {
                $linArticulo = isset($linea["ARTICULO"]) ? $linea["ARTICULO"] : "";
            
                //PRIMERO MIRO QUE EL ARTICULO NO ESTÉ BLOQUEADO Y EXISTA, SI NO LO CANCELO TODO
                //$articulo = Articulo::find($linArticulo);
                $articulo = Utils::buscarArticulo($linArticulo, config("app.proyecto_stock", 1));

                if(!$articulo || $articulo->bloqueado())
                {
                    $pedido->delete();
                    return Response::error("El artículo ".$linArticulo." no está disponible", '400');
                }


                $cantidad = round(isset($linea["CANTIDAD"]) ? $linea["CANTIDAD"] : 0);

                //CONTROLAMOS EL STOCK DEL ARTICULO, SI NO HAY STOCK NO PERMITO HACER EL PEDIDO
                $stock = $articulo->stockVendible(config("app.proyecto_stock", 1));
                if($stock < $cantidad)
                {
                    $pedido->delete();
                    return Response::error("El artículo ".$linArticulo." no tiene stock disponible", '400');
                }

                $linpedcli = new Linpedcli;                

                $linpedcli->PEDIDO     = $pedido->CODIGO;
                $linpedcli->LINEA      = "0";
                //$linpedcli->ARTICULO   = $linea["ARTICULO"];
                $linpedcli->ARTICULO   = $articulo->CODIGO;
                $linpedcli->CANTIDAD   = ($cantidad > 0) ? $cantidad : 0;
                $linpedcli->COMENTARIO = isset($linea["COMENTARIO"]) ? utf8_decode($linea["COMENTARIO"]) : "";

                if (config('app.b2b') && isset($linea['PVP']))
                {
                    $pvp = $linea['PVP'];  

                    $pvpTotal += $pvp;
                    
                    $importe = $cantidad * $pvp;

                    $linpedcli->IMPORTE  = $importe;
                    $linpedcli->PVP      = $pvp;
                    $linpedcli->PVPFINAL = $pvp;

                    if (isset($linea['DESCUENTO']))
                    {
                        $dto = $linea['DESCUENTO'];

                        $linpedcli->DTO = number_format($dto, 2);
                        $linpedcli->PVPFINAL = $pvp - ($pvp * $dto / 100);
                    }
                }
                
                $linpedcli->save();
            }

            if (config('app.b2b') && isset($json['IMPORTE_PORTES']))
            {
                $impPortes = $json['IMPORTE_PORTES'];

                $linpedcli = new Linpedcli;
                $linpedcli->PEDIDO = $pedido->CODIGO;
                $linpedcli->LINEA = "0";
                $linpedcli->ARTICULO = "PORTES".((date("i") <> "00") ? round(date("i")) : "");
                $linpedcli->CANTIDAD = 1;
                $linpedcli->PVP      = $impPortes;
                $linpedcli->PVPFINAL = $impPortes;
                $linpedcli->IMPORTE  = $impPortes;

                $linpedcli->save();

                //dump($linpedcli);
            }

            //POR ULTIMO RECALCULAMOS LOS PVPS
            if ($pvpTotal == 0) $res = DB::select("EXECUTE PROCEDURE RECALCULAR_PVP_PEDCLI(".$cPedido.", 0)");
            
            $res = DB::select("EXECUTE PROCEDURE RECALCULAR_COSTES_PEDCLI(".$cPedido.", 0)");
        }
        catch(\Exception $err)
        {
            //dd($err);
            if(isset($pedido)) $pedido->delete();

            return Response::error(utf8_encode($err->getMessage()), '500');
        }

        return Response::send([
            "Message" => "Pedido creado correctamente",
            "Numero de pedido" => $cPedido
        ]);
    }

    public function show(Request $request, $cPedido)
    {
        //dd($cPedido);
        //Primero obtengo el pedido
        $pedido = Pedido::selectRaw("CODIGO, CODIGO_PEDIDO_WEB AS ID_WEB, ESTADO, FECHA, CLIENTE")
                        ->where("CODIGO_PEDIDO_WEB", $cPedido)
                        ->where("CLIENTE", auth()->user()->CODIGO)
                        ->first();

        if(!$pedido && $cPedido < 2147483640) $pedido = Pedido::selectRaw("CODIGO, CODIGO_PEDIDO_WEB AS ID_WEB, ESTADO, FECHA, CLIENTE")
                                                              ->where("CODIGO", $cPedido)
                                                              ->where("CLIENTE", auth()->user()->CODIGO)
                                                              ->first();

        if (empty($pedido) || $pedido->CLIENTE <> auth()->user()->CODIGO) 
            return Response::error("No se encontró el pedido $cPedido", 404);


        //dd($cPedido);
        $pedido->TRACKING = $pedido->obtenerTrackings();
        
        $result = ["pedido" => $pedido];

        return Response::send($result);
    }

    public function delete(Request $request, $cPedido)
    {
        $pedido = Pedido::selectRaw("CODIGO, CODIGO_PEDIDO_WEB AS ID_WEB, ESTADO, FECHA")
                        ->where("CODIGO_PEDIDO_WEB", $cPedido)
                        ->first();

        if(!$pedido) $pedido = Pedido::find($cPedido);
        
        if(!$pedido) return Response::error("El pedido no existe", 404);
        
        //dump($pedido->cliente->CODIGO);
        //dump(auth()->user()->CODIGO);
                        
        //PRIMERO TENGO QUE MIRAR QUE EL PEDIDO SEA SUYO
        if($pedido->cliente->CODIGO <> auth()->user()->CODIGO) 
            return Response::error("El pedido no existe", 404);

        //AHORA SOLO VOY A PERMITIR CANCELAR EL PEDIDO SI SU ESTADO TIENE EL EVENTO "AL CREARSE" (1)
        $estadoAlCrearse       = EstadoPedido::where("EVENTO_CAMBIO", config('app.evento_al_crearse'))   ->first();
        $estadoAlCancelarseAPI = EstadoPedido::where("EVENTO_CAMBIO", config('app.evento_al_cancelarse'))->first();

        //dd($estadoAlCancelarseAPI->DESCRIPCION." - ". $pedido->ESTADO);

        if($estadoAlCancelarseAPI->DESCRIPCION == $pedido->ESTADO)
            return Response::error("El pedido ya tiene una solicitud de cancelación", 400);

        if(strtoupper($estadoAlCrearse->DESCRIPCION) <> strtoupper($pedido->ESTADO))
            return Response::error("El pedido tiene un estado que no permite cancelar", 400);
        

        $pedido->ESTADO = $estadoAlCancelarseAPI->DESCRIPCION;
        $pedido->save();

        return Response::send(["Message" => "Pedido cancelado correctamente"]);
    }

    public function asignarAgencia($cPedido)
    {
        $cAgencia = 0;
        $pedido = Pedido::find($cPedido);

        if (!$pedido) return;

        $res = DB::select("SELECT AGENCIA FROM AGENCIAS_DOCUMENTO(1, $cPedido)")[0];

        if (empty($res) || empty($res->AGENCIA)) return;

        $cAgencia = $res->AGENCIA;

        $pedido->AGENCIA = $cAgencia;

        $pedido->save();
    }

    public function buscarArticulo($codigo, $proyecto)
    {
        $articulo = Articulo::find($codigo);

        if ($articulo) return $articulo; //SI HE ENCONTRADO EL ARTÍCULO LO DEVUELVO Y YA ESTA

        //SI NO PUEDE SER UN CONJUNTO
        $conjunto = ConjuntoArticulos::find($codigo);
       

        if (!$conjunto) return null; //SI TAMPOCO ENCUENTRA EL CONJUNTO DEVUELVO NULL

        $compraConjunta = $conjunto->COMPRA_CONJUNTA;


        if ($compraConjunta) //SI ES COMPRA CONJUNTA DEVUELVO EL QUE MAS STOCK TIENE
        {
            $linconjunto = Linconjunto::where("LINCONJUNTOS.CONJUNTO", $conjunto->CODIGO)
                                      //->leftJoin("CALCULAR_STOCK_VENDIBLE_ARTI($proyecto, LINCONJUNTOS.ARTICULO) CSVA", "0", "=", "0")
                                      ->leftJoin(DB::raw("CALCULAR_STOCK_VENDIBLE_ARTI($proyecto, LINCONJUNTOS.ARTICULO) AS CSVA"), function($join) {
                                            $join->on(DB::raw('0'), '=', DB::raw('0')); // Esto depende de la lógica de tu unión
                                      })
                                      ->orderByDesc("CSVA.STOCK_VENDIBLE")
                                      ->first();

            if ($linconjunto) $articulo = $linconjunto->articulo;

            //dump($linconjunto);
        }
        else // SI NO DEVUELVO EL POR DEFECTO
        {
            $articulo = $conjunto->predeterminado();
        }

        return $articulo;
    }
}
