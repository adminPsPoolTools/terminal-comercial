<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class ContactosController extends Controller
{
    public function obtenerContactosPorCliente(Request $request)
    {
        $query = "select * from clientescontactos where cliente = :cliente ";
        $bindings = ['cliente' => $request->cliente];

        if($request->has('linea')){
            $query .= ' AND LINEA = :linea';
            $bindings['linea'] = $request->linea;
        }

        $query .= " order by nombre";
        $res = DB::select($query,  $bindings);
        return response()->json(UtilsHelper::utf8ize($res));

    }

    public function obtenerContactosPorExpediente(Request $request)
    {
        $query = "select * from expedientescontactos where expediente = :expediente";
        $bindings = ['expediente' => $request->expediente];
        if($request->has('linea')){
            $query .= ' AND LINEA = :linea';
            $bindings['linea'] = $request->linea;
        }
        $query .= " order by nombre";
        $res = DB::select($query,  $bindings);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function crearActualizarExpedientesContactos(Request $request)
    {

        $linea = $request->linea;
        if(empty($linea))
        {
            //obtener max linea de este expediente
            $lineaQuery = 'SELECT MAX(LINEA) AS LINEA FROM EXPEDIENTESCONTACTOS WHERE EXPEDIENTE = :expediente';
            $res = DB::select($lineaQuery, [
                'expediente' => $request->expediente,
            ]);
            $linea = $res[0]->LINEA + 1;
        }

        $query = 'UPDATE OR INSERT INTO expedientescontactos
            (NOMBRE, CARGO, TELEFONOFIJO, TELEFONOMOVIL, CORREO, FAX, COMENTARIO_CONTACTO, EXPEDIENTE, LINEA)
             VALUES
            (:nombre, :cargo, :telefonofijo, :telefonomovil, :correo, :fax, :comentario_contacto, :expediente, :linea)
            MATCHING (LINEA, EXPEDIENTE);';

        $res = DB::select($query, [
            'nombre'              => $request->nombre,
            'cargo'               => $request->cargo,
            'telefonofijo'        => $request->telefonofijo,
            'telefonomovil'       => $request->telefonomovil,
            'correo'              => $request->correo,
            'fax'                 => $request->fax,
            'comentario_contacto' => $request->comentario_contacto,
            'expediente'          => $request->expediente,
            'linea'             => $request->linea,
        ]);

        return response()->json(['msg' => 'Contacto actualizado']);

    }

    public function borrarClientesContactos(Request $request)
    {
        if(!empty($request->cliente))
        {
            $query = 'DELETE FROM CLIENTESCONTACTOS
            WHERE CLIENTE = :cliente
            AND linea = :linea';

            $res = DB::select($query, [
                'cliente' => $request->cliente,
                'linea'  => $request->linea,
            ]);
        }
        else if(!empty($request->expediente))
        {
            $query = 'DELETE FROM EXPEDIENTESCONTACTOS
            WHERE EXPEDIENTE = :expediente
            AND LINEA = :linea';

            $res = DB::select($query, [
                'expediente' => $request->expediente,
                'linea'  => $request->linea,
            ]);
        }



        return response()->json(['msg' => 'Contacto eliminado']);
    }

    public function obtenerDetalleContacto(Request $request)
    {
        $query =
            "SELECT cliente, linea, nombre, cargo, clientescontactos.telefonofijo as telefonofijo, clientescontactos.fax, clientescontactos.correo as correo, clientescontactos.telefonomovil,
            CAST(comentario_contacto AS VARCHAR(10000)) AS comentario_contacto
            from clientescontactos
            where 0=0 ";

        $contacto = "%$request->nombre%";
        $bindings = [
            'contacto'  => $contacto,
        ];

        if($request->has('cliente') && !empty($request->cliente) && $request->cliente != "0"){
            $query .= " and cliente = :cliente ";
            $bindings['cliente'] = $request->cliente;
        }

        $query .= " and nombre LIKE :contacto
                order by nombre";
        ;


        $res = DB::select($query, $bindings);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function grabarContactoConOSinCliente(Request $request)
    {
        //
        $codigoCliente = $request->cliente;
        if(empty($request->cliente) || $request->cliente == 0 || $request->cliente == '0')
        {
            $idQuery = "SELECT GEN_ID(CLIENTES_CODIGO_GEN, 1) AS N_ID FROM RDB\$DATABASE";
            $res = DB::select($idQuery);
            $codigoCliente = $res[0]->N_ID;
            DB::select("INSERT INTO CLIENTES (CODIGO) VALUES ($codigoCliente)");
        }

        $query = "UPDATE OR INSERT INTO CLIENTESCONTACTOS (CLIENTE, NOMBRE, TELEFONOMOVIL, CORREO, COMENTARIO_CONTACTO)
            VALUES (:cliente, :nombre, :telefono, :correo, '')
            MATCHING (CLIENTE, NOMBRE)";

        DB::select($query, [
            'cliente' => $codigoCliente,
            'nombre' => $request->nombre,
            'telefono' => $request->telefono,
            'correo' => $request->correo
        ]);

        return response()->json(['msg' => 'Contacto actualizado']);
    }

    public function crearActualizarClientesContactos(Request $request)
    {
        $linea = $request->linea;
        if(empty($linea))
        {
            //obtener max linea de este contacto
            $lineaQuery = 'SELECT MAX(LINEA) AS LINEA FROM CLIENTESCONTACTOS WHERE CLIENTE = :cliente';
            $res = DB::select($lineaQuery, [
                'cliente' => $request->cliente,
            ]);
            $linea = $res[0]->LINEA + 1;
        }

        $query = "UPDATE OR INSERT INTO CLIENTESCONTACTOS
            (CLIENTE, NOMBRE, CARGO, TELEFONOFIJO, TELEFONOMOVIL, CORREO, FAX, LINEADIRECCIONCLIENTE, COMENTARIO_CONTACTO, LINEA)
            VALUES
            (:cliente, :nombre, :cargo, :telefonofijo, :telefonomovil, :correo, :fax, :lineadireccion, :comentario_contacto, :linea)
             MATCHING (CLIENTE, LINEA)";

        $bindings = [
            'cliente' => $request->cliente,
            'nombre' => $request->nombre,
            'cargo' => $request->cargo,
            'telefonofijo' => $request->telefonofijo,
            'telefonomovil' => $request->telefonomovil,
            'correo' => $request->correo,
            'fax' => $request->fax,
            'lineadireccion' => $request->lineadireccion,
            'comentario_contacto' => $request->comentario_contacto,
            'linea' => $linea,
        ];

        DB::select($query, $bindings);
        return response()->json(['msg' => 'Contacto actualizado']);
    }

    public function obtenerContactosFichaClientes(Request $request)
    {
        $query = "SELECT C.cliente, c.linea, C.nombre, C.cargo, C.telefonofijo, C.fax, C.correo, C.telefonomovil,
            CAST(comentario_contacto AS VARCHAR(10000)) AS comentario_contacto, C.CONTACTO_POR_DEFECTO,
            D.DIRECCION, D.PROVINCIA as PROVINCIA, D.DESCRIPCION_DIRECCION_CLIENTE
            from clientescontactos C
            LEFT JOIN CLIENTES CL ON CL.CODIGO = C.CLIENTE
            LEFT JOIN DIRECCIONESCLIENTES D ON D.CLIENTE = C.CLIENTE AND D.LINEA = C.LINEADIRECCIONCLIENTE
            LEFT JOIN PROVINCIAS ON D.PROVINCIA = PROVINCIAS.DESCRIPCION
            where C.cliente = :cliente
            AND ((PROVINCIAS.COMERCIAL_ASIGNADO = :comercial )
                    OR (CL.PROVINCIA IS NOT NULL AND (C.LINEADIRECCIONCLIENTE IS NULL OR C.LINEADIRECCIONCLIENTE = 0)))
            order by C.nombre";

        $res = DB::select($query, [
            'cliente' => $request->cliente,
            'comercial' => $request->comercial
        ]);

        return response()->json(UtilsHelper::utf8ize($res));

    }

    public function obtenerLlamadasFichaClientes(Request $request)
    {
        $query = "select cliente,fecha,hora,telefono, llamadas_tel_clientes.descripcion,tipo_llamada, llamadas_tel_clientes.comentario
	    from llamadas_tel_clientes
        where  cliente = ?";

        $res = DB::select($query, [$request->cliente]);
        return response()->json(UtilsHelper::utf8ize($res));

    }

}
