<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class SeccionesController extends Controller
{
    public function obtenerSecciones()
    {
        $query = "SELECT * FROM SECCIONES
            WHERE BLOQUEADO <> 'S'
            ORDER BY DESCRIPCION ";
            $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));

    }
}
