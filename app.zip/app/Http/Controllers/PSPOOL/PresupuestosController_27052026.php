<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

use App\Helpers\UtilsHelper;

class PresupuestosController extends Controller
{
    public function obtenerPorExpediente(Request $request)
    {
        $query = "SELECT codigo, titulo, fecha
          FROM presupuestos
         WHERE expediente = :expediente
           AND COALESCE(BASE_EN_EXPEDIENTE, 'N') = 'S'
         ORDER BY CODIGO DESC";

        $res = DB::select($query, ['expediente' => $request->expediente]);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerPresupuestosFichaCliente(Request $request)
    {
        $sql = "SELECT presupuestos.codigo, presupuestos.fecha, presupuestos.titulo,presupuestos.estado, presupuestos.baseimponible, presupuestos.total, clientes.descripcion as descripcion_cliente,
               VALTA.NOMBRE AS USUARIO_ALTA, presupuestos.presupuesto AS PRESUPUESTO_DE, presupuestos.presupuestod AS PRESUPUESTO_A
          FROM presupuestos
          LEFT JOIN clientes                ON presupuestos.cliente = clientes.codigo
          LEFT JOIN VENDEDORES VALTA        ON VALTA.CODIGO = presupuestos.VENDEDOR
          LEFT JOIN VENDEDORES              ON VENDEDORES.CODIGO = :comercial
          LEFT JOIN SOLICITUD_PRESUPUESTO   ON presupuestos.solicitud = SOLICITUD_PRESUPUESTO.CODIGO
         WHERE presupuestos.fecha >= :fecha_desde
           and ((clientes.vendedor = :comercial3)
                or (:comercial1 = 1)
                or (:comercial2 > 100)
                or (VENDEDORES.ACCESO_TODOS_CLIENTES_TC = 'S'))";

        $bindings = [
            'comercial' => $request->comercial,
            'comercial1' => $request->comercial,
            'comercial2' => $request->comercial,
            'comercial3' => $request->comercial,
            'fecha_desde' => $request->fecha_desde
        ];


        if (!empty($request->cliente)) {
            $sql .= " and presupuestos.cliente = :cliente";
            $bindings['cliente'] = $request->cliente;
        }
        if (!empty($request->titulo)) {
            $sql .= " and upper(presupuestos.titulo) like :titulo";
            $bindings['titulo'] = "%" . strtoupper($request->titulo) . "%";
        }
        if (!empty($request->estado) && $request->estado !== "Todos") {

            $estado = urldecode(trim($request->estado));

            $partes = explode(' ', $estado, 2);
            $primeraPalabra = $partes[0];

            $sql .= " and presupuestos.estado LIKE :estado";
            $bindings['estado'] = $primeraPalabra . '%';
        }

        if (!empty($request->proyecto) && $request->proyecto !== "0") {
            $sql .= " and presupuestos.proyecto = :proyecto";
            $bindings['proyecto'] = $request->proyecto;
        }
        if (!empty($request->caracter) && $request->caracter !== "0") {
            $sql .= " and SOLICITUD_PRESUPUESTO.CARACTER = :caracter";
            $bindings['caracter'] = $request->caracter;
        }
        if (!empty($request->desc_articulo)) {
            $sql .= " and presupuestos.codigo in (SELECT presupuesto
                    FROM linpresu
                    WHERE linpresu.articulo in (SELECT codigo
                    FROM ARTICULOS
                    WHERE UPPER(DESCRIPCION) LIKE UPPER(:desc_articulo))
                    OR linpresu.articulo like :desc_articulo_like)";
            $bindings['desc_articulo'] = '%' . strtoupper($request->desc_articulo) . '%';
            $bindings['desc_articulo_like'] = '%' . $request->desc_articulo . '%';
        }

        if ((!empty($request->provincia)) && ($request->provincia != "")) {
            $sql_aux = "SELECT descripcion from provincias
                        where codigo = ?";
            $res_aux = DB::select($sql_aux, [$request->provincia]);
            $row_aux = $res_aux[0];
            $bindings['provincia_desc'] = $row_aux->DESCRIPCION;
            $sql .= " and trim(clientes.provincia) = :provincia_desc";
        }

        if ((!empty($request->poblacion)) && ($request->poblacion != "null") && ($request->poblacion <> "Todas") && ($request->provincia != "null")) {
            $sql_aux = "SELECT descripcion from poblaciones
                        where codigo = ?";
            $res_aux = DB::select($sql_aux, [$request->poblacion]);
            $row_aux = $res_aux[0];
            $bindings['poblacion_desc'] = $row_aux->DESCRIPCION;
            $sql .= " and trim(clientes.poblacion) = :poblacion_desc";
        }

        $sql .= " ORDER BY ";

        switch ($request->orden) {
            case 'fecha':
                $sql .= "presupuestos.fecha";
                break;

            case 'cliente':
                $sql .= "clientes.descripcion";
                break;

            case 'vendedor':
                $sql .= "VALTA.NOMBRE";
                break;

            case 'base_imp':
                $sql .= "presupuestos.baseimponible";
                break;

            case 'imp_c_iva':
                $sql .= "presupuestos.total";
                break;

            case 'titulo':
                $sql .= "presupuestos.titulo";
                break;

            case 'codigo':
            default:
                $sql .= "presupuestos.codigo";
                break;
        }

        $sql .= " " . $request->orden_ori;

        $res = DB::select($sql, $bindings);


        return response()->json(UtilsHelper::utf8ize($res));
    }


    public function obtenerSolicitudesFichaCliente(Request $request)
    {
        $query = "SELECT solicitud_presupuesto.codigo,
            solicitud_presupuesto.fecha,
            solicitud_presupuesto.hora,
            solicitud_presupuesto.caracter,
            solicitud_presupuesto.comentario,
            solicitud_presupuesto.descripcion_detallada,
            /* CAST(solicitud_presupuesto.texto_plantilla AS VARCHAR(10000)) AS TEXTO_PLANTILLA, */
            solicitud_presupuesto.texto_plantilla AS TEXTO_PLANTILLA,
            solicitud_presupuesto.presupuesto,
            caracter_solicitudes.descripcion as desc_caracter,
            clientes.descripcion,
            categorias_sol_presupuestos.DESCRIPCIONCATEGORIA
            from solicitud_presupuesto, clientes, caracter_solicitudes, categorias_sol_presupuestos
            where solicitud_presupuesto.cliente   = clientes.codigo
            and caracter_solicitudes.codigo     = solicitud_presupuesto.caracter
            and solicitud_presupuesto.categoria_solicitud = categorias_sol_presupuestos.codigo
            and solicitud_presupuesto.cliente   = :cliente1 ";

        $bindings = ['cliente1' => $request->cliente];

        if (!empty($request->cliente)) {
            $query .= " and  cliente = :cliente2 ";
            $bindings['cliente2'] = $request->cliente;
        }

        //1 Presupuestadas
        //2 No presupestadas

        if (!empty($request->filtro)) {
            if ($request->filtro == 1) {
                $query .= "and presupuesto is not null";
            }
            if ($request->filtro == 2) {
                $query .= "and presupuesto is null";
            }
        }

        //$sql = $sql . " order by codigo,fecha,hora desc";
        $query .= " order by codigo desc";

        $res = DB::select($query, $bindings);
        return response()->json(UtilsHelper::utf8ize($res));
    }


    //opciones select caracter
    public function obtenerOpcionesCaracterSolicitud(Request $request)
    {
        //SEPARO LA SQL DEL CARACTER DE LA SOLICITUD DEL RESTO PARA PODER TRABAJAR CON SU CARACTER
        if (!empty($request->solicitud)) {
            $query = "SELECT CARACTER FROM SOLICITUD_PRESUPUESTO WHERE CODIGO = ?";
            $res = DB::select($query, [$request->solicitud]);

            $caracter_sol = $res[0]->CARACTER;
        } else $caracter_sol = null;

        $query =  "SELECT CODIGO, DESCRIPCION
                FROM CARACTER_SOLICITUDES
               WHERE CODIGO = 2
                  OR CODIGO = 3
                  OR CODIGO = 8";

        if (!empty($caracter_sol->CARACTER)) {
            $query .= " OR CODIGO = ? ";
        };

        $query .= " GROUP BY 1, 2
               order by 1 ";

        $res = DB::select($query, [$caracter_sol]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    //opciones select categoria solicitud presupuesto
    public function obtenerOpcionesCategoriaSolicitud()
    {
        $query =  "select * from CATEGORIAS_SOL_PRESUPUESTOS order by codigo ";
        $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerSolicitudPorCodigo(Request $request)
    {
        $query = "SELECT * FROM solicitud_presupuesto"
            . " WHERE codigo = ?";

        if (!empty($request->visita_comercial)) {
            $query .= " OR SOLICITUD_PRESUPUESTO.VISITACOMERCIAL = ?";
        }
        $res = DB::select($query, [$request->codigo, $request->visita_comercial]);

        if (count($res) > 0) {
            $res[0]->imagenes = [];
            //buscar imágenes relacionadas
            $listaArchivos = UtilsHelper::obtenerListaArchivosCarpeta('solicitudes_presupuestos/' . $request->codigo);

            Log::info(print_r($listaArchivos, true));

            $res[0]->imagenes = $listaArchivos;

            /* foreach ($listaArchivos as $archivo)
            {
                $res[0]->imagenes[] = UtilsHelper::obtenerURLAsset("solicitudes_presupuestos/$request->codigo/$archivo");
            } */
        }

        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function obtenerDescripcionCaracterSolicitud(Request $request)
    {
        $query = "SELECT DESCRIPCION FROM caracter_solicitudes WHERE CODIGO = ?";
        $res = DB::select($query, [$request->caracter]);
        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function actualizarSolicitud(Request $request)
    {
        $query = "UPDATE solicitud_presupuesto
            SET fecha = :fecha,
                texto_plantilla = :plantilla,
                hora = :hora,
                caracter = :caracter,
                CATEGORIA_SOLICITUD = :categoria,
                CORREO_PRESUPUESTO = :correo,
                VISITACOMERCIAL = :visitaComercial,
                PROYECTO = :proyecto,
                expediente = :expediente
            WHERE codigo = :codigo";

        $bindings = [
            'fecha'            => $request->fecha,
            'plantilla'        => $request->texto_plantilla,
            'hora'             => $request->hora,
            'caracter'         => $request->caracter,
            'categoria'        => $request->categoria,
            'correo'           => $request->correo,
            'visitaComercial'  => $request->visitaComercial,
            'proyecto'         => $request->proyecto,
            'expediente'       => $request->expediente,
            'codigo'           => $request->codigo
        ];

        DB::select($query, $bindings);
        return response()->json(['msg' => 'Registro actualizado']);
    }

    public function obtenerSiguienteCodigoSolicitud(Request $request)
    {
        $query = "SELECT GEN_ID(solicitud_codigo_gen,1) AS NUEVO_CODIGO FROM RDB\$DATABASE";
        $res = DB::select($query);
        return response()->json($res[0]);
    }

    public function crearSolicitud(Request $request)
    {
        $query = "INSERT INTO SOLICITUD_PRESUPUESTO (CODIGO, FECHA, HORA, COMERCIAL, PROYECTO, CLIENTE, CARACTER, CATEGORIA_SOLICITUD, CORREO_PRESUPUESTO,
            TEXTO_PLANTILLA, EXPEDIENTE, TIPO_SOLICITUD_PRESUPUESTO, VISITACOMERCIAL)
            VALUES
            (:nuevo_codigo, :fecha, :hora, :comercial, :proyecto, :cliente, :caracter, :categoria, :correo,
            :plantilla, :expediente, 1, :visitaComercial)";

        $bindings = [
            'nuevo_codigo' => $request->nuevo_codigo,
            'fecha' => $request->fecha,
            'hora' => $request->hora,
            'comercial' => $request->comercial,
            'proyecto' => $request->proyecto,
            'cliente' => $request->cliente,
            'caracter' => $request->caracter,
            'categoria' => $request->categoria,
            'correo' => $request->correo,
            'plantilla' => $request->plantilla,
            'expediente' => $request->expediente,
            'visitaComercial' => $request->visitaComercial
        ];

        DB::select($query, $bindings);
        return response()->json(['msg' => "Registro creado"]);
    }

    public function borrarSolicitud(Request $request)
    {
        $query = "DELETE FROM SOLICITUD_PRESUPUESTO "
            . "WHERE CODIGO = ? ";

        DB::select($query, [$request->codigo]);
        return response()->json(['msg' => "Registro eliminado"]);
    }


    //INFORME_PRESUPUESTO

    public function obtenerInformacionPresupuesto(Request $request)
    {
        $query = "SELECT proyectos.razonsocial as razonsocial, proyectos.cif, proyectos.direccion, proyectos.cp, proyectos.poblacion,
               proyectos.provincia, proyectos.telefono, proyectos.fax, proyectos.email, proyectos.codigo as proyecto,

               clientes.codigo as cli_codigo, clientes.descripcion as cli_descripcion, clientes.cif as cli_cif, clientes.direccion as cli_direccion,
               clientes.cp as cli_cp, clientes.poblacion as cli_poblacion, clientes.provincia as cli_provincia, clientes.telefonofijo as cli_telefonofijo,
               clientes.fax as cli_fax, clientes.correo as cli_correo,

               presupuestos.codigo as pre_codigo, presupuestos.fecha, presupuestos.titulo, presupuestos.descripcion as pre_descripcion,
               presupuestos.baseimponible, presupuestos.total, presupuestos.pedido, presupuestos.tiquet, presupuestos.pdto,
               presupuestos.importedto, presupuestos.estado,

               vendedores.nombre as vendedor,

               impuestos.iva

          from presupuestos
          left join clientes   on presupuestos.cliente  = clientes.codigo
          left join proyectos  on presupuestos.proyecto = proyectos.codigo
          left join impuestos  on presupuestos.impuesto = impuestos.codigo
          left join vendedores on presupuestos.vendedor = vendedores.codigo
         where presupuestos.codigo   = ?";

        $res = DB::select($query, [$request->presupuesto]);
        $presupuesto = count($res) > 0 ? $res[0] : null;
        return response()->json(UtilsHelper::utf8ize($presupuesto));
    }

    public function obtenerArticulosPresupuesto(Request $request)
    {
        $query = "SELECT articulo, descripcion, CAST(cantidad AS FLOAT) as cantidad, CAST(pvp AS FLOAT) AS PVP, dto, CAST(pvpfinal AS FLOAT) AS PVPFINAL,
            CAST(importe AS FLOAT) AS IMPORTE, linpresu.comentario
            FROM linpresu, articulos
            WHERE articulos.codigo = linpresu.articulo
            AND presupuesto = ?";

        $res = DB::select($query, [$request->presupuesto]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function actualizarEstadoPresupuesto(Request $request)
    {
        $sql = "UPDATE presupuestos
        SET comentario_comercial_presu = :comentario";

        $bindings = [
            'comentario' => $request->comentario,
            'presupuesto' => $request->presupuesto
        ];

        if (!empty($request->estado)) {
            $sql .= ", estado = :estado";
            $bindings['estado'] = $request->estado;
        }

        $sql .= " WHERE codigo = :presupuesto";
        DB::select($sql, $bindings);

        return response()->json(['msg' => $request->all()]);
    }

    public function cargarDetalleEstadoPresupuesto(Request $request)
    {
        $sql = "SELECT * FROM PRESUPUESTOS WHERE CODIGO = :codigo";

        $bindings = ['codigo' => $request->codigo];
        $result = DB::select($sql, $bindings);
        $res = count($result) > 0 ? $result[0] : null;

        return response()->json(UtilsHelper::utf8ize($res));
    }

    //menu presupuestos
    public function obtenerSelectEstadosPresupuesto()
    {
        $sql = "SELECT DESCRIPCION as estado FROM estados_presupuestos ORDER BY estado";
        $res = DB::select($sql);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function subirFotoSolicitud(Request $request) {}
}
