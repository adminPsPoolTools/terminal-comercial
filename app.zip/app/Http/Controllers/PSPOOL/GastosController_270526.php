<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class GastosController extends Controller
{
    public function obtenerTiposGasto()
    {
        $query = "SELECT * FROM GASTOS";
        $res = DB::select($query);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerTiposMediosCobro()
    {
        $query = "SELECT * FROM MEDIOSCOBRO";
        $res = DB::select($query);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function buscarGastos(Request $request)
    {
        $sql = "SELECT HG.CODIGO, HG.PROYECTO, HG.GASTO AS CGASTO, G.DESCRIPCION AS GASTO, HG.FECHA,
               HG.COMENTARIO, HG.IMPORTE, HG.PAGADO, MEDIOSCOBRO.DESCRIPCION AS MEDIOCOBRO
        FROM HGASTOS HG
        LEFT JOIN GASTOS G ON G.CODIGO = HG.GASTO
        LEFT JOIN MEDIOSCOBRO ON HG.MEDIOCOBRO = MEDIOSCOBRO.CODIGO
        WHERE (HG.VENDEDOR = :comercial1 OR :comercial2 = 99)
          AND HG.FECHA BETWEEN :fecha_gasto_desde AND :fecha_gasto_hasta
          AND HG.PROYECTO = 1";

        $comercial = $request->comercial;
        $fecha_gasto_desde = $request->fecha_gasto_desde;
        $fecha_gasto_hasta = $request->fecha_gasto_hasta;
        $comentario = $request->comentario;
        $tipo_gasto = $request->tipo_gasto;
        $medio_cobro = $request->medio_cobro;
        $pagado = $request->pagado;

        $params = [
            'comercial1' => $comercial,
            'comercial2' => $comercial,
            'fecha_gasto_desde' => $fecha_gasto_desde,
            'fecha_gasto_hasta' => $fecha_gasto_hasta
        ];

        // Add conditions based on the optional filters
        if (!empty($comentario)) {
            $sql .= " AND upper(HG.comentario) LIKE :comentario";
            $params['comentario'] = '%' . strtoupper($comentario) . '%';
        }

        if (!empty($tipo_gasto) && $tipo_gasto !== "Todos" && $tipo_gasto !== "0") {
            $sql .= " AND HG.GASTO = :tipo_gasto";
            $params['tipo_gasto'] = $tipo_gasto;
        }

        if (!empty($medio_cobro) && $medio_cobro !== "Todos" && $medio_cobro !== "0") {
            $sql .= " AND HG.MEDIOCOBRO = :medio_cobro";
            $params['medio_cobro'] = $medio_cobro;
        }

        if (!empty($pagado) && $pagado !== "Todos" && $pagado !== "0") {
            $sql .= " AND HG.PAGADO = :pagado";
            $params['pagado'] = ($pagado == 1 || $pagado == "1") ? "S" : "N";
        }

        $sql .= " ORDER BY HG.CODIGO DESC";

        // Execute the query with the parameters
        $res = DB::select($sql, $params);

        //Comprobar si hay archivos asociados a los resultados de la query
        foreach($res as $gasto)
        {
            $listaArchivos = UtilsHelper::obtenerListaArchivosCarpeta('gastos/'.$gasto->CODIGO);
            
            $gasto->tieneArchivos = (count($listaArchivos) > 0);
        }


        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerDetalle(Request $request)
    {
        $query = "SELECT * FROM HGASTOS WHERE CODIGO = ?";

        $res = DB::select($query, [$request->gasto]);
       if(count($res) > 0){
            $res[0]->imagenes = [];
            //buscar imágenes relacionadas
            $listaArchivos = UtilsHelper::obtenerListaArchivosCarpeta('gastos/'.$request->gasto);
            foreach ($listaArchivos as $archivo)
            {
                if(UtilsHelper::archivoEsImagen($archivo)) $res[0]->imagenes[] = UtilsHelper::obtenerURLAsset("$archivo");
            }

        }


        return response()->json(UtilsHelper::utf8ize(
            count($res) > 0 ? $res[0] : null
        ));
    }

    public function actualizarOCrear(Request $request)
    {

        //dd(UtilsHelper::removeAccentsV2($request->comentario));
        $codigo = $request->codigo;
        if(empty($codigo) || $codigo == 0 || $codigo == "0")
        {
            //buscar nuevo código
            $queryCodigo = 'SELECT GEN_ID(hgastos_codigo_gen,1) AS CODIGO FROM RDB$DATABASE';
            $resCodigo = DB::select($queryCodigo);
            $codigo = $resCodigo[0]->CODIGO;
        }

        $query = "UPDATE OR INSERT INTO HGASTOS (CODIGO, PROYECTO, GASTO, MEDIOCOBRO, FECHA, COMENTARIO, IMPORTE, VENDEDOR, PAGADO)
            VALUES (:codigo, 1, :gasto, :mediocobro, :fecha, :comentario, :importe, :vendedor, :pagado)
            MATCHING (CODIGO)";


        $bindings = [
            'codigo' => $codigo,
            'gasto' => $request->gasto,
            'mediocobro' => $request->mediocobro,
            'fecha' => $request->fecha,
            //Este campo no acepta acentos ni caracteres especiales aunque hayan pasado por el middleware
            'comentario' => UtilsHelper::removeAccentsV2($request->comentario),
            'importe' => $request->importe,
            'vendedor' => $request->vendedor,
            'pagado' => $request->pagado
        ];

        //return response()->json($bindings);
        //dd($bindings);

        $res = DB::insert($query, $bindings);
        if($res) return response()->json(['codigo' => $codigo]);
        else return response()->json(['msg' => 'Error'], 400);
    }
}
