<?php

namespace App\Http\Controllers\PSPOOL;

use App\Helpers\UtilsHelper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ClientesController extends Controller
{
    public function obtenerPorExpediente(Request $request)
    {
        $query = "SELECT C.ALIAS AS NOMBRE,C.CODIGO AS CODIGO, EC.COMENTARIO AS COMENTARIO
        FROM EXPEDIENTES_CLIENTES EC
        LEFT JOIN CLIENTES C ON C.CODIGO = EC.CLIENTE

        WHERE EC.EXPEDIENTE = ? ";

        $res = DB::select($query, [$request->expediente]);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function filtrarPorNombre(Request $request)
    {
        $parametros = [
            $request->comercial

        ];

        $query = "SELECT DISTINCT(clientes.*)
           FROM clientes
           LEFT JOIN VENDEDORES             ON VENDEDORES.CODIGO = ?
           LEFT JOIN DIRECCIONESCLIENTES    ON DIRECCIONESCLIENTES.CLIENTE = CLIENTES.CODIGO AND DIRECCIONESCLIENTES.DELEGACION = 'S'
           LEFT JOIN PROVINCIAS             ON DIRECCIONESCLIENTES.PROVINCIA = PROVINCIAS.DESCRIPCION OR CLIENTES.PROVINCIA = PROVINCIAS.DESCRIPCION
           LEFT JOIN COMERCIALES_PROVINCIAS ON PROVINCIAS.CODIGO = COMERCIALES_PROVINCIAS.PROVINCIA
            WHERE 0=0
            /*AND clientes.bloqueado = 'N'*/
            AND UPPER(clientes.descripcion) NOT LIKE 'USUARIO WEB --%'";


        if ($request->comercial != 0) {
            array_push(
                $parametros,
                $request->comercial,
                $request->comercial,
                $request->comercial,
                $request->comercial
            );
            $query .= " AND ((vendedor = ? )
            or ( ?> 100)
            or (VENDEDORES.ACCESO_TODOS_CLIENTES_TC = 'S')
            or (COMERCIALES_PROVINCIAS.COMERCIAL = ? )
            or (PROVINCIAS.COMERCIAL_ASIGNADO    = ? ))";
        }


        $query .= " AND ((cast(clientes.codigo as varchar(100)) = ?)
              OR (UPPER(clientes.descripcion) LIKE ? )
              OR (UPPER(clientes.alias)       LIKE ? )
              OR (UPPER(clientes.CIF)         LIKE ? ))";

        $filtroLike = '%' . strtoupper($request->filtro) . '%';
        array_push($parametros, $request->filtro, $filtroLike, $filtroLike, $filtroLike);

        if ($request->has('tipo') && $request->tipo != 999 && $request->tipo != "999" && !empty($request->tipo)) {
            array_push($parametros, $request->tipo);
            $query .= " AND TIPOCLIENTE = ?";
        }

        $query .= " ORDER BY descripcion";


        $res = DB::select(
            $query,
            $parametros
        );

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerDirecciones(Request $request)
    {
        $query = "SELECT DISTINCT d.LINEA, d.DIRECCION, d.PROVINCIA, d.DESCRIPCION_DIRECCION_CLIENTE as  descripcion,
                d.cliente, d.contacto, d.nombre, d.telefonofijo, d.fax, d.correo, d.telefonomovil, d.poblacion, d.cp, d.apcorreos
                from DIRECCIONESCLIENTES d
                left join provincias on d.provincia = provincias.descripcion
                where 0=0";

        if (!empty($request->comercial)) {
            $query .= " AND provincias.comercial_asignado = :comercial";
        }

        if (!empty($request->cliente)) {
            $query .= " AND d.cliente = :cliente ";
        }
        $query .= " ORDER BY 1";

        $res = DB::select($query, [
            'comercial' => $request->comercial,
            'cliente' => $request->cliente
        ]);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerTipos()
    {
        $query = "SELECT * FROM TIPOSCLIENTE ORDER BY CODIGO";
        $res = DB::select($query);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    //opciones ficha clientes
    public function obtenerCategorias()
    {
        $query = "select * from categoriasclientes where ((bloqueado='N') or (bloqueado is null)) order by descripcioncategoria";
        $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    //opciones ficha clientes

    public function obtenerTemasInteres()
    {
        $query = "select * from temas_interes_clientes where bloqueado = 'N' order by descripcion";
        $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerPorCodigo(Request $request)
    {
        $query = "SELECT DESCRIPCION, ALIAS, CP, CPENVIOMERCANCIA FROM CLIENTES WHERE CODIGO = ? AND CODIGO != 0";
        $res = DB::select($query, [$request->cliente]);
        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }


    public function obtenerCorreosRelacionados(Request $request)
    {
        $query = "SELECT CORREO FROM CLIENTES WHERE CODIGO = :cliente1
                UNION
                SELECT CORREO FROM CLIENTESCONTACTOS WHERE CLIENTE = :cliente2
                UNION
                SELECT CORREO FROM DIRECCIONESCLIENTES WHERE CLIENTE = :cliente3
                ";
        $bindings = [
            'cliente1' => $request->cliente,
            'cliente2' => $request->cliente,
            'cliente3' => $request->cliente
        ];

        $res = DB::select($query, $bindings);
        return response()->json(UtilsHelper::utf8ize($res));
    }


    public function calcularRiesgo(Request $request)
    {
        $query = "SELECT VENCICLI_NO_COBRADOS, VENCICLI_FECHA_LLEGAR, IMPORTE_TIQUETS_CERRADOS, RIESGO_DISPONIBLE
              FROM CALCULAR_RIESGO(:cliente, :fecha_hasta)";

        $res = DB::select($query, [
            'cliente' => $request->cliente,
            'fecha_hasta' => $request->fecha_hasta
        ]);

        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function obtenerDetalleFichaCliente(Request $request)
    {
        $query = "SELECT CLIENTES.CODIGO, CLIENTES.CIF, CLIENTES.DESCRIPCION AS DESCRIPCION, CLIENTES.ALIAS, CLIENTES.DIRECCION, CLIENTES.APCORREOS, CLIENTES.CP,
                   CLIENTES.POBLACION, CLIENTES.COMARCA, CLIENTES.PROVINCIA AS PROVINCIA, CLIENTES.PAIS, CLIENTES.TELEFONOFIJO, CLIENTES.TELEFONOMOVIL,
                   CLIENTES.FAX, CLIENTES.CORREO, CLIENTES.WEB, CLIENTES.BLOQUEADO, CLIENTES.FECHA_ALTA, CLIENTES.FORMADEPAGO, CLIENTES.BANCO, CLIENTES.TARIFA,
                   CLIENTES.DTO_GENERAL, CLIENTES.IMPUESTO, CLIENTES.DIRECCIONENVIOMERCANCIA, CLIENTES.CPENVIOMERCANCIA, CLIENTES.POBLACIONENVIOMERCANCIA,
                   CLIENTES.PROVINCIAENVIOMERCANCIA, CLIENTES.TELEFONOFIJOENVIOMERCANCIA, CLIENTES.TELEFONOMOVILENVIOMERCANCIA, CLIENTES.FECHA_ALTA,
                   CLIENTES.FECHA_ULTIMA_MODIFICACION, CLIENTES.FAXENVIOMERCANCIA, CLIENTES.CORREOENVIOMERCANCIA, CLIENTES.AGENCIAT, CLIENTES.NO_CREDITO,
                   CLIENTES.RIESGO, CLIENTES.COMENTARIO, CLIENTES.COMENTARIO_INTERNO_CLIENTE, CLIENTES.COMENTARIO_COMERCIAL_CLIENTE, CLIENTES.HORARIO,
                   CLIENTES.COMENTARIO_RIESGO, CLIENTES.COMENTARIO_BLOQUEADO_CLIENTE, CLIENTES.COMENTARIO_ALERTA_COMERCIAL, CLIENTES.LIBRE10_CLIENTE,
                   CLIENTES.TIPONACIONALIDAD,

                   V.NOMBRE AS USUARIO_ALTA,
                   V2.NOMBRE AS USUARIO_ULTIMA_MODIFICACION,
                   CATEGORIASCLIENTES.DESCRIPCIONCATEGORIA, CATEGORIASCLIENTES.CODIGO AS CODIGOCATEGORIA,
                   TIPOSCLIENTE.CODIGO AS CODIGOTIPO, TIPOSCLIENTE.DESCRIPCION AS DESCRIPCIONTIPO

              FROM CLIENTES
              LEFT JOIN CATEGORIASCLIENTES ON CLIENTES.CATEGORIA    = CATEGORIASCLIENTES.CODIGO
              LEFT JOIN PROVINCIAS		   ON CLIENTES.PROVINCIA    = PROVINCIAS.DESCRIPCION
              LEFT JOIN TIPOSCLIENTE       ON CLIENTES.TIPOCLIENTE  = TIPOSCLIENTE.CODIGO
              LEFT JOIN VENDEDORES V       ON CLIENTES.USUARIO_ALTA = V.CODIGO
              LEFT JOIN VENDEDORES V2      ON CLIENTES.USUARIO_ULTIMA_MODIFICACION = V2.CODIGO
             WHERE CLIENTES.CODIGO      = ?";

        $res = DB::select($query, [$request->cliente]);
        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function obtenerContactoPorDefecto(Request $request)
    {
        $query = "SELECT NOMBRE AS CONTACTO
              FROM CLIENTESCONTACTOS
             WHERE CLIENTE = ?
             ORDER BY CONTACTO_POR_DEFECTO DESC";

        $res = DB::select($query, [$request->codigo]);
        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function obtenerTemasInteresCliente(Request $request)
    {
        $query = "SELECT * FROM CLIENTES_TEMAS_INTERES WHERE CLIENTE = ? ";
        $res = DB::select($query, [$request->cliente]);
        return response()->json(UtilsHelper::utf8ize($res));
    }


    public function actualizarOCrear(Request $request)
    {
        //dd($request->all());
        //return response()->json(UtilsHelper::utf8ize($request->all()));

        //Si no hay código generarlo
        $codigo = $request->codigo;
        if ($codigo == 0 || empty($codigo)) {
            $queryObtenerCodigo = "SELECT GEN_ID(clientes_codigo_gen, 1) AS NUEVO_CODIGO FROM RDB\$DATABASE";
            $res = DB::select($queryObtenerCodigo);
            $codigo = $res[0]->NUEVO_CODIGO;
        }

        $provincia = strtoupper($request->provincia);

        $vendedor = null;
        // Consulta para obtener vendedor asignado y código de provincia
        $provinciaData = DB::select("
            SELECT COMERCIAL_ASIGNADO, CODIGO
            FROM PROVINCIAS
            WHERE UPPER(DESCRIPCION) = UPPER(?)", [$provincia]);

        if (!empty($provinciaData)) {
            $vendedor = $provinciaData[0]->COMERCIAL_ASIGNADO;
            $cProvincia = $provinciaData[0]->CODIGO;
        }


        // Si el vendedor asignado no es el comercial proporcionado, buscar en comerciales de la provincia
        if ($vendedor != $request->comercial) {
            $comerciales = DB::select("
                SELECT COMERCIAL
                FROM COMERCIALES_PROVINCIAS
                WHERE PROVINCIA = ?", [$cProvincia]);

            foreach ($comerciales as $com) {
                if ($com->COMERCIAL == $request->comercial) {
                    $vendedor = $request->comercial;
                    break;
                }
            }
        }

        if (empty($vendedor)) {
            $vendedor = "0";
        }

        //Obtener usuario alta-en el update llega el nombre, no el código
        if (is_int($request->usuario_alta)) $usuario_alta = $request->usuario_alta;
        else {
            $obtenerCodigoUsuarioQuery = "SELECT CODIGO FROM USUARIOS WHERE UPPER(NOMBRE) LIKE UPPER(?)";
            $resUsuario = DB::select($obtenerCodigoUsuarioQuery, [$request->usuario_alta]);
            $usuario_alta = count($resUsuario) > 0 ? $resUsuario[0]->CODIGO : $vendedor;
        }

        $query = "UPDATE OR INSERT INTO clientes (
            codigo, cif, categoria, tipocliente, descripcion, alias, direccion, apcorreos, cp, poblacion, comarca, provincia,
            pais, telefonofijo, telefonomovil, fax, correo, web, comentario_comercial_cliente, comentario_alerta_comercial, libre10_cliente,
            direccionenviomercancia, cpenviomercancia, poblacionenviomercancia, provinciaenviomercancia,
            telefonofijoenviomercancia, telefonomovilenviomercancia, faxenviomercancia, correoenviomercancia,
            vendedor, tarifa, formadepago, banco, libre5_cliente, USUARIO_ALTA, USUARIO_ULTIMA_MODIFICACION, TIPONACIONALIDAD, IMPUESTO
        ) VALUES (
            :codigo, :cif, :categoria, :tipocliente, :descripcion, :alias, :direccion, :apcorreos, :cp, :poblacion, :comarca, :provincia,
            :pais, :telefonofijo, :telefonomovil, :fax, :correo, :web, :comentario_comercial_cliente, :comentario_alerta_comercial, :libre10_cliente,
            :direccionenviomercancia, :cpenviomercancia, :poblacionenviomercancia, :provinciaenviomercancia,
            :telefonofijoenviomercancia, :telefonomovilenviomercancia, :faxenviomercancia, :correoenviomercancia,
            :vendedor, 0, 86, 10, :libre5_cliente, :usuario_alta, :usuario_ultima_modificacion, :tiponacionalidad, :impuesto
        ) MATCHING (codigo)";

        $bindings = [
            'codigo' => $codigo,
            'cif' => $request->cif,
            'categoria' => $request->categoria,
            'tipocliente' => $request->tipocliente,
            'descripcion' => $request->descripcion,
            'alias' => $request->alias,
            'direccion' => $request->direccion,
            'apcorreos' => $request->apcorreos,
            'cp' => $request->cp,
            'poblacion' => $request->poblacion,
            'comarca' => $request->comarca,
            'provincia' => $request->provincia,
            //si es nacional pais = españa
            'pais' => $request->es_extracomunitario == 'N' ? mb_convert_encoding('ESPAÑA', 'ISO-8859-15', 'UTF-8') : $request->pais,
            'telefonofijo' => $request->telefonofijo,
            'telefonomovil' => $request->telefonomovil,
            'fax' => $request->fax,
            'correo' => $request->correo,
            'web' => $request->web,
            'comentario_comercial_cliente' => $request->comentario_comercial_cliente,
            'comentario_alerta_comercial' => $request->comentario_alerta_comercial,
            'libre10_cliente' => $request->libre10_cliente,
            'direccionenviomercancia' => $request->direccionenviomercancia,
            'cpenviomercancia' => $request->cpenviomercancia,
            'poblacionenviomercancia' => $request->poblacionenviomercancia,
            'provinciaenviomercancia' => $request->provinciaenviomercancia,
            'telefonofijoenviomercancia' => $request->telefonofijoenviomercancia,
            'telefonomovilenviomercancia' => $request->telefonomovilenviomercancia,
            'faxenviomercancia' => $request->faxenviomercancia,
            'correoenviomercancia' => $request->correoenviomercancia,
            'vendedor' => $request->vendedor,
            'libre5_cliente' => $vendedor,
            'usuario_alta' => $usuario_alta,
            'usuario_ultima_modificacion' => $request->comercial,
            'tiponacionalidad' => $request->es_extracomunitario,
            'impuesto' => $request->impuesto
        ];

        $res = DB::select($query, $bindings);

        //TEMAS DE INTERÉS
        if ($request->has('temas_interes') && !empty($request->temas_interes)) {

            $temasInteres = explode(",", $request->temas_interes);

            // Eliminar todos los temas de interés actuales del cliente
            $sqlDelete = "DELETE FROM CLIENTES_TEMAS_INTERES WHERE CLIENTE = ?";
            DB::statement($sqlDelete, [$codigo]);

            // Insertar los nuevos temas de interés
            for ($i = 1; $i < count($temasInteres) - 1; $i++) {
                $sqlInsert = "
                    UPDATE OR INSERT INTO CLIENTES_TEMAS_INTERES (CLIENTE, TEMA_INTERES)
                    VALUES (?, ?)
                    MATCHING (CLIENTE, TEMA_INTERES)
                ";

                DB::statement($sqlInsert, [$codigo, $temasInteres[$i]]);
            }
        }

        //CONTACTO
        if ($request->has('contacto') && !empty($request->contacto)) {
            $contacto = $request->contacto;
            $tipoCliente = $request->tipocliente;


            // Obtener la descripción del tipo de cliente con una consulta SQL completa
            $sqlTipoCliente = "SELECT DESCRIPCION FROM tiposcliente WHERE codigo = ?";
            $tipoClienteResult = DB::select($sqlTipoCliente, [$tipoCliente]);

            // Verificar si se obtuvo la descripción
            $descripcionTipoCliente = count($tipoClienteResult) > 0 ? $tipoClienteResult[0]->DESCRIPCION : '';

            // Buscar si ya existe la línea del contacto
            $sqlLinea = "SELECT LINEA FROM CLIENTESCONTACTOS WHERE CLIENTE = ? AND NOMBRE = ?";
            $lineaResult = DB::select($sqlLinea, [$codigo, $contacto]);

            $linea = count($lineaResult) > 0 ? $lineaResult[0]->LINEA : 0;

            // Consulta para actualizar o insertar el contacto
            $sqlUpsert = "
                UPDATE OR INSERT INTO CLIENTESCONTACTOS
                (LINEA, CLIENTE, NOMBRE, COMENTARIO_CONTACTO)
                VALUES (?, ?, ?, ?)
                MATCHING(CLIENTE, LINEA, NOMBRE)
            ";

            // Ejecutar la consulta
            DB::select($sqlUpsert, [$linea, $codigo, $contacto, $descripcionTipoCliente]);
        }

        return response()->json(['codigo' => $codigo]);
    }

    public function obtenerHorarios(Request $request)
    {
        $query = "SELECT LINEA, DESCRIPCION, DESDE_DIA, HASTA_DIA
              FROM CLIENTES_TEMPORADAS
                 WHERE CLIENTE = ?";

        $res = DB::select($query, [$request->cliente]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerContactos(Request $request)
    {
        $query = "SELECT NOMBRE, LINEA
           FROM CLIENTESCONTACTOS
          WHERE NOMBRE <> ''";

        if (!empty($request->cliente) && $request->cliente != "0" && $request->cliente != 0) {
            $query .= " AND CLIENTE = ?";
        }

        $query .= " GROUP BY NOMBRE, LINEA ORDER BY LINEA DESC";
        $res = DB::select($query, [$request->cliente]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function borrarHorario(Request $request)
    {
        $query = "DELETE FROM CLIENTES_TEMPORADAS
         WHERE CLIENTE = ?
           AND LINEA   = ?";

        $res = DB::select($query, [$request->cliente, $request->linea]);
        return response()->json(['msg' => 'Registro borrado']);
    }


    public function crearActualizarHorario(Request $request)
    {

        //Si no hay linea calcularla
        $linea = $request->linea;
        if (empty($linea)) {

            $queryObtenerLinea = "SELECT MAX(LINEA) + 1 AS NUEVA_LINEA FROM CLIENTES_TEMPORADAS WHERE CLIENTE = :cliente";
            $resLinea = DB::select($queryObtenerLinea, [$request->cliente]);
            if (empty($resLinea) || empty($resLinea[0]) || empty($resLinea[0]->NUEVA_LINEA)) {
                $linea = 1;
            } else $linea = $resLinea[0]->NUEVA_LINEA;
        }


        $query = "UPDATE OR INSERT INTO CLIENTES_TEMPORADAS
            (CLIENTE, LINEA, DESCRIPCION, DESDE_DIA, HASTA_DIA)
        VALUES
            (:cliente, :linea, :descripcion, :desde, :hasta)
        MATCHING (CLIENTE, LINEA)";


        $bindings = [
            'cliente' => $request->cliente,
            'linea' => $linea,
            'descripcion' => $request->descripcion,
            'desde' => $request->desde,
            'hasta' => $request->hasta,
        ];

        $res = DB::select($query, $bindings);
        return response()->json(['msg' => 'Registro modificado']);
    }

    public function obtenerHorasHorario(Request $request)
    {
        $cliente = $request->cliente;
        $linea = $request->linea;

        $query = "SELECT DESDE_HORA, HASTA_HORA
                FROM CLIENTES_HORARIO_TEMPORADA
                WHERE CLIENTE = :cliente
                    AND LINEA = :linea";

        // Bindings array
        $bindings = [
            ':cliente' => $cliente,
            ':linea' => $linea
        ];

        // Execute the query with bindings
        $results = DB::select($query, $bindings);
        return response()->json(UtilsHelper::utf8ize($results));
    }

    public function borrarHorasHorario(Request $request)
    {

        $cliente = $request->cliente;
        $linea = $request->linea;
        $desde = $request->desde;

        $query = "DELETE FROM CLIENTES_HORARIO_TEMPORADA
                WHERE CLIENTE = :cliente
                    AND LINEA = :linea
                    AND DESDE_HORA = :desde";

        $bindings = [
            ':cliente' => $cliente,
            ':linea' => $linea,
            ':desde' => $desde,
        ];

        DB::select($query, $bindings);

        return response()->json(['msg' => 'Registro eliminado']);
    }

    public function grabarHorasHorario(Request $request)
    {
        $cliente = $request->cliente;
        $linea = $request->linea;
        $desde = $request->desde;
        $hasta = $request->hasta;

        $query = "INSERT INTO CLIENTES_HORARIO_TEMPORADA (CLIENTE, LINEA, DESDE_HORA, HASTA_HORA)
                VALUES (:cliente, :linea, :desde, :hasta)";


        $bindings = [
            ':cliente' => $cliente,
            ':linea' => $linea,
            ':desde' => $desde,
            ':hasta' => $hasta
        ];


        DB::select($query, $bindings);
        return response()->json(['msg' => 'Registro creado']);
    }

    //Obtener nombres de datos :tarifa, banco... para la ficha de cliente
    public function obtenerInfoDatosFiscales(Request $request)
    {
        $query = "SELECT descripcion  FROM formaspago WHERE codigo = :formaPago
        UNION
        SELECT descripcion FROM bancos WHERE codigo = :banco
        UNION
        SELECT descripcion   FROM tarifas WHERE codigo = :tarifa
        UNION
        SELECT iva FROM impuestos WHERE codigo = :impuesto
        UNION
        SELECT descripcion FROM agenciat WHERE codigo = :agenciat";

        $res = DB::select($query, [
            'formaPago' => $request->formaPago,
            'banco' => $request->banco,
            'tarifa' => $request->tarifa,
            'impuesto' => $request->impuesto,
            'agenciat' => $request->agenciat
        ]);
        //dd($res);
        $nombresDatos = ['formaPago', 'banco', 'tarifa', 'impuesto', 'agenciat'];
        $formaPago = DB::select("SELECT descripcion FROM formaspago WHERE codigo = ?", [$request->formaPago]);
        $banco = DB::select("SELECT descripcion FROM bancos WHERE codigo = ?", [$request->banco]);
        $tarifa = DB::select("SELECT descripcion FROM tarifas WHERE codigo = ?", [$request->tarifa]);
        $impuesto = DB::select("SELECT iva FROM impuestos WHERE codigo = ?", [$request->impuesto]);
        $agenciat = DB::select("SELECT descripcion FROM agenciat WHERE codigo = ?", [$request->agenciat]);

        $arrayRes = [
            'formaPago' => count($formaPago) > 0 ? $formaPago[0]->DESCRIPCION : null,
            'banco' => count($banco) > 0 ? $banco[0]->DESCRIPCION : null,
            'tarifa' => count($tarifa) > 0 ? $tarifa[0]->DESCRIPCION : null,
            'impuesto' => count($impuesto) > 0 ? $impuesto[0]->IVA : null,
            'agenciat' => count($agenciat) > 0 ? $agenciat[0]->DESCRIPCION : null,
        ];

        return response()->json(UtilsHelper::utf8ize($arrayRes));
    }
}
