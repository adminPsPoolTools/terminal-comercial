<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class DireccionesController extends Controller
{
    public function obtenerDireccionesPorClienteExpediente(Request $request)
    {
        if(!empty($request->expediente) && "" == $request->expediente &&  !empty($request->nombre) && '' != $request->nombre){
            $query    = "select * from direccionesclientes where cliente = :cliente order by linea";

        }else if("0" != $request->linea && "" != $request->linea && 0 != $request->linea){

            $query  = "select * from direccionesexpedientes where expediente = :expediente order by linea";

        }

        $res = DB::select($query, [
            'cliente' => $request->cliente,
            'expediente' => $request->expediente,
        ]);


        return response()->json(UtilsHelper::utf8ize($res));
    }


    public function crearActualizarDireccion(Request $request)
    {
        $linea = $request->linea;
        //comprobar si existe el registro para actualizar o crear
        $queryBuscarRegistro = "SELECT *
          FROM direccionesclientes
          WHERE cliente = :cliente
          AND linea = :linea";

        $bindingsBuscarRegistro = [
            'cliente' => $request->cliente,
            'linea' => $request->linea
        ];


        $resBuscarRegistro = DB::select($queryBuscarRegistro, $bindingsBuscarRegistro);

        //si existe actualizar
        if(count($resBuscarRegistro) > 0)
        {
            $queryUpdate = "UPDATE direccionesclientes
                SET direccion = :direccion,
                    poblacion = :poblacion,
                    cp = :cp,
                    provincia = :provincia,
                    telefonofijo = :telefonofijo,
                    fax = :fax,
                    correo = :correo,
                    telefonomovil = :telefonomovil,
                    nombre = :nombre,
                    contacto = :contacto,
                    apcorreos = :apcorreos,
                    DESCRIPCION_DIRECCION_CLIENTE = :descripcion,
                    PAIS_DIRECCIONES_CLIENTES = :pais
                WHERE cliente = :cliente
                AND linea = :linea";

            $bindingsUpdate = [
                'direccion'  => $request->direccion,
                'poblacion'  => $request->poblacion,
                'cp'         => $request->cp,
                'provincia'  => $request->provincia,
                'telefonofijo' => $request->telefonofijo,
                'fax'        => $request->fax,
                'correo'     => $request->correo,
                'telefonomovil' => $request->telefonomovil,
                'nombre'     => $request->nombre,
                'contacto'   => $request->contacto,
                'apcorreos'  => $request->apcorreos,
                'descripcion' => $request->descripcion,
                'cliente'    => $request->cliente,
                'linea'      => $request->linea,
                'pais' =>       !empty($request->pais) ? $request->pais : mb_convert_encoding('ESPAÑA', 'ISO-8859-1', 'UTF-8')
            ];

            $res = DB::select($queryUpdate, $bindingsUpdate);

            //return response()->json(['msg' => 'Registro modificado']);
        }
        else
        {

            //obtener numero de linea para insertar
            $queryObtenerLinea = "SELECT MAX(LINEA) + 1 AS NUEVA_LINEA FROM DIRECCIONESCLIENTES WHERE CLIENTE = :cliente" ;
            $resLinea = DB::select($queryObtenerLinea, [$request->cliente]);
            if(empty($resLinea) || empty($resLinea[0]) || empty($resLinea[0]->NUEVA_LINEA))
            {
                $linea = 1;
            }
            else $linea = $resLinea[0]->NUEVA_LINEA;
            //dd($resLinea);

            $queryInsert = "INSERT INTO direccionesclientes (
                CLIENTE, linea, direccion, poblacion, cp, provincia, telefonofijo, fax,
                correo, telefonomovil, nombre, contacto, descripcion_direccion_cliente, apcorreos, PAIS_DIRECCIONES_CLIENTES
              ) VALUES (
                :cliente, :linea, :direccion, :poblacion, :cp, :provincia, :telefonofijo, :fax,
                :correo, :telefonomovil, :nombre, :contacto, :descripcion, :apcorreos, :pais
              )";

            $bindingsInsert = [
                'cliente'       => $request->cliente,
                'linea'         => $linea,
                'direccion'     => $request->direccion,
                'poblacion'     => $request->poblacion,
                'cp'            => $request->cp,
                'provincia'     => $request->provincia,
                'telefonofijo'  => $request->telefonofijo,
                'fax'           => $request->fax,
                'correo'        => $request->correo,
                'telefonomovil' => $request->telefonomovil,
                'nombre'        => $request->nombre,
                'contacto'      => $request->contacto,
                'descripcion'   => $request->descripcion,
                'apcorreos'     => $request->apcorreos,
                'pais'          => !empty($request->pais) ? $request->pais : mb_convert_encoding('ESPAÑA', 'ISO-8859-1', 'UTF-8')
            ];

            $res = DB::select($queryInsert, $bindingsInsert);


        }

        return response()->json(['linea' => $linea]);
    }

    public function crearActualizarDireccionExpediente(Request $request)
    {
        //comprobar si existe el registro para actualizar o crear
        $queryBuscarRegistro = "SELECT *
          FROM direccionesexpedientes
          WHERE cliente = :cliente
          AND linea = :linea";

        $bindingsBuscarRegistro = [
            'cliente' => $request->cliente,
            'linea' => $request->linea
        ];


        $resBuscarRegistro = DB::select($queryBuscarRegistro, $bindingsBuscarRegistro);
        dd($resBuscarRegistro);
        //si existe actualizar
        if(count($resBuscarRegistro) > 0)
        {

            $queryUpdate = "UPDATE direccionesexpedientes
                SET direccion = :direccion,
                    poblacion = :poblacion,
                    cp = :cp,
                    provincia = :provincia,
                    telefonofijo = :telefonofijo,
                    fax = :fax,
                    correo = :correo,
                    telefonomovil = :telefonomovil,
                    nombre = :nombre,
                    contacto = :contacto,
                    apcorreos = :apcorreos,
                    DESCRIPCION_DIRECCION_CLIENTE = :descripcion,
                    PAIS_DIRECCIONES_CLIENTES = :pais
                WHERE expediente = :expediente
                AND linea = :linea";

            $bindingsUpdate = [
                'direccion'  => $request->direccion,
                'poblacion'  => $request->poblacion,
                'cp'         => $request->cp,
                'provincia'  => $request->provincia,
                'telefonofijo' => $request->telefonofijo,
                'fax'        => $request->fax,
                'correo'     => $request->correo,
                'telefonomovil' => $request->telefonomovil,
                'nombre'     => $request->nombre,
                'contacto'   => $request->contacto,
                'apcorreos'  => $request->apcorreos,
                'descripcion' => $request->descripcion,
                'expediente'    => $request->expediente,
                'linea'      => $request->linea,
                'pais' =>       !empty($request->pais) ? $request->pais : mb_convert_encoding('ESPAÑA', 'ISO-8859-1', 'UTF-8')
            ];

            $res = DB::select($queryUpdate, $bindingsUpdate);

            return response()->json(['msg' => 'Registro modificado']);
        }
        else
        {

            //obtener numero de linea para insertar
            $queryObtenerLinea = "SELECT MAX(LINEA) + 1 AS NUEVA_LINEA FROM direccionesexpedientes WHERE CLIENTE = :cliente" ;
            $resLinea = DB::select($queryObtenerLinea, [$request->cliente]);

            $queryInsert = "INSERT INTO direccionesexpedientes (
                 linea, direccion, poblacion, cp, provincia, telefonofijo, fax,
                correo, telefonomovil, nombre, contacto, descripcion_direccion_cliente, apcorreos, expediente, PAIS_DIRECCIONES_CLIENTES
              ) VALUES (
                 :linea, :direccion, :poblacion, :cp, :provincia, :telefonofijo, :fax,
                :correo, :telefonomovil, :nombre, :contacto, :descripcion, :apcorreos, :expediente, :pais
              )";

            $bindingsInsert = [
                'expediente'       => $request->expediente,
                'linea'         => $resLinea[0]->NUEVA_LINEA,
                'direccion'     => $request->direccion,
                'poblacion'     => $request->poblacion,
                'cp'            => $request->cp,
                'provincia'     => $request->provincia,
                'telefonofijo'  => $request->telefonofijo,
                'fax'           => $request->fax,
                'correo'        => $request->correo,
                'telefonomovil' => $request->telefonomovil,
                'nombre'        => $request->nombre,
                'contacto'      => $request->contacto,
                'descripcion'   => $request->descripcion,
                'apcorreos'     => $request->apcorreos,
                'pais' =>       !empty($request->pais) ? $request->pais : mb_convert_encoding('ESPAÑA', 'ISO-8859-1', 'UTF-8')
            ];

            $res = DB::select($queryInsert, $bindingsInsert);

            return response()->json(['msg' => 'Registro creado']);
        }


    }

    public function borrarDireccionCliente(Request $request)
    {
        $query = "DELETE
		 FROM direccionesclientes
		 WHERE CLIENTE = :cliente
		   AND linea  = :linea";

        DB::select($query, ['cliente' => $request->cliente, 'linea' => $request->linea]);
        return response()->json(['msg' => 'Registro eliminado']);
    }

    public function obtenerDetalleDireccionCliente(Request $request)
    {
        if(empty($request->expediente)){
            $query = "SELECT D.DIRECCION, D.POBLACION, D.CP, D.TELEFONOFIJO, D.FAX, D.CORREO, D.TELEFONOMOVIL, D.NOMBRE, D.CONTACTO, D.APCORREOS, D.PAIS_DIRECCIONES_CLIENTES,
            PROVINCIAS.CODIGO AS PROVINCIA, D.DESCRIPCION_DIRECCION_CLIENTE AS DESCRIPCION
            FROM direccionesclientes D
            LEFT JOIN PROVINCIAS ON PROVINCIAS.DESCRIPCION = D.PROVINCIA
            WHERE D.cliente = :cliente
            AND D.linea   = :linea";

            $res = DB::select($query, ['cliente' => $request->cliente, 'linea' => $request->linea]);
            //return response()->json(UtilsHelper::utf8ize($res));
        }
        else if(!empty($request->linea) && "" != $request->linea && "0" != $request->linea && 0 != $request->linea){
            $query = "SELECT * FROM direccionesexpedientes
                WHERE expediente = :expediente
                  AND linea   = :linea " ;

           $res = DB::select($query, ['expediente' => $request->expediente, 'linea' => $request->linea]);

        }

        return response()->json(UtilsHelper::utf8ize($res[0]));

    }

    public function obtenerPorClienteYLinea(Request $request)
    {
        $sql = "SELECT *
            FROM DIRECCIONESCLIENTES
            WHERE CLIENTE = :cliente
              AND LINEA = :linea";

        $bindings = [
            'cliente' => $request->cliente,
            'linea' => $request->linea
        ];

        $result = DB::select($sql, $bindings);
        $res = count($result) > 0 ? $result[0] : null;
        return response()->json(UtilsHelper::utf8ize($res));
    }

}
