<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class LoginController extends Controller
{
    //Entrar a panel Recursos Humanos
    public function loginEmpleados(Request $request)
    {
        $query = "SELECT NOMBRE, PASSWORD FROM empleados WHERE codigo = ? ";
        $res = DB::connection('recursosHumanos')->select($query, [$request->comercial]);
        $empleado = count($res) > 0 ? $res[0] : null;
        return response()->json(UtilsHelper::utf8ize($empleado));
    }

    public function loginVendedores(Request $request)
    {
        $query = 'SELECT * FROM vendedores WHERE codigo = ?';
        $res = DB::select($query, [$request->comercial]);
        $empleado = count($res) > 0 ? $res[0] : null;
        return response()->json(UtilsHelper::utf8ize($empleado));
    }
}
