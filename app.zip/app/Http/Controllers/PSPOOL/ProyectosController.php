<?php

namespace App\Http\Controllers\PSPOOL;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProyectosController extends Controller
{
    public function obtenerOpcionesSolicitudPresupuesto()
    {
        $sql = "SELECT CODIGO, DESCRIPCION
                FROM PROYECTOS
                WHERE UPPER(DESCRIPCION) LIKE 'PS_POOL'
                OR UPPER(DESCRIPCION) LIKE 'PS_COVER'
                OR UPPER(DESCRIPCION) LIKE 'PS_WATER'";
        $res = DB::select($sql);
        
        return response()->json(UtilsHelper::utf8ize($res));
    }
}
