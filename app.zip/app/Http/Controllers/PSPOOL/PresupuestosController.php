<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

use App\Helpers\UtilsHelper;

class PresupuestosController extends Controller
{
    public function obtenerPorExpediente(Request $request)
    {
        $query = "SELECT codigo, titulo, fecha
          FROM presupuestos
         WHERE expediente = :expediente
           AND COALESCE(BASE_EN_EXPEDIENTE, 'N') = 'S'
         ORDER BY CODIGO DESC";

        $res = DB::select($query, ['expediente' => $request->expediente]);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerPresupuestosFichaCliente(Request $request)
    {
        $sql = "SELECT presupuestos.codigo, presupuestos.fecha, presupuestos.titulo,presupuestos.estado, presupuestos.baseimponible, presupuestos.total, clientes.descripcion as descripcion_cliente,
               VALTA.NOMBRE AS USUARIO_ALTA, presupuestos.presupuesto, presupuestos.presupuestod,  com.nombre as comercial,

            CASE
            WHEN
                presupuestos.estado = 'Aceptado'
                OR P_PADRE1.ESTADO = 'Aceptado'
                OR P_PADRE2.ESTADO = 'Aceptado'
                OR P_PADRE3.ESTADO = 'Aceptado'
                OR P_PADRE4.ESTADO = 'Aceptado'
            OR P_PADRE5.ESTADO = 'Aceptado'
            OR P_PADRE6.ESTADO = 'Aceptado'
                OR P_HIJO1.ESTADO = 'Aceptado'
                OR P_HIJO2.ESTADO = 'Aceptado'
                OR P_HIJO3.ESTADO = 'Aceptado'
                OR P_HIJO4.ESTADO = 'Aceptado'
                OR P_HIJO5.ESTADO = 'Aceptado'
                OR P_HIJO6.ESTADO = 'Aceptado'
            THEN 'SI'
            ELSE 'NO'

          END AS PRESUPUESTO_ACEPTADO

          FROM presupuestos
          LEFT JOIN clientes                ON presupuestos.cliente = clientes.codigo
          LEFT JOIN VENDEDORES com ON com.codigo = clientes.vendedor
          LEFT JOIN VENDEDORES VALTA        ON VALTA.CODIGO = presupuestos.VENDEDOR
          LEFT JOIN VENDEDORES              ON VENDEDORES.CODIGO = :comercial
          LEFT JOIN SOLICITUD_PRESUPUESTO   ON presupuestos.solicitud = SOLICITUD_PRESUPUESTO.CODIGO

            LEFT JOIN PRESUPUESTOS P_PADRE1
                ON P_PADRE1.CODIGO = presupuestos.PRESUPUESTO

            LEFT JOIN PRESUPUESTOS P_PADRE2
                ON P_PADRE2.CODIGO = P_PADRE1.PRESUPUESTO

            LEFT JOIN PRESUPUESTOS P_PADRE3
                ON P_PADRE3.CODIGO = P_PADRE2.PRESUPUESTO

            LEFT JOIN PRESUPUESTOS P_PADRE4
                ON P_PADRE4.CODIGO = P_PADRE3.PRESUPUESTO

            LEFT JOIN PRESUPUESTOS P_PADRE5
                ON P_PADRE5.CODIGO = P_PADRE4.PRESUPUESTO

            LEFT JOIN PRESUPUESTOS P_PADRE6
                ON P_PADRE6.CODIGO = P_PADRE5.PRESUPUESTO


            LEFT JOIN PRESUPUESTOS P_HIJO1
                ON P_HIJO1.CODIGO = presupuestos.PRESUPUESTOD

            LEFT JOIN PRESUPUESTOS P_HIJO2
                ON P_HIJO2.CODIGO = P_HIJO1.PRESUPUESTOD

            LEFT JOIN PRESUPUESTOS P_HIJO3
                ON P_HIJO3.CODIGO = P_HIJO2.PRESUPUESTOD

            LEFT JOIN PRESUPUESTOS P_HIJO4
                ON P_HIJO4.CODIGO = P_HIJO3.PRESUPUESTOD

            LEFT JOIN PRESUPUESTOS P_HIJO5
                ON P_HIJO5.CODIGO = P_HIJO4.PRESUPUESTOD

            LEFT JOIN PRESUPUESTOS P_HIJO6
                ON P_HIJO6.CODIGO = P_HIJO5.PRESUPUESTOD


         WHERE presupuestos.fecha between :fecha_desde and :fecha_hasta
           and ((clientes.vendedor = :comercial3)
                or (:comercial1 = 1)
                or (:comercial2 > 100)
                or (VENDEDORES.ACCESO_TODOS_CLIENTES_TC = 'S'))";

        $bindings = [
            'comercial' => $request->comercial,
            'comercial1' => $request->comercial,
            'comercial2' => $request->comercial,
            'comercial3' => $request->comercial,
            'fecha_desde' => $request->fecha_desde,
            'fecha_hasta' => $request->fecha_hasta
        ];

        if (!empty($request->cliente)) {
            $sql .= " and presupuestos.cliente = :cliente";
            $bindings['cliente'] = $request->cliente;
        }
        if (!empty($request->titulo)) {
            $sql .= " and upper(presupuestos.titulo) like :titulo";
            $bindings['titulo'] = "%" . strtoupper($request->titulo) . "%";
        }
        if (!empty($request->estado) && $request->estado !== "Todos") {

            $estado = urldecode(trim($request->estado));

            $partes = explode(' ', $estado, 2);
            $primeraPalabra = $partes[0];

            $sql .= " and presupuestos.estado LIKE :estado";
            $bindings['estado'] = $primeraPalabra . '%';
        }

        if (!empty($request->proyecto) && $request->proyecto !== "0") {
            $sql .= " and presupuestos.proyecto = :proyecto";
            $bindings['proyecto'] = $request->proyecto;
        }
        if (!empty($request->caracter) && $request->caracter !== "0") {
            $sql .= " and SOLICITUD_PRESUPUESTO.CARACTER = :caracter";
            $bindings['caracter'] = $request->caracter;
        }
        if (!empty($request->desc_articulo)) {
            $sql .= " and presupuestos.codigo in (SELECT presupuesto
                    FROM linpresu
                    WHERE linpresu.articulo in (SELECT codigo
                    FROM ARTICULOS
                    WHERE UPPER(DESCRIPCION) LIKE UPPER(:desc_articulo))
                    OR linpresu.articulo like :desc_articulo_like)";
            $bindings['desc_articulo'] = '%' . strtoupper($request->desc_articulo) . '%';
            $bindings['desc_articulo_like'] = '%' . $request->desc_articulo . '%';
        }

        if ((!empty($request->provincia)) && ($request->provincia != "")) {
            $sql_aux = "SELECT descripcion from provincias
                        where codigo = ?";
            $res_aux = DB::select($sql_aux, [$request->provincia]);
            $row_aux = $res_aux[0];
            $bindings['provincia_desc'] = $row_aux->DESCRIPCION;
            $sql .= " and trim(clientes.provincia) = :provincia_desc";
        }

        if ((!empty($request->poblacion)) && ($request->poblacion != "null") && ($request->poblacion <> "Todas") && ($request->provincia != "null")) {
            $sql_aux = "SELECT descripcion from poblaciones
                        where codigo = ?";
            $res_aux = DB::select($sql_aux, [$request->poblacion]);
            $row_aux = $res_aux[0];
            $bindings['poblacion_desc'] = $row_aux->DESCRIPCION;
            $sql .= " and trim(clientes.poblacion) = :poblacion_desc";
        }

        $sql .= " ORDER BY ";

        switch ($request->orden) {
            case 'fecha':
                $sql .= "presupuestos.fecha";
                break;

            case 'cliente':
                $sql .= "clientes.descripcion";
                break;

            case 'vendedor':
                $sql .= "VALTA.NOMBRE";
                break;

            case 'base_imp':
                $sql .= "presupuestos.baseimponible";
                break;

            case 'imp_c_iva':
                $sql .= "presupuestos.total";
                break;

            case 'titulo':
                $sql .= "presupuestos.titulo";
                break;

            case 'codigo':
            default:
                $sql .= "presupuestos.codigo";
                break;
        }

        $sql .= " " . $request->orden_ori;

        $res = DB::select($sql, $bindings);


        return response()->json(UtilsHelper::utf8ize($res));
    }
    public function obtenerTrazaPresupuestosClientes(Request $request)
    {
        $sql = "SELECT
    TRIM(
        CASE WHEN presupuestos.SOLICITUD IS NOT NULL
            THEN 'SOL:' || CAST(presupuestos.SOLICITUD AS VARCHAR(20)) || ' > '
            ELSE ''
        END ||

        COALESCE(CAST(P_PADRE6.CODIGO AS VARCHAR(20)) ||
            CASE WHEN P_PADRE6.PEDIDO > 0
                THEN '(P:' || CAST(P_PADRE6.PEDIDO AS VARCHAR(20)) ||
                     CASE WHEN TIQ_PADRE6.CODIGO IS NOT NULL THEN '/A:' || CAST(CAST(TIQ_PADRE6.CODIGO AS BIGINT) AS VARCHAR(20)) ELSE '' END || ')'
                ELSE '' END || ' > ', '') ||

        COALESCE(CAST(P_PADRE5.CODIGO AS VARCHAR(20)) ||
            CASE WHEN P_PADRE5.PEDIDO > 0
                THEN '(P:' || CAST(P_PADRE5.PEDIDO AS VARCHAR(20)) ||
                     CASE WHEN TIQ_PADRE5.CODIGO IS NOT NULL THEN '/A:' || CAST(CAST(TIQ_PADRE5.CODIGO AS BIGINT) AS VARCHAR(20)) ELSE '' END || ')'
                ELSE '' END || ' > ', '') ||

        COALESCE(CAST(P_PADRE4.CODIGO AS VARCHAR(20)) ||
            CASE WHEN P_PADRE4.PEDIDO > 0
                THEN '(P:' || CAST(P_PADRE4.PEDIDO AS VARCHAR(20)) ||
                     CASE WHEN TIQ_PADRE4.CODIGO IS NOT NULL THEN '/A:' || CAST(CAST(TIQ_PADRE4.CODIGO AS BIGINT) AS VARCHAR(20)) ELSE '' END || ')'
                ELSE '' END || ' > ', '') ||

        COALESCE(CAST(P_PADRE3.CODIGO AS VARCHAR(20)) ||
            CASE WHEN P_PADRE3.PEDIDO > 0
                THEN '(P:' || CAST(P_PADRE3.PEDIDO AS VARCHAR(20)) ||
                     CASE WHEN TIQ_PADRE3.CODIGO IS NOT NULL THEN '/A:' || CAST(CAST(TIQ_PADRE3.CODIGO AS BIGINT) AS VARCHAR(20)) ELSE '' END || ')'
                ELSE '' END || ' > ', '') ||

        COALESCE(CAST(P_PADRE2.CODIGO AS VARCHAR(20)) ||
            CASE WHEN P_PADRE2.PEDIDO > 0
                THEN '(P:' || CAST(P_PADRE2.PEDIDO AS VARCHAR(20)) ||
                     CASE WHEN TIQ_PADRE2.CODIGO IS NOT NULL THEN '/A:' || CAST(CAST(TIQ_PADRE2.CODIGO AS BIGINT) AS VARCHAR(20)) ELSE '' END || ')'
                ELSE '' END || ' > ', '') ||

        COALESCE(CAST(P_PADRE1.CODIGO AS VARCHAR(20)) ||
            CASE WHEN P_PADRE1.PEDIDO > 0
                THEN '(P:' || CAST(P_PADRE1.PEDIDO AS VARCHAR(20)) ||
                     CASE WHEN TIQ_PADRE1.CODIGO IS NOT NULL THEN '/A:' || CAST(CAST(TIQ_PADRE1.CODIGO AS BIGINT) AS VARCHAR(20)) ELSE '' END || ')'
                ELSE '' END || ' > ', '') ||

        '[' || CAST(presupuestos.CODIGO AS VARCHAR(20)) || ']' ||
            CASE WHEN presupuestos.PEDIDO > 0
                THEN '(P:' || CAST(presupuestos.PEDIDO AS VARCHAR(20)) ||
                     CASE WHEN TIQ_ACTUAL.CODIGO IS NOT NULL THEN '/A:' || CAST(CAST(TIQ_ACTUAL.CODIGO AS BIGINT) AS VARCHAR(20)) ELSE '' END || ')'
                ELSE ''
            END ||

        COALESCE(' > ' || CAST(P_HIJO1.CODIGO AS VARCHAR(20)) ||
            CASE WHEN P_HIJO1.PEDIDO > 0
                THEN '(P:' || CAST(P_HIJO1.PEDIDO AS VARCHAR(20)) ||
                     CASE WHEN TIQ_HIJO1.CODIGO IS NOT NULL THEN '/A:' || CAST(CAST(TIQ_HIJO1.CODIGO AS BIGINT) AS VARCHAR(20)) ELSE '' END || ')'
                ELSE '' END, '') ||

        COALESCE(' > ' || CAST(P_HIJO2.CODIGO AS VARCHAR(20)) ||
            CASE WHEN P_HIJO2.PEDIDO > 0
                THEN '(P:' || CAST(P_HIJO2.PEDIDO AS VARCHAR(20)) ||
                     CASE WHEN TIQ_HIJO2.CODIGO IS NOT NULL THEN '/A:' || CAST(CAST(TIQ_HIJO2.CODIGO AS BIGINT) AS VARCHAR(20)) ELSE '' END || ')'
                ELSE '' END, '') ||

        COALESCE(' > ' || CAST(P_HIJO3.CODIGO AS VARCHAR(20)) ||
            CASE WHEN P_HIJO3.PEDIDO > 0
                THEN '(P:' || CAST(P_HIJO3.PEDIDO AS VARCHAR(20)) ||
                     CASE WHEN TIQ_HIJO3.CODIGO IS NOT NULL THEN '/A:' || CAST(CAST(TIQ_HIJO3.CODIGO AS BIGINT) AS VARCHAR(20)) ELSE '' END || ')'
                ELSE '' END, '') ||

        COALESCE(' > ' || CAST(P_HIJO4.CODIGO AS VARCHAR(20)) ||
            CASE WHEN P_HIJO4.PEDIDO > 0
                THEN '(P:' || CAST(P_HIJO4.PEDIDO AS VARCHAR(20)) ||
                     CASE WHEN TIQ_HIJO4.CODIGO IS NOT NULL THEN '/A:' || CAST(CAST(TIQ_HIJO4.CODIGO AS BIGINT) AS VARCHAR(20)) ELSE '' END || ')'
                ELSE '' END, '') ||

        COALESCE(' > ' || CAST(P_HIJO5.CODIGO AS VARCHAR(20)) ||
            CASE WHEN P_HIJO5.PEDIDO > 0
                THEN '(P:' || CAST(P_HIJO5.PEDIDO AS VARCHAR(20)) ||
                     CASE WHEN TIQ_HIJO5.CODIGO IS NOT NULL THEN '/A:' || CAST(CAST(TIQ_HIJO5.CODIGO AS BIGINT) AS VARCHAR(20)) ELSE '' END || ')'
                ELSE '' END, '') ||

        COALESCE(' > ' || CAST(P_HIJO6.CODIGO AS VARCHAR(20)) ||
            CASE WHEN P_HIJO6.PEDIDO > 0
                THEN '(P:' || CAST(P_HIJO6.PEDIDO AS VARCHAR(20)) ||
                     CASE WHEN TIQ_HIJO6.CODIGO IS NOT NULL THEN '/A:' || CAST(CAST(TIQ_HIJO6.CODIGO AS BIGINT) AS VARCHAR(20)) ELSE '' END || ')'
                ELSE '' END, '')

    ) AS TRAZA_COMPLETA,

    (
        CASE WHEN presupuestos.PEDIDO > 0 THEN 1 ELSE 0 END +
        CASE WHEN P_PADRE1.PEDIDO > 0 THEN 1 ELSE 0 END +
        CASE WHEN P_PADRE2.PEDIDO > 0 THEN 1 ELSE 0 END +
        CASE WHEN P_PADRE3.PEDIDO > 0 THEN 1 ELSE 0 END +
        CASE WHEN P_PADRE4.PEDIDO > 0 THEN 1 ELSE 0 END +
        CASE WHEN P_PADRE5.PEDIDO > 0 THEN 1 ELSE 0 END +
        CASE WHEN P_PADRE6.PEDIDO > 0 THEN 1 ELSE 0 END +
        CASE WHEN P_HIJO1.PEDIDO  IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN P_HIJO2.PEDIDO  IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN P_HIJO3.PEDIDO  IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN P_HIJO4.PEDIDO  IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN P_HIJO5.PEDIDO  IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN P_HIJO6.PEDIDO  IS NOT NULL THEN 1 ELSE 0 END
    ) AS TOTAL_PEDIDOS,

    (
        CASE WHEN TIQ_ACTUAL.CODIGO IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN TIQ_PADRE1.CODIGO IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN TIQ_PADRE2.CODIGO IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN TIQ_PADRE3.CODIGO IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN TIQ_PADRE4.CODIGO IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN TIQ_PADRE5.CODIGO IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN TIQ_PADRE6.CODIGO IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN TIQ_HIJO1.CODIGO  IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN TIQ_HIJO2.CODIGO  IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN TIQ_HIJO3.CODIGO  IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN TIQ_HIJO4.CODIGO  IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN TIQ_HIJO5.CODIGO  IS NOT NULL THEN 1 ELSE 0 END +
        CASE WHEN TIQ_HIJO6.CODIGO  IS NOT NULL THEN 1 ELSE 0 END
    ) AS TOTAL_ALBARANES

FROM PRESUPUESTOS
    LEFT JOIN PRESUPUESTOS P_PADRE1 ON P_PADRE1.CODIGO = PRESUPUESTOS.PRESUPUESTO
    LEFT JOIN PRESUPUESTOS P_PADRE2 ON P_PADRE2.CODIGO = P_PADRE1.PRESUPUESTO
    LEFT JOIN PRESUPUESTOS P_PADRE3 ON P_PADRE3.CODIGO = P_PADRE2.PRESUPUESTO
    LEFT JOIN PRESUPUESTOS P_PADRE4 ON P_PADRE4.CODIGO = P_PADRE3.PRESUPUESTO
    LEFT JOIN PRESUPUESTOS P_PADRE5 ON P_PADRE5.CODIGO = P_PADRE4.PRESUPUESTO
    LEFT JOIN PRESUPUESTOS P_PADRE6 ON P_PADRE6.CODIGO = P_PADRE5.PRESUPUESTO

    LEFT JOIN PRESUPUESTOS P_HIJO1  ON P_HIJO1.CODIGO  = PRESUPUESTOS.PRESUPUESTOD
    LEFT JOIN PRESUPUESTOS P_HIJO2  ON P_HIJO2.CODIGO  = P_HIJO1.PRESUPUESTOD
    LEFT JOIN PRESUPUESTOS P_HIJO3  ON P_HIJO3.CODIGO  = P_HIJO2.PRESUPUESTOD
    LEFT JOIN PRESUPUESTOS P_HIJO4  ON P_HIJO4.CODIGO  = P_HIJO3.PRESUPUESTOD
    LEFT JOIN PRESUPUESTOS P_HIJO5  ON P_HIJO5.CODIGO  = P_HIJO4.PRESUPUESTOD
    LEFT JOIN PRESUPUESTOS P_HIJO6  ON P_HIJO6.CODIGO  = P_HIJO5.PRESUPUESTOD

    LEFT JOIN TIQUETS TIQ_PADRE6 ON TIQ_PADRE6.PEDIDO = P_PADRE6.PEDIDO
    LEFT JOIN TIQUETS TIQ_PADRE5 ON TIQ_PADRE5.PEDIDO = P_PADRE5.PEDIDO
    LEFT JOIN TIQUETS TIQ_PADRE4 ON TIQ_PADRE4.PEDIDO = P_PADRE4.PEDIDO
    LEFT JOIN TIQUETS TIQ_PADRE3 ON TIQ_PADRE3.PEDIDO = P_PADRE3.PEDIDO
    LEFT JOIN TIQUETS TIQ_PADRE2 ON TIQ_PADRE2.PEDIDO = P_PADRE2.PEDIDO
    LEFT JOIN TIQUETS TIQ_PADRE1 ON TIQ_PADRE1.PEDIDO = P_PADRE1.PEDIDO
    LEFT JOIN TIQUETS TIQ_ACTUAL ON TIQ_ACTUAL.PEDIDO = PRESUPUESTOS.PEDIDO
    LEFT JOIN TIQUETS TIQ_HIJO1  ON TIQ_HIJO1.PEDIDO  = P_HIJO1.PEDIDO
    LEFT JOIN TIQUETS TIQ_HIJO2  ON TIQ_HIJO2.PEDIDO  = P_HIJO2.PEDIDO
    LEFT JOIN TIQUETS TIQ_HIJO3  ON TIQ_HIJO3.PEDIDO  = P_HIJO3.PEDIDO
    LEFT JOIN TIQUETS TIQ_HIJO4  ON TIQ_HIJO4.PEDIDO  = P_HIJO4.PEDIDO
    LEFT JOIN TIQUETS TIQ_HIJO5  ON TIQ_HIJO5.PEDIDO  = P_HIJO5.PEDIDO
    LEFT JOIN TIQUETS TIQ_HIJO6  ON TIQ_HIJO6.PEDIDO  = P_HIJO6.PEDIDO

WHERE PRESUPUESTOS.CODIGO = :presupuesto";

        $bindings = [
            'presupuesto' => $request->presupuesto,
        ];

        $res = DB::select($sql, $bindings);

        return response()->json(UtilsHelper::utf8ize($res));
    }


    public function obtenerSolicitudesFichaCliente(Request $request)
    {
        $query = "SELECT solicitud_presupuesto.codigo,
            solicitud_presupuesto.fecha,
            solicitud_presupuesto.hora,
            solicitud_presupuesto.caracter,
            solicitud_presupuesto.comentario,
            solicitud_presupuesto.descripcion_detallada,
            /* CAST(solicitud_presupuesto.texto_plantilla AS VARCHAR(10000)) AS TEXTO_PLANTILLA, */
            solicitud_presupuesto.texto_plantilla AS TEXTO_PLANTILLA,
            solicitud_presupuesto.presupuesto,
            caracter_solicitudes.descripcion as desc_caracter,
            clientes.descripcion,
            categorias_sol_presupuestos.DESCRIPCIONCATEGORIA
            from solicitud_presupuesto, clientes, caracter_solicitudes, categorias_sol_presupuestos
            where solicitud_presupuesto.cliente   = clientes.codigo
            and caracter_solicitudes.codigo     = solicitud_presupuesto.caracter
            and solicitud_presupuesto.categoria_solicitud = categorias_sol_presupuestos.codigo
            and solicitud_presupuesto.cliente   = :cliente1 ";

        $bindings = ['cliente1' => $request->cliente];

        if (!empty($request->cliente)) {
            $query .= " and  cliente = :cliente2 ";
            $bindings['cliente2'] = $request->cliente;
        }

        //1 Presupuestadas
        //2 No presupestadas

        if (!empty($request->filtro)) {
            if ($request->filtro == 1) {
                $query .= "and presupuesto is not null";
            }
            if ($request->filtro == 2) {
                $query .= "and presupuesto is null";
            }
        }

        //$sql = $sql . " order by codigo,fecha,hora desc";
        $query .= " order by codigo desc";

        $res = DB::select($query, $bindings);
        return response()->json(UtilsHelper::utf8ize($res));
    }


    //opciones select caracter
    public function obtenerOpcionesCaracterSolicitud(Request $request)
    {
        //SEPARO LA SQL DEL CARACTER DE LA SOLICITUD DEL RESTO PARA PODER TRABAJAR CON SU CARACTER
        if (!empty($request->solicitud)) {
            $query = "SELECT CARACTER FROM SOLICITUD_PRESUPUESTO WHERE CODIGO = ?";
            $res = DB::select($query, [$request->solicitud]);

            $caracter_sol = $res[0]->CARACTER;
        } else $caracter_sol = null;

        $query =  "SELECT CODIGO, DESCRIPCION
                FROM CARACTER_SOLICITUDES
               WHERE CODIGO = 2
                  OR CODIGO = 3
                  OR CODIGO = 8";

        if (!empty($caracter_sol->CARACTER)) {
            $query .= " OR CODIGO = ? ";
        };

        $query .= " GROUP BY 1, 2
               order by 1 ";

        $res = DB::select($query, [$caracter_sol]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    //opciones select categoria solicitud presupuesto
    public function obtenerOpcionesCategoriaSolicitud()
    {
        $query =  "select * from CATEGORIAS_SOL_PRESUPUESTOS order by codigo ";
        $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerSolicitudPorCodigo(Request $request)
    {
        $query = "SELECT * FROM solicitud_presupuesto"
            . " WHERE codigo = ?";

        if (!empty($request->visita_comercial)) {
            $query .= " OR SOLICITUD_PRESUPUESTO.VISITACOMERCIAL = ?";
        }
        $res = DB::select($query, [$request->codigo, $request->visita_comercial]);

        if (count($res) > 0) {
            $res[0]->imagenes = [];
            //buscar imágenes relacionadas
            $listaArchivos = UtilsHelper::obtenerListaArchivosCarpeta('solicitudes_presupuestos/' . $request->codigo);

            Log::info(print_r($listaArchivos, true));

            $res[0]->imagenes = $listaArchivos;

            /* foreach ($listaArchivos as $archivo)
            {
                $res[0]->imagenes[] = UtilsHelper::obtenerURLAsset("solicitudes_presupuestos/$request->codigo/$archivo");
            } */
        }

        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function obtenerDescripcionCaracterSolicitud(Request $request)
    {
        $query = "SELECT DESCRIPCION FROM caracter_solicitudes WHERE CODIGO = ?";
        $res = DB::select($query, [$request->caracter]);
        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function actualizarSolicitud(Request $request)
    {
        $query = "UPDATE solicitud_presupuesto
            SET fecha = :fecha,
                texto_plantilla = :plantilla,
                hora = :hora,
                caracter = :caracter,
                CATEGORIA_SOLICITUD = :categoria,
                CORREO_PRESUPUESTO = :correo,
                VISITACOMERCIAL = :visitaComercial,
                PROYECTO = :proyecto,
                expediente = :expediente
            WHERE codigo = :codigo";

        $bindings = [
            'fecha'            => $request->fecha,
            'plantilla'        => $request->texto_plantilla,
            'hora'             => $request->hora,
            'caracter'         => $request->caracter,
            'categoria'        => $request->categoria,
            'correo'           => $request->correo,
            'visitaComercial'  => $request->visitaComercial,
            'proyecto'         => $request->proyecto,
            'expediente'       => $request->expediente,
            'codigo'           => $request->codigo
        ];

        DB::select($query, $bindings);
        return response()->json(['msg' => 'Registro actualizado']);
    }

    public function obtenerSiguienteCodigoSolicitud(Request $request)
    {
        $query = "SELECT GEN_ID(solicitud_codigo_gen,1) AS NUEVO_CODIGO FROM RDB\$DATABASE";
        $res = DB::select($query);
        return response()->json($res[0]);
    }

    public function crearSolicitud(Request $request)
    {
        $query = "INSERT INTO SOLICITUD_PRESUPUESTO (CODIGO, FECHA, HORA, COMERCIAL, PROYECTO, CLIENTE, CARACTER, CATEGORIA_SOLICITUD, CORREO_PRESUPUESTO,
            TEXTO_PLANTILLA, EXPEDIENTE, TIPO_SOLICITUD_PRESUPUESTO, VISITACOMERCIAL)
            VALUES
            (:nuevo_codigo, :fecha, :hora, :comercial, :proyecto, :cliente, :caracter, :categoria, :correo,
            :plantilla, :expediente, 1, :visitaComercial)";

        $bindings = [
            'nuevo_codigo' => $request->nuevo_codigo,
            'fecha' => $request->fecha,
            'hora' => $request->hora,
            'comercial' => $request->comercial,
            'proyecto' => $request->proyecto,
            'cliente' => $request->cliente,
            'caracter' => $request->caracter,
            'categoria' => $request->categoria,
            'correo' => $request->correo,
            'plantilla' => $request->plantilla,
            'expediente' => $request->expediente,
            'visitaComercial' => $request->visitaComercial
        ];

        DB::select($query, $bindings);
        return response()->json(['msg' => "Registro creado"]);
    }

    public function borrarSolicitud(Request $request)
    {
        $query = "DELETE FROM SOLICITUD_PRESUPUESTO "
            . "WHERE CODIGO = ? ";

        DB::select($query, [$request->codigo]);
        return response()->json(['msg' => "Registro eliminado"]);
    }


    //INFORME_PRESUPUESTO

    public function obtenerInformacionPresupuesto(Request $request)
    {
        $query = "SELECT proyectos.razonsocial as razonsocial, proyectos.cif, proyectos.direccion, proyectos.cp, proyectos.poblacion,
               proyectos.provincia, proyectos.telefono, proyectos.fax, proyectos.email, proyectos.codigo as proyecto,

               clientes.codigo as cli_codigo, clientes.descripcion as cli_descripcion, clientes.cif as cli_cif, clientes.direccion as cli_direccion,
               clientes.cp as cli_cp, clientes.poblacion as cli_poblacion, clientes.provincia as cli_provincia, clientes.telefonofijo as cli_telefonofijo,
               clientes.fax as cli_fax, clientes.correo as cli_correo,

               presupuestos.codigo as pre_codigo, presupuestos.fecha, presupuestos.titulo, presupuestos.descripcion as pre_descripcion,
               presupuestos.baseimponible, presupuestos.total, presupuestos.pedido, presupuestos.tiquet, presupuestos.pdto,
               presupuestos.importedto, presupuestos.estado, presupuestos.presupuesto, presupuestos.presupuestod,

               vendedores.nombre as vendedor,

               impuestos.iva

          from presupuestos
          left join clientes   on presupuestos.cliente  = clientes.codigo
          left join proyectos  on presupuestos.proyecto = proyectos.codigo
          left join impuestos  on presupuestos.impuesto = impuestos.codigo
          left join vendedores on presupuestos.vendedor = vendedores.codigo
         where presupuestos.codigo   = ?";

        $res = DB::select($query, [$request->presupuesto]);
        $presupuesto = count($res) > 0 ? $res[0] : null;
        return response()->json(UtilsHelper::utf8ize($presupuesto));
    }

    public function obtenerArticulosPresupuesto(Request $request)
    {
        $query = "SELECT articulo, descripcion, CAST(cantidad AS FLOAT) as cantidad, CAST(pvp AS FLOAT) AS PVP, dto, CAST(pvpfinal AS FLOAT) AS PVPFINAL,
            CAST(importe AS FLOAT) AS IMPORTE, linpresu.comentario
            FROM linpresu, articulos
            WHERE articulos.codigo = linpresu.articulo
            AND presupuesto = ?";

        $res = DB::select($query, [$request->presupuesto]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function actualizarEstadoPresupuesto(Request $request)
    {
        $sql = "UPDATE presupuestos
        SET comentario_comercial_presu = :comentario";

        $bindings = [
            'comentario' => $request->comentario,
            'presupuesto' => $request->presupuesto
        ];

        if (!empty($request->estado)) {
            $sql .= ", estado = :estado";
            $bindings['estado'] = $request->estado;
        }

        $sql .= " WHERE codigo = :presupuesto";
        DB::select($sql, $bindings);

        return response()->json(['msg' => $request->all()]);
    }

    public function cargarDetalleEstadoPresupuesto(Request $request)
    {
        $sql = "SELECT * FROM PRESUPUESTOS WHERE CODIGO = :codigo";

        $bindings = ['codigo' => $request->codigo];
        $result = DB::select($sql, $bindings);
        $res = count($result) > 0 ? $result[0] : null;

        return response()->json(UtilsHelper::utf8ize($res));
    }

    //menu presupuestos
    public function obtenerSelectEstadosPresupuesto()
    {
        $sql = "SELECT DESCRIPCION as estado FROM estados_presupuestos ORDER BY estado";
        $res = DB::select($sql);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function subirFotoSolicitud(Request $request) {}
}
