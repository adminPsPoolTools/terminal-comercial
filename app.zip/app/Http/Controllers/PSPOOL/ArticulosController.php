<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use App\Helpers\UtilsHelper;


class ArticulosController extends Controller
{
    public function buscarArticulos(Request $request)
    {
        $filtro = $request->filtro;
        $resultadosPorPagina = 100;
        $offset = $resultadosPorPagina * ($request->pagina - 1);

        $sql = "SELECT FIRST :resultados SKIP :offset articulos.CODIGO, articulos.DESCRIPCION
        FROM articulos
        LEFT JOIN EANS ON EANS.ARTICULO = ARTICULOS.CODIGO
        LEFT JOIN PROYECTO ON PROYECTO.ARTICULO = ARTICULOS.CODIGO AND PROYECTO.PROYECTO = 1
        WHERE PROYECTO.BLOQUEADO = 'N'
        ";

        $bindings = ['offset' => $offset, 'resultados' => $resultadosPorPagina];

        if (!empty($filtro)) {
            $sql .= " AND ((ARTICULOS.DESCRIPCION LIKE :filtro)
                        OR (ARTICULOS.CODIGO = :codigo)
                        OR (EANS.EAN = :ean)
                        OR (ARTICULOS.CODIGO IN (SELECT ARTICULO FROM REFERENCIAS WHERE REFERENCIA LIKE :referencia)))";

            $bindings['filtro'] = "%$filtro%";
            $bindings['codigo'] = $filtro;
            $bindings['ean'] = $filtro;
            $bindings['referencia'] = "%$filtro%";
        }

        $sql .= " GROUP BY 1,2 ORDER BY ARTICULOS.descripcion

        ";
        //ROWS 10 FETCH FIRST 30 ROWS ONLY

        $res= DB::select($sql, $bindings);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerDisponibilidad(Request $request)
    {

        $sql = "SELECT DISPONIBILIDAD, PROVEEDOR, FECHA_REFERENCIA, MINIMO_DIAS_DISPONIBILIDAD,
        FECHA_PROXIMA_DISPONIBILIDAD, STOCK_DISPONIBLE, NO_CONTROLAR_STOCK
        FROM DISPONIBILIDAD_ARTICULO(1, :articulo, :unidades)";

        $bindings = [

        'articulo' => $request->articulo,
        'unidades' => $request->unidades,
        ];

        $res = DB::select($sql, $bindings);


        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function obtenerDetalle(Request $request)
    {

        $sql = "SELECT ARTICULOS.CODIGO, ARTICULOS.DESCRIPCION, PROYECTO.PVP
                  FROM ARTICULOS
                  LEFT JOIN PROYECTO ON PROYECTO.ARTICULO = ARTICULOS.CODIGO
                 WHERE ARTICULOS.CODIGO = :articulo
                   AND PROYECTO.PROYECTO = 1";
 
        $bindings = [
            'articulo' => $request->articulo,
        ];

        $res = DB::select($sql, $bindings);
        if(count($res) > 0){
            $res[0]->imagenes = [];
            //buscar imagen

            $listaArchivos = UtilsHelper::obtenerListaArchivosCarpeta('articulos');

            //Log::notice(print_r($listaArchivos, true));

            foreach ($listaArchivos as $archivo)
            {
                //obtener código del producto que está en el nombre del archivo y comprobar si es el que se está buscando
                $codigoEnArchivo = explode('.', basename($archivo))[0];

                //Log::notice($request->articulo . ' - ' .$codigoEnArchivo);

                if(/* UtilsHelper::archivoEsImagen($archivo) &&  */$request->articulo == $codigoEnArchivo)
                {
                    //$res[0]->imagenes[] = UtilsHelper::obtenerURLAsset("$archivo");
                    $res[0]->imagenes[] = UtilsHelper::obtenerURLAsset($archivo);
                    break;
                }
            }

        }
        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function obtenerCategoriasPorSelectSGF(Request $request)
    {
        $tipo_seleccionado = $request->tipo_seleccionado;

        if ($tipo_seleccionado == 1) {
            $sql = "SELECT * FROM secciones ORDER BY descripcion";
        } elseif ($tipo_seleccionado == 2) {
            $sql = "SELECT * FROM grupos ORDER BY descripcion";
        } elseif ($tipo_seleccionado == 3) {
            $sql = "SELECT * FROM familias ORDER BY descripcion";
        }

        $res = DB::select($sql);

        return response()->json(UtilsHelper::utf8ize($res));
    }
}
