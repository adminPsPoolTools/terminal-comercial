<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class UsuariosController extends Controller
{
    public function obtenerCodigoNombre(Request $request)
    {
        $query = "SELECT codigo, nombre FROM usuarios";
        if(!$request->has('expediente') || empty($request->expediente))
        {
            $query .=  ($request->comercial != 101)
            ? " WHERE CODIGO = 101 OR CODIGO = 999 OR CODIGO = ? "
            : " WHERE CODIGO = 9 OR CODIGO = 14 OR CODIGO = 15 OR CODIGO = 16 OR CODIGO = 26 OR CODIGO = 101 OR CODIGO = 999 OR CODIGO = 30 OR CODIGO = 29";
        }

        $res = DB::select($query, [$request->comercial]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerUsuariosVendedores()
    {
        $sql = "SELECT USUARIOS.CODIGO, USUARIOS.NOMBRE
        FROM USUARIOS
        JOIN VENDEDORES ON USUARIOS.VENDEDOR_ASOCIADO_USUARIO = VENDEDORES.CODIGO
        WHERE VENDEDORES.USA_TERMINAL_COMERCIAL = 'S'";

        $res = DB::select($sql);

        return response()->json(UtilsHelper::utf8ize($res));
    }
}
