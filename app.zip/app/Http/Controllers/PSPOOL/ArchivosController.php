<?php

namespace App\Http\Controllers\PSPOOL;

use App\Helpers\UtilsHelper;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

use App\Models\Config;

class ArchivosController extends Controller
{
    public function guardarArchivo(Request $request)
    {
        //comprobar que existe la carpeta o crearla

        if (!Storage::disk('public')->exists($request->ruta)) {
            Storage::disk('public')->makeDirectory($request->ruta);
        }


        if ($request->has('archivo') && $request->file('archivo')->isValid()) {
            $explodeImage = explode('.', $request->archivo->getClientOriginalName());
            $nombreArchivo = $explodeImage[0];
            $extension = end($explodeImage);
            $nombreArchivoSlug = Str::slug($nombreArchivo);
            $request->archivo->storeAs($request->ruta, $nombreArchivoSlug . '.' . $extension, 'public');
            //mover a la carpeta gesplanet
            //buscar directorio imagenes
            /* $queryDirectorio = 'SELECT DIRECTORIOIMAGENES FROM CONFIGCENTRAL';
            $resDirectorio = DB::select($queryDirectorio);
            $directorioImagenes = $resDirectorio[0]->DIRECTORIOIMAGENES;
            */
            Log::info(print_r($request->archivo, true));
            Log::info("Guardando archivo en " . $request->ruta . ' ' . $nombreArchivoSlug . '.' . $extension);

            //mover a carpeta compartida
            //$directorioCarpetaCompartida = $directorioImagenes;
            $directorioCarpetaCompartida = Config::directorioImagenes();

            //$directorioCarpetaCompartida = "\\\\Desktop-hprl3et\\192.168.0.75/";

            if (!is_dir("$directorioCarpetaCompartida$request->ruta")) mkdir("$directorioCarpetaCompartida$request->ruta", 0775, true);

            copy("storage/$request->ruta/$nombreArchivoSlug.$extension", "$directorioCarpetaCompartida$request->ruta/$nombreArchivoSlug.$extension");
        }


        return redirect()->back()->with('msg', 'Archivo subido correctamente');
    }


    public function obtenerArchivos(Request $request)
    {
        //Log::info('Ruta: ' . $request->ruta);

        $res = UtilsHelper::obtenerListaArchivosCarpeta($request->ruta);

        return response()->json(['archivos' => $res]);
    }

    public function obtenerArchivo(Request $request)
    {
        //die("FUNCIONA");
        $rutaCompleta = $request->ruta . '/' . $request->archivo;

        Log::info('Obteniendo archivo ' . $rutaCompleta);

        if (Storage::disk('public')->exists($rutaCompleta)) {

            Log::info('Archivo encontrado');
            //Ignorar el error - sí funciona
            /* $download = Storage::disk('public')->download($rutaCompleta);

            Log::info($download);

            return $download; */
            $contents = base64_encode(file_get_contents('.' . Storage::url($rutaCompleta)));

            return response()->json(['archivo' => $contents]);
        }

        //  return response()->json(['imagen'])
    }

    //obtener las urls de todas las imagenes de un directorio
    public function obtenerImagenesDirectorio(Request $request)
    {
        $res = [];
        $rutaCompleta = $request->ruta/* .'/'.$request->archivo */;

        if (Storage::disk('public')->exists($rutaCompleta)) {

            $archivos = UtilsHelper::obtenerListaArchivosCarpeta($request->ruta);
            foreach ($archivos as $archivo) {

                if (UtilsHelper::archivoEsImagen($archivo)) {
                    $res[] = UtilsHelper::obtenerURLAsset($rutaCompleta . '/' . $archivo);
                }
            }
        }

        return response()->json(['imagenes' => $res]);
    }
}
