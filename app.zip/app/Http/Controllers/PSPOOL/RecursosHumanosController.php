<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class RecursosHumanosController extends Controller
{
    public function obtenerEntradasSalidas(Request $request)
    {
        $query = "
            SELECT ID, TIPO, PROYECTO, FECHA, HORA, COMENTARIO
            FROM ENTRADAS_SALIDAS_EMPLEADO
            WHERE EMPLEADO = :comercial
            AND FECHA = 'NOW'
            ORDER BY FECHA DESC, HORA DESC";

        $res = DB::connection('recursosHumanos')->select($query, ['comercial' => $request->comercial]);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerEstadoActual(Request $request)
    {
        $query = "SELECT FIRST 1 TIPO
          FROM ENTRADAS_SALIDAS_EMPLEADO
         WHERE EMPLEADO = :empleado
           AND FECHA = 'NOW'
         ORDER BY FECHA DESC, HORA DESC";

         $res = DB::connection('recursosHumanos')->select($query, ['empleado' => $request->empleado]);

         return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));

    }

    public function insertarEstado(Request $request)
    {
        //comprobar estado actual
        //buscar si está dentro
        $sql = "SELECT DENTRO FROM EMPLEADO_DENTRO(:user, :fecha)";
        $resDentro = DB::connection('recursosHumanos')->select($sql, ['user' => $request->user, 'fecha' => $request->fecha]);
        $dentro = count($resDentro) > 0 ? $resDentro[0]->DENTRO : null;

        //buscar si está parado
        $sql = "SELECT PARADO FROM EMPLEADO_PARADO(:user, :fecha)";
        $resParado = DB::connection('recursosHumanos')->select($sql, ['user' => $request->user, 'fecha' => $request->fecha]);
        $parado = count($resParado) > 0 ? $resParado[0]->PARADO : null;

        $mensaje = null;

        //si el estado nuevo que se quiere insertar no tiene sentido, geenrar un mensaje apropiado
        switch ($request->tipo) {
            case 'SALIDA':
                if ($dentro == 'N') {
                    $mensaje = "Para salir primero tiene que entrar";
                } else if ($parado == 'S') {
                    $mensaje = "Para salir primero tiene que continuar";
                }
                break;

            case 'ENTRADA':
                if ($dentro == 'S') {
                    $mensaje = "Ya hay una entrada de hoy";
                }
                break;

            case 'CONTINUA':
                if ($parado == 'N') {
                    $mensaje = "Para continuar tiene que parar primero";
                }
                break;

            case 'PARADA':
                if ($parado == 'S') {
                    $mensaje = "Ya est&aacute; en una parada, tiene que continuar para volver a parar";
                } else if ($dentro == "N") {
                    $mensaje = "Tiene que comenzar para hacer una parada";
                }
                break;
        }

        if($mensaje != null) {
            return response()->json(['estado' => 'error', 'mensaje' => $mensaje]);
        }

        //Si el nuevo estado tiene sentido insertarlo
        $nuevoIdQuery = "SELECT GEN_ID(ENTRADAS_SALIDAS_ID_GEN,1) AS ID FROM RDB\$DATABASE";
        $nuevoIdRes = DB::connection('recursosHumanos')->select($nuevoIdQuery);
        $nuevoId = count($nuevoIdRes) > 0 ? $nuevoIdRes[0]->ID : null;

        $queryProyecto = "SELECT PROYECTO, SUBPROYECTO FROM EMPLEADOS WHERE CODIGO = :user";
        $resProyecto = DB::connection('recursosHumanos')->select($queryProyecto, ['user' => $request->user]);
        $proyecto = count($resProyecto) > 0 ? $resProyecto[0]->PROYECTO : null;
        $subproyecto = count($resProyecto) > 0 ? $resProyecto[0]->SUBPROYECTO : null;


       /*  ID: Se rellenará solo es un generador
        EMPLEADO: El código del empleado logueado
        PROYECTO: el código del proyecto que tiene el empleado logueado EMPLEADOS.PROYECTO
        SUBPROYECTO: el código del subproyecto que tiene el empleado logueado EMPLEADOS.SUBPROYECTO
        DISPOSITIVO_FIRMA: el número de terminal que tenemos en configuración
        FECHA: La de ahora mismo
        HORA: La de ahora mismo
        BLOQUEADO: 'N'
        UBICACION_LONGITUD: La que capture el teléfono
        UBICACION_LATITUD: La que capture el teléfono
        DIRECCION: Nombre de la calle/Ciudad/Provincia/pais
        COMENTARIO: El que rellene el empleado .. realmente es el único que puede tocar. */

        $query = "INSERT INTO ENTRADAS_SALIDAS_EMPLEADO (ID, TIPO, PROYECTO, SUBPROYECTO, DISPOSITIVO_FIRMA,
                EMPLEADO, FECHA, HORA, BLOQUEADO, COMENTARIO, UBICACION_LONGITUD, UBICACION_LATITUD, DIRECCION)
        VALUES(:id, :tipo, :proyecto, :subproyecto, :terminal, :user, 'NOW', 'NOW', 'N', :comentario, :longitud, :latitud, :direccion)";

        $params = [
            'id' => $nuevoId,
            'tipo' => $request->tipo,
            'proyecto' => $proyecto,
            'subproyecto' => $subproyecto,
            'terminal' => $request->terminal,
            'user' => $request->user,
            'comentario' => str_replace("'", "", $request->comentario),
            'longitud' => $request->longitud,
            'latitud' => $request->latitud,
            'direccion' => str_replace("'", "", $request->direccion)
        ];

        DB::connection('recursosHumanos')->insert($query, $params);

        return response()->json(['msg' => 'Estado insertado']);
    }


    public function comprobarUsuario(Request $request)
    {
        $query = "SELECT CODIGO, NOMBRE, ES_JEFE
            FROM EMPLEADOS
            WHERE CODIGO = :user
            AND PASSWORD = :clave ";

        $res = DB::connection('recursosHumanos')->select($query, ['user' => $request->user, 'clave' => $request->clave]);

        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function mandarAlarmaEstablecida(Request $request)
    {
        $sql = "UPDATE OR INSERT INTO ALARMAS_ESTABLECIDAS (EMPLEADO, FECHA, HORA, MENSAJE, FECHA_ALARMA, HORA_ALARMA)
        VALUES (:usuario, 'NOW', 'NOW', :msg, :fecha, :hora)
        MATCHING (EMPLEADO, FECHA_ALARMA, HORA_ALARMA)";

        $params = [
            'usuario' => $request->usuario,
            'msg' => $request->msg,
            'fecha' => $request->fecha,
            'hora' => $request->hora
        ];

        DB::connection('recursosHumanos')->update($sql, $params);

        return response()->json(['msg' => 'Alarma insertada']);
    }

    public function mandarErrorAlarma(Request $request)
    {

        $query = " INSERT INTO ERRORES_ALARMAS (EMPLEADO, FECHA, HORA, MENSAJE)
            VALUES (:usuario, 'NOW', 'NOW', :mensaje)
            ";
        DB::connection('recursosHumanos')->insert($query, [
            'usuario' => $request->usuario,
            'mensaje' => $request->msg
        ]);

        return response()->json(['msg' => 'Error creado']);
    }

    public function obtenerAlarmas (Request $request)
    {
        $query = "SELECT RTIPO, RHORA, RFECHA FROM OBTENER_ALARMAS(:usuario, 'NOW')";
        $res = DB::connection('recursosHumanos')->select($query, ['usuario' => $request->usuario]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerChivatos(Request $request)
    {
        $sql = "SELECT CODIGO, NOMBRE, CORREO, TELEFONO_MOVIL, CAST(EMPLEADOS.COMENTARIO AS VARCHAR(1000)) AS COMENTARIO, POBLACION, PROVINCIA, PAIS, ALIAS, ESE.UBICACION_LATITUD AS LATITUD, ESE.UBICACION_LONGITUD AS LONGITUD
          FROM EMPLEADOS
          LEFT JOIN ENTRADAS_SALIDAS_EMPLEADO ESE ON ESE.EMPLEADO = EMPLEADOS.CODIGO AND ESE.ID = (SELECT MAX(ID) FROM ENTRADAS_SALIDAS_EMPLEADO WHERE EMPLEADO = ESE.EMPLEADO AND UBICACION_LONGITUD IS NOT NULL)
          LEFT JOIN EMPLEADO_DENTRO(CODIGO,'NOW') ON 0=0
          LEFT JOIN ES_LABORABLE(CODIGO,'NOW')    ON 0=0
          LEFT JOIN EMPLEADO_PARADO(CODIGO,'NOW') ON 0=0
         WHERE 0=0 ";

        if($request->estado == "DENTRO"){
            $sql .= "AND DENTRO = 'S' AND PARADO = 'N'";
        }

        if($request->estado == "FUERA"){
            $sql .= "AND DENTRO = 'N' AND ES_LABORABLE = 'S'";
        }

        if($request->estado == "PARADA"){
            $sql .= "AND PARADO = 'S'";
        }

        if($request->estado == "VACACIONES"){
            $sql .= "AND EMPLEADO_VACACIONES = 'S'";
        }

        if($request->estado == "BAJA"){
            $sql .= "AND EMPLEADO_BAJA = 'S'";
        }

        $res = DB::connection('recursosHumanos')->select($sql);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerContadores()
    {
        $sql = "SELECT EMPLEADOS_DENTRO, EMPLEADOS_FUERA, EMPLEADOS_PARADA, EMPLEADOS_VACACIONES, EMPLEADOS_BAJA 
          FROM OBTENER_CONTADORES_EMPLEADOS";

        $res = DB::connection('recursosHumanos')->select($sql);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function buscarProyectos(Request $request)
    {
        $sql = "SELECT CODIGO, DESCRIPCION  
          FROM PROYECTOS
         WHERE (CODIGO LIKE :filtro
            OR UPPER(DESCRIPCION) LIKE UPPER(:filtroLike))
           AND BLOQUEADO = 'N'
         ORDER BY DESCRIPCION";

        $res = DB::connection('recursosHumanos')->select($sql, [
            'filtro' => $request->filtro,
            'filtroLike' => '%' . $request->filtro . '%'
        ]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerTicadoHoy20190510(Request $request)
    {
        $msg = null;

        //contar entradas
        $results = DB::connection('recursosHumanos')->select("
        SELECT COUNT(ID) AS ENTRADAS
        FROM ENTRADAS_SALIDAS_EMPLEADO
        WHERE EMPLEADO = :usuario
          AND TIPO LIKE :tipo
          AND FECHA = :fecha
        ", [
            'usuario' => $request->usuario,
            'tipo' => $request->tipo,
            'fecha' => $request->fecha
        ]);

        $entradas = count($results) > 0 ? $results[0]->ENTRADAS : null;

        //si no tiene entradas
        if($entradas == 0)
        {
            //comprobar si está de vacaciones
            $results = DB::connection('recursosHumanos')->select("
            SELECT COUNT(ID) AS VACAS
            FROM VACACIONES_EMPLEADOS
            WHERE EMPLEADO = :usuario
              AND BLOQUEADO = 'N'
              AND DESDE_FECHA <= :fecha
              AND HASTA_FECHA >= :fecha1
            ", [
                'usuario' => $request->usuario,
                'fecha' => $request->fecha,
                'fecha1' => $request->fecha
            ]);

            $vacas = count($results) > 0 ? $results[0]->VACAS : null;

            //si no está de vacaciones comprobar si es festivo
            if($vacas == 0)
            {
                $query = "SELECT COUNT(DF.FECHA) AS FESTIVOS
                FROM DIAS_FESTIVOS DF
                LEFT JOIN EMPLEADOS ON DF.EMPLEADO = EMPLEADOS.CODIGO
                WHERE (DF.TIPO = 0)
                    OR (DF.TIPO = 1 AND EMPLEADOS.PAIS = DF.PAIS)
                    OR (DF.TIPO = 2 AND EMPLEADOS.COMUNIDAD_AUTONOMA = DF.COMUNIDAD_AUTONOMA)
                    OR (DF.TIPO = 3 AND EMPLEADOS.PROVINCIA = DF.PROVINCIA)
                    OR (DF.TIPO = 4 AND EMPLEADOS.POBLACION = DF.POBLACION)
                    OR (DF.TIPO = 5 AND DF.EMPLEADO = :usuario)
                AND EMPLEADOS.CODIGO = :usuario1 ";

                $results = DB::connection('recursosHumanos')->select($query, [
                    'usuario' => $request->usuario,
                    'usuario1' => $request->usuario,
                ]);


                $festivo = count($results) > 0 ? $results[0]->FESTIVOS : null;

                //si no es festivo comprobar si está de baja
                if($festivo === 0)
                {
                    $sql = "SELECT COUNT(ID) AS BAJAS 
                        FROM BAJAS_EMPLEADOS
                        WHERE EMPLEADO = :usuario
                        AND DESDE_FECHA <= :fecha
                        AND HASTA_FECHA >= :fecha1
                        AND BLOQUEADO = 'N'";

                    $results = DB::connection('recursosHumanos')->select($sql, [
                        'usuario' => $request->usuario,
                        'fecha' => $request->fecha,
                        'fecha1' => $request->fecha
                    ]);
                    $bajas = count($results) > 0 ? $results[0]->BAJAS : null;

                    //Por ultimo, si no está de baja miramos si está dentro del planning de dias lectivos de la empresa
                    if($bajas == 0)
                    {
                        $sql = "SELECT COUNT(ID) AS PLANNING
                            FROM PLANING_TRABAJO
                            WHERE EMPLEADO = :usuario
                            AND BLOQUEADO = 'N'
                            AND FECHA_DESDE <= :fecha 
                            AND FECHA_HASTA >= :fecha1 ";

                        $results = DB::connection('recursosHumanos')->select($sql, [
                            'usuario' => $request->usuario,
                            'fecha' => $request->fecha,
                            'fecha1' => $request->fecha
                        ]);

                        $planning = count($results) > 0 ? $results[0]->PLANNING : null;

                        if($planning != 0) $msg = "TIENE QUE TICAR";
                    }
                    else $msg = "ESTA DE BAJA";
                }
                else $msg = "ES FESTIVO";
                
            }
            else $msg = "VACACIONES";


        }
        else $msg = "TICADO";

        return response()->json(['msg' => $msg]);

    }

    public function obtenerTicadoHoy20190513(Request $request)
    {
        $ticar = false;

       //comprobar si está parado
        $paradoResults = DB::connection('recursosHumanos')->select(
            "SELECT PARADO FROM EMPLEADO_PARADO(:usuario, 'NOW')",
            ['usuario' => $request->usuario]
        );
        $parado = !empty($paradoResults) ? $paradoResults[0]->PARADO : 'N';

        if (($request->tipo == 'CONTINUA' && $parado == 'S') ||
            ($request->tipo == 'PARADA' && $parado == 'N')) {
            $ticar = true;
        }

        //comprobar si está dentro
        $dentroResults = DB::connection('recursosHumanos')->select(
            "SELECT DENTRO FROM EMPLEADO_DENTRO(:usuario, 'NOW')",
            ['usuario' => $request->usuario]
        );
        $dentro = !empty($dentroResults) ? $dentroResults[0]->DENTRO : 'N';

        if (($dentro == 'S' && $request->tipo == 'SALIDA') ||
            ($dentro == 'N' && $request->tipo == 'ENTRADA')) {
            $ticar = true;
        }

        return response()->json([
            'msg' => $ticar ? 'TIENE QUE TICAR' : 'TICADO',
        ]);
    }

    public function obtenerTicadoHoy(Request $request)
    {
        $hora = $request->hora;

        if(empty($hora)){
            $hora = date("m/d/Y");
        }

        $query = $sql= "SELECT ALARMA FROM SALTAR_ALARMA(:usuario)";

        $res = DB::connection('recursosHumanos')->select($query, [
            'usuario' => $request->usuario,
            'hora' => $hora
        ]);

        $alarma = count($res) > 0 ? $res[0]->ALARMA : null;

        return response()->json(UtilsHelper::utf8ize(['msg' => $alarma]));
    }

    public function obtenerUltimaVersion()
    {
        $query = "SELECT VERSION_A_ACTUALIZAR_APP FROM CONFIGCENTRAL";
        $res = DB::connection('recursosHumanos')->select($query);
        return response()->json(UtilsHelper::utf8ize($res[0]));
    }
}
