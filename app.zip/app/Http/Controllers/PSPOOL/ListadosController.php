<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class ListadosController extends Controller
{
    public function obtenerVentasClientesProvincias(Request $request)
    {

        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;
        $comercial = $request->comercial;


        $sql = "
            SELECT
                cliente,
                clientes.descripcion,
                clientes.provincia,
                clientes.codigo,
                SUM(hventasarticulo.importebaseventa) AS timportebase
            FROM hventasarticulo
            LEFT JOIN clientes ON hventasarticulo.cliente = clientes.codigo
            WHERE fecha BETWEEN :fecha_desde AND :fecha_hasta
            AND ((clientes.vendedor = :comercial) OR (:comercial1 = 1))
        ";


        if (empty($comercial)) {
            $sql .= " AND clientes.vendedor = :comercial2";
        }

        $sql .= "
            GROUP BY clientes.pais, clientes.provincia, cliente, clientes.descripcion, clientes.codigo
            ORDER BY UPPER(clientes.provincia), UPPER(clientes.pais)
        ";


        $res = DB::select($sql, [
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
            'comercial'   => $comercial,
            'comercial1'   => $comercial,
            'comercial2'   => $comercial
        ]);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerVentasSecciones(Request $request)
    {
        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;
        $comercial = $request->comercial;


        $sql = "
            SELECT
                secciones.codigo AS seccion,
                secciones.descripcion AS descripcion_seccion,
                articulos.codigo AS articulo,
                articulos.descripcion AS descripcion_articulo,
                SUM(hventasarticulo.importebaseventa) AS timportebase
            FROM hventasarticulo
            LEFT JOIN clientes ON hventasarticulo.cliente = clientes.codigo
            LEFT JOIN articulos ON hventasarticulo.articulo = articulos.codigo
            LEFT JOIN secciones ON secciones.codigo = articulos.seccion
            WHERE fecha BETWEEN :fecha_desde AND :fecha_hasta
            AND ((clientes.vendedor = :comercial) OR (:comercial1 = 1))
        ";


        if (empty($comercial)) {
            $sql .= " AND clientes.vendedor = :comercial2";
        }

        $sql .= "
            GROUP BY secciones.codigo, secciones.descripcion, articulos.codigo, articulos.descripcion
            ORDER BY secciones.codigo, articulos.descripcion
        ";


        $res = DB::select($sql, [
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
            'comercial'   => $comercial,
            'comercial1'   => $comercial,
            'comercial2'   => $comercial
        ]);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerNuevosClientes(Request $request)
    {
        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;
        $comercial   = $request->comercial;

        $sql = "
            SELECT * FROM CLIENTES
            WHERE fecha_alta >= :fecha_desde
            AND fecha_alta <= :fecha_hasta
            AND vendedor = :comercial
            ORDER BY codigo
        ";

        $res = DB::select($sql, [
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
            'comercial'   => $comercial
        ]);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerVentasProvincias(Request $request)
    {
        $provincia = '';
        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;
        $comercial   = $request->comercial;
        // dd($request->all());


        $sql = "SELECT CLIENTES.PROVINCIA, SUM(HVENTASARTICULO.IMPORTEVENTA) AS VENTAS
            FROM CLIENTES
            LEFT JOIN HVENTASARTICULO ON HVENTASARTICULO.CLIENTE = CLIENTES.CODIGO
            WHERE CLIENTES.VENDEDOR             = :comercial
                AND HVENTASARTICULO.FECHA >= :fecha_desde
                AND HVENTASARTICULO.FECHA <= :fecha_hasta
            GROUP BY CLIENTES.PROVINCIA
            ORDER BY CLIENTES.PROVINCIA";

        $infoProvincias = DB::select($sql, [
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
            'comercial'   => $comercial
        ]);

        //obtener los cálculos por provincia y guardarlos en un array
        $arrayInfoDetallada = [];


        foreach ($infoProvincias as $prov) {
            $infoDetalladaProv = [];
            //realizar consulta, obtener valor y guardarlo
            $bindings = [
                'provincia'   => $prov->PROVINCIA,
                'fecha_desde' => $fecha_desde,
                'fecha_hasta' => $fecha_hasta,
                'comercial'   => $comercial
            ];

            //clientes nuevos
            $sql = "
                SELECT COUNT(CLIENTES.CODIGO) AS CLIENTES_NUEVOS
                FROM CLIENTES
                WHERE PROVINCIA = :provincia
                AND FECHA_ALTA BETWEEN :fecha_desde AND :fecha_hasta
                AND VENDEDOR = :comercial
            ";

            $res = DB::select($sql, $bindings);

            $infoDetalladaProv['CLIENTES_NUEVOS'] = $res[0]->CLIENTES_NUEVOS;

            //total clientes
            $sql = " SELECT COUNT(CLIENTES.CODIGO) AS CLIENTES_TOTAL
                FROM CLIENTES
                WHERE PROVINCIA = :provincia
                AND VENDEDOR = :comercial
            ";


            $res = DB::select($sql, $bindings);

            $infoDetalladaProv['CLIENTES_TOTAL'] = $res[0]->CLIENTES_TOTAL;

            //visitas comerciales por provincia
            $sql = "SELECT COUNT(CLIENTES.CODIGO) AS VISITAS_COMERCIALES
                FROM VISITASCOMERCIALES, CLIENTES
                WHERE VISITASCOMERCIALES.CLIENTE = CLIENTES.CODIGO
                AND CLIENTES.PROVINCIA = :provincia
                AND VISITASCOMERCIALES.FECHA BETWEEN :fecha_desde AND :fecha_hasta
                AND CLIENTES.VENDEDOR = :comercial
            ";

            $res = DB::select($sql, $bindings);
            $infoDetalladaProv['VISITAS_COMERCIALES'] = $res[0]->VISITAS_COMERCIALES;

            //presupuestos realizados
            $sql = "
                SELECT COUNT(PRESUPUESTOS.CODIGO) AS PRESUPUESTOS_REALIZADOS
                FROM PRESUPUESTOS, CLIENTES
                WHERE PRESUPUESTOS.CLIENTE = CLIENTES.CODIGO
                AND CLIENTES.PROVINCIA = :provincia
                AND PRESUPUESTOS.FECHA BETWEEN :fecha_desde AND :fecha_hasta
                AND CLIENTES.VENDEDOR = :comercial
            ";


            $res = DB::select($sql, $bindings);
            $infoDetalladaProv['PRESUPUESTOS_REALIZADOS'] = $res[0]->PRESUPUESTOS_REALIZADOS;

            //presupuestos aprobados
            $sql = "
                SELECT COUNT(PRESUPUESTOS.CODIGO) AS PRESUPUESTOS_APROBADOS
                FROM PRESUPUESTOS, CLIENTES
                WHERE PRESUPUESTOS.CLIENTE = CLIENTES.CODIGO
                AND PRESUPUESTOS.PEDIDO <> 0
                AND PRESUPUESTOS.PEDIDO IS NOT NULL
                AND CLIENTES.PROVINCIA = :provincia
                AND PRESUPUESTOS.FECHA BETWEEN :fecha_desde AND :fecha_hasta
                AND CLIENTES.VENDEDOR = :comercial
            ";



            $res = DB::select($sql, $bindings);
            $infoDetalladaProv['PRESUPUESTOS_APROBADOS'] = $res[0]->PRESUPUESTOS_APROBADOS;

            $arrayInfoDetallada[$prov->PROVINCIA] = $infoDetalladaProv;
        }

        return response()->json(UtilsHelper::utf8ize([$infoProvincias, $arrayInfoDetallada]));
    }

    public function obtenerRankingVentas(Request $request)
    {

        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;
        $comercial   = $request->comercial;

        $queryClientes =  " SELECT FIRST 10 CLIENTES.CODIGO AS CLIENTE,
                CLIENTES.DESCRIPCION,
                CLIENTES.PROVINCIA,
                CLIENTES.DISTANCIA,
                SUM(HVENTASARTICULO.IMPORTEVENTA) AS VENTAS
            FROM CLIENTES
            INNER JOIN HVENTASARTICULO ON CLIENTES.CODIGO = HVENTASARTICULO.CLIENTE
            WHERE CLIENTES.VENDEDOR = :comercial
            AND HVENTASARTICULO.FECHA BETWEEN :fecha_desde AND :fecha_hasta
            GROUP BY CLIENTES.CODIGO, CLIENTES.DESCRIPCION, CLIENTES.PROVINCIA, CLIENTES.DISTANCIA
            ORDER BY SUM(HVENTASARTICULO.IMPORTEVENTA) DESC
        ";

        $bindings = [
            'comercial'   => $comercial,
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
        ];

        $clientes = DB::select($queryClientes, $bindings);

        //por cada linea obtener unos datos

        $res = [];
        foreach ($clientes as $cliente) {
            $clienteArray = (array) $cliente;

            $bindings['cliente'] = $cliente->CLIENTE;

            //Número visitas comerciales

            $sql = "
                SELECT COUNT(VISITASCOMERCIALES.CODIGO) AS VISITAS
                FROM VISITASCOMERCIALES
                WHERE CLIENTE = :cliente
                AND VISITASCOMERCIALES.FECHA BETWEEN :fecha_desde AND :fecha_hasta
            ";

            $result = DB::select($sql, $bindings);
            $clienteArray['VISITAS'] = $result[0]->VISITAS;

            $res[] = $clienteArray;
        }

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerRankingVisitas(Request $request)
    {
        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;
        $comercial   = $request->comercial;

        $queryClientes =  "SELECT FIRST 10 CLIENTES.CODIGO AS CLIENTE, CLIENTES.DESCRIPCION, CLIENTES.PROVINCIA, CLIENTES.DISTANCIA,
         COUNT(VISITASCOMERCIALES.CODIGO) AS VISITAS
		 FROM CLIENTES, VISITASCOMERCIALES
		 WHERE CLIENTES.CODIGO = VISITASCOMERCIALES.CLIENTE
		       AND CLIENTES.VENDEDOR               = :comercial
               AND VISITASCOMERCIALES.FECHA BETWEEN :fecha_desde
		       AND                                  :fecha_hasta
	     GROUP BY CLIENTES.CODIGO, CLIENTES.DESCRIPCION, CLIENTES.PROVINCIA, CLIENTES.DISTANCIA
		 ORDER BY COUNT(VISITASCOMERCIALES.CODIGO) DESC";

        $bindings = [
            'comercial'   => $comercial,
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
        ];

        $clientes = DB::select($queryClientes, $bindings);

        $res = [];

        foreach ($clientes as $cliente) {
            $clienteArray = (array) $cliente;

            $bindings['cliente'] = $cliente->CLIENTE;

            //Número visitas comerciales

            $sql =  "SELECT SUM(HVENTASARTICULO.IMPORTEVENTA) AS VENTAS
				  FROM HVENTASARTICULO
				  WHERE CLIENTE               =            :cliente
				    AND HVENTASARTICULO.FECHA BETWEEN     :fecha_desde
					AND                                   :fecha_hasta";

            $result = DB::select($sql, $bindings);
            $clienteArray['VENTAS'] = $result[0]->VENTAS;

            $res[] = $clienteArray;
        }

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerControlVisitas(Request $request)
    {
        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;
        $comercial   = $request->comercial;

        DB::statement("EXECUTE PROCEDURE RELLENAR_TMP_CONTROL_VISITAS(:fecha_desde, :fecha_hasta, :comercial)", [
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
            'comercial'   => $comercial,
        ]);

        $sql = "
            SELECT CANTIDAD_VISITAS_COMERCIALES, COUNT(CLIENTE) AS CLIENTES
            FROM TMP_CONTROL_VISITAS
            GROUP BY CANTIDAD_VISITAS_COMERCIALES
            ORDER BY CANTIDAD_VISITAS_COMERCIALES
        ";

        $visitas = DB::select($sql);

        $res = [];

        //Número clientes visitados

        $sql =  "SELECT COUNT(DISTINCT VISITASCOMERCIALES.CLIENTE) AS CLIENTES_VISITADOS
                FROM VISITASCOMERCIALES, CLIENTES
                WHERE VISITASCOMERCIALES.CLIENTE = CLIENTES.CODIGO
                    AND VISITASCOMERCIALES.FECHA BETWEEN :fecha_desde AND :fecha_hasta
                    AND CLIENTES.VENDEDOR = :comercial";

        $resultClientesVisitados = DB::select($sql, [
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
            'comercial'   => $comercial,
        ]);



        $res['VISITAS'] = $visitas;
        $res['CLIENTES_VISITADOS'] = $resultClientesVisitados[0]->CLIENTES_VISITADOS;


        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerControlVisitasExtendido(Request $request)
    {
        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;
        $comercial   = $request->comercial;

        $bindings = [
            'comercial'   => $comercial,
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
        ];

        $sqlClientes = "SELECT CLIENTES.CODIGO AS CLIENTE, CLIENTES.DESCRIPCION, CLIENTES.PROVINCIA, CLIENTES.DISTANCIA,
                COUNT(VISITASCOMERCIALES.VENDEDOR) AS VISITAS,
                VISITASCOMERCIALES.EXPEDIENTE
            FROM CLIENTES
            JOIN VISITASCOMERCIALES ON CLIENTES.CODIGO = VISITASCOMERCIALES.CLIENTE
            WHERE VISITASCOMERCIALES.VENDEDOR = :comercial
            AND VISITASCOMERCIALES.FECHA BETWEEN :fecha_desde AND :fecha_hasta
            GROUP BY CLIENTES.CODIGO, CLIENTES.DESCRIPCION, CLIENTES.PROVINCIA, CLIENTES.DISTANCIA, VISITASCOMERCIALES.EXPEDIENTE
            ORDER BY COUNT(VISITASCOMERCIALES.CODIGO) DESC
        ";

        $clientes = DB::select($sqlClientes, $bindings);

        $res = [];

        foreach ($clientes as $cliente) {
            $clienteArray = (array) $cliente;

            $bindings['cliente'] = $cliente->CLIENTE;

            //calcular ventas por cliente

            $sql =  "SELECT SUM(HVENTASARTICULO.IMPORTEVENTA) AS VENTAS
				    FROM HVENTASARTICULO
				   WHERE CLIENTE = :cliente
				     AND HVENTASARTICULO.FECHA BETWEEN :fecha_desde AND :fecha_hasta";

            $result = DB::select($sql, $bindings);
            $clienteArray['VENTAS'] = $result[0]->VENTAS;

            $res[] = $clienteArray;
        }

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerFacturasClientes(Request $request)
    {
        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;
        $comercial   = $request->comercial;

        $sql = "SELECT FRASCLI.SERIE AS SERIE, FRASCLI.CODIGO AS NUMERO_FACTURA, FRASCLI.CLIENTE AS CLIENTE,
            FRASCLI.FECHA, FRASCLI.TOTAL_IMPORTENETO AS IMPORTE, CLIENTES.DESCRIPCION AS DES_CLIENTE
        FROM FRASCLI
        JOIN CLIENTES ON FRASCLI.CLIENTE = CLIENTES.CODIGO
        WHERE CLIENTES.VENDEDOR = :comercial
        AND FRASCLI.FECHA BETWEEN :fecha_desde AND :fecha_hasta
        ORDER BY FRASCLI.CLIENTE, FRASCLI.FECHA
        ";

        $res = DB::select($sql, [
            'comercial'   => $comercial,
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
        ]);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerListadoClientes(Request $request)
    {
        $comercial = $request->comercial;
        $fecha_alta = $request->fecha_alta;
        $fecha_desde_clientes = $request->fecha_desde_clientes;
        $fecha_visitado = $request->fecha_visitado;
        $nombre_cliente = $request->nombre_cliente;
        $provincia = $request->provincia;
        $poblacion = $request->poblacion;
        $categoria_cliente = $request->categoria_cliente;

        $accesoComercial = "
        SELECT acceso_todos_clientes_tc
        FROM vendedores
        WHERE codigo = :comercial
    ";

        $resP = DB::select($accesoComercial, [
            'comercial' => $comercial
        ]);

        $acceso = strtoupper(trim($resP[0]->ACCESO_TODOS_CLIENTES_TC ?? $resP[0]->acceso_todos_clientes_tc ?? 'N'));

        $sql = "
        SELECT CLIENTES.CODIGO, CLIENTES.DESCRIPCION, CLIENTES.FECHA_ALTA, CLIENTES.PROVINCIA,
               CLIENTES.POBLACION, CLIENTES.TELEFONOFIJO, CLIENTES.TELEFONOMOVIL,
               CATEGORIASCLIENTES.DESCRIPCIONCATEGORIA,
               SUM(HVENTASARTICULO.IMPORTEBASEVENTA) AS TIMPORTEBASE,
               SUM(HVENTASARTICULO.IMPORTEVENTA) - SUM(HVENTASARTICULO.IMPORTECOSTE) AS MARGEN
        FROM CLIENTES
        LEFT JOIN HVENTASARTICULO ON HVENTASARTICULO.CLIENTE = CLIENTES.CODIGO
        LEFT JOIN CATEGORIASCLIENTES ON CATEGORIASCLIENTES.CODIGO = CLIENTES.CATEGORIA
        WHERE CLIENTES.BLOQUEADO <> 'S'
    ";

        $bindings = [];

        if ($acceso !== 'S') {
            $sql .= " AND CLIENTES.VENDEDOR = :comercial";
            $bindings['comercial'] = $comercial;
        }

        if ($fecha_alta) {
            $sql .= " AND CLIENTES.FECHA_ALTA >= :fecha_alta";
            $bindings['fecha_alta'] = $fecha_alta;
        }

        if ($fecha_desde_clientes) {
            $sql .= " AND HVENTASARTICULO.FECHA >= :fecha_desde_clientes";
            $bindings['fecha_desde_clientes'] = $fecha_desde_clientes;
        }

        if ($fecha_visitado) {
            $sql .= " AND CLIENTES.CODIGO NOT IN (
            SELECT CLIENTE
            FROM VISITASCOMERCIALES
            WHERE VENDEDOR = :comercial_visita
              AND FECHA >= :fecha_visitado
        )";

            $bindings['comercial_visita'] = $comercial;
            $bindings['fecha_visitado'] = $fecha_visitado;
        }

        if ($nombre_cliente) {
            $sql .= " AND UPPER(CLIENTES.DESCRIPCION) LIKE :nombre_cliente";
            $bindings['nombre_cliente'] = '%' . strtoupper($nombre_cliente) . '%';
        }

        if ($provincia && $provincia !== "Todas") {
            $sql .= " AND TRIM(CLIENTES.PROVINCIA) = (
            SELECT DESCRIPCION
            FROM PROVINCIAS
            WHERE CODIGO = :provincia
        )";

            $bindings['provincia'] = $provincia;
        }

        if ($poblacion && $poblacion !== "Todas" && $provincia !== "Todas") {
            $sql .= " AND TRIM(CLIENTES.POBLACION) = (
            SELECT DESCRIPCION
            FROM POBLACIONES
            WHERE CODIGO = :poblacion
        )";

            $bindings['poblacion'] = $poblacion;
        }

        if ($categoria_cliente && $categoria_cliente !== "Todas") {
            $sql .= " AND CLIENTES.CATEGORIA = :categoria_cliente";
            $bindings['categoria_cliente'] = $categoria_cliente;
        }

        $sql .= "
        GROUP BY CLIENTES.CODIGO, CLIENTES.DESCRIPCION, CLIENTES.FECHA_ALTA, CLIENTES.PROVINCIA, CLIENTES.POBLACION,
                 CLIENTES.TELEFONOFIJO, CLIENTES.TELEFONOMOVIL, CATEGORIASCLIENTES.DESCRIPCIONCATEGORIA
    ";

        $res = DB::select($sql, $bindings);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerListadoVentasClientesArticulos(Request $request)
    {

        $fecha_desde  = $request->fecha_desde;
        $fecha_hasta  = $request->fecha_hasta;
        $comercial    = $request->comercial;
        $descripcion_articulo = $request->descripcion_articulo;
        $provincia    = $request->provincia;
        $poblacion    = $request->poblacion;
        $s_g_f        = $request->s_g_f;
        $codigo_s_g_f = $request->codigo_s_g_f;
        $tipo_orden   = $request->tipo_orden;
        $orden_asc_desc = $request->orden_asc_desc;

        $sql = "SELECT CLIENTES.CODIGO AS CLIENTE,
               CLIENTES.DESCRIPCION AS DES_CLIENTE,
               ARTICULOS.CODIGO AS ARTICULO,
               ARTICULOS.DESCRIPCION AS DES_ARTICULO,
               SUM(HVENTASARTICULO.IMPORTEBASEVENTA) AS TIMPORTEBASE,
               SUM(HVENTASARTICULO.CANTIDAD) AS TOTAL_CANTIDAD
        FROM HVENTASARTICULO
        JOIN CLIENTES ON HVENTASARTICULO.CLIENTE = CLIENTES.CODIGO
        JOIN ARTICULOS ON HVENTASARTICULO.ARTICULO = ARTICULOS.CODIGO
        WHERE HVENTASARTICULO.FECHA BETWEEN :fecha_desde AND :fecha_hasta
        AND CLIENTES.VENDEDOR = :comercial";

        $bindings = [
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
            'comercial'   => $comercial,
        ];

        if (!empty($descripcion_articulo)) {
            $sql .= " AND UPPER(ARTICULOS.DESCRIPCION) LIKE :descripcion_articulo";
            $bindings['descripcion_articulo'] = '%' . strtoupper($descripcion_articulo) . '%';
        }

        if ($provincia && $provincia !== "Todas") {
            $sql .= " AND TRIM(CLIENTES.PROVINCIA) = (
                SELECT DESCRIPCION FROM PROVINCIAS WHERE CODIGO = :provincia
            )";
            $bindings['provincia'] = $provincia;
        }

        if ($poblacion && $poblacion !== "Todas" && $provincia !== "Todas") {
            $sql .= " AND TRIM(CLIENTES.POBLACION) = (
                SELECT DESCRIPCION FROM POBLACIONES WHERE CODIGO = :poblacion
            )";
            $bindings['poblacion'] = $poblacion;
        }

        /* if (!empty($provincia) && $provincia !== 'Todas') {
            $sql_aux = "SELECT descripcion FROM provincias WHERE codigo = :provincia";
            $row_aux = DB::select($sql_aux, ['provincia' => $provincia]);
            $provincia_desc = $row_aux[0]->descripcion ?? '';
            if ($provincia_desc) {
                $sql .= " AND TRIM(CLIENTES.PROVINCIA) = :provincia_desc";
                $bindings['provincia_desc'] = $provincia_desc;
            }
        }

        if (!empty($poblacion) && $poblacion !== 'Todas' && $provincia !== 'Todas') {
            $sql_aux = "SELECT descripcion FROM poblaciones WHERE codigo = :poblacion";
            $row_aux = DB::select($sql_aux, ['poblacion' => $poblacion]);
            $poblacion_desc = $row_aux[0]->descripcion ?? '';
            if ($poblacion_desc) {
                $sql .= " AND TRIM(CLIENTES.POBLACION) = :poblacion_desc";
                $bindings['poblacion_desc'] = $poblacion_desc;
            }
        } */

        if ($s_g_f !== 'Todas') {
            if ($s_g_f == 1 && $codigo_s_g_f !== 'Todas') {
                $sql .= " AND ARTICULOS.SECCION = :codigo_s_g_f";
                $bindings['codigo_s_g_f'] = $codigo_s_g_f;
            }
            if ($s_g_f == 2 && $codigo_s_g_f !== 'Todas') {
                $sql .= " AND ARTICULOS.GRUPO = :codigo_s_g_f";
                $bindings['codigo_s_g_f'] = $codigo_s_g_f;
            }
            if ($s_g_f == 3 && $codigo_s_g_f !== 'Todas') {
                $sql .= " AND ARTICULOS.FAMILIA = :codigo_s_g_f";
                $bindings['codigo_s_g_f'] = $codigo_s_g_f;
            }
        }

        $sql .= " GROUP BY CLIENTES.CODIGO, CLIENTES.DESCRIPCION, ARTICULOS.CODIGO, ARTICULOS.DESCRIPCION";

        // Order
        if ($tipo_orden == 1) {
            $sql .= " ORDER BY CLIENTES.CODIGO, ARTICULOS.CODIGO";
        }

        if ($tipo_orden == 2) {
            $sql .= " ORDER BY CLIENTES.CODIGO, SUM(HVENTASARTICULO.CANTIDAD)";
        }

        if ($orden_asc_desc == 1) {
            $sql .= " ASC";
        }

        if ($orden_asc_desc == 2) {
            $sql .= " DESC";
        }

        // Execute the query
        $res = DB::select($sql, $bindings);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerVentasComparativaAnual(Request $request)
    {
        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;
        $tipo = $request->tipo;
        $comercial = $request->comercial;

        DB::statement('EXECUTE PROCEDURE RELLENA_TPMLSTMESES_COMPARATIVA(:fecha_desde, :fecha_hasta, :tipo, 0)', [
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
            'tipo' => $tipo,
        ]);

        $sql = "SELECT ANO,
                SUM(ENERO_VTA) AS ENERO_VTA,
                SUM(ENERO_BFO) AS ENERO_BFO,
                SUM(ENERO_CAN) AS ENERO_CAN,
                SUM(ENERO_CAN * ARTICULOS.CC) AS ENERO_LITROS,
                SUM(FEBRERO_VTA) AS FEBRERO_VTA,
                SUM(FEBRERO_BFO) AS FEBRERO_BFO,
                SUM(FEBRERO_CAN) AS FEBRERO_CAN,
                SUM(FEBRERO_CAN * ARTICULOS.CC) AS FEBRERO_LITROS,
                SUM(MARZO_VTA) AS MARZO_VTA,
                SUM(MARZO_BFO) AS MARZO_BFO,
                SUM(MARZO_CAN) AS MARZO_CAN,
                SUM(MARZO_CAN * ARTICULOS.CC) AS MARZO_LITROS,
                SUM(ABRIL_VTA) AS ABRIL_VTA,
                SUM(ABRIL_BFO) AS ABRIL_BFO,
                SUM(ABRIL_CAN) AS ABRIL_CAN,
                SUM(ABRIL_CAN * ARTICULOS.CC) AS ABRIL_LITROS,
                SUM(MAYO_VTA) AS MAYO_VTA,
                SUM(MAYO_BFO) AS MAYO_BFO,
                SUM(MAYO_CAN) AS MAYO_CAN,
                SUM(MAYO_CAN * ARTICULOS.CC) AS MAYO_LITROS,
                SUM(JUNIO_VTA) AS JUNIO_VTA,
                SUM(JUNIO_BFO) AS JUNIO_BFO,
                SUM(JUNIO_CAN) AS JUNIO_CAN,
                SUM(JUNIO_CAN * ARTICULOS.CC) AS JUNIO_LITROS,
                SUM(JULIO_VTA) AS JULIO_VTA,
                SUM(JULIO_BFO) AS JULIO_BFO,
                SUM(JULIO_CAN) AS JULIO_CAN,
                SUM(JULIO_CAN * ARTICULOS.CC) AS JULIO_LITROS,
                SUM(AGOSTO_VTA) AS AGOSTO_VTA,
                SUM(AGOSTO_BFO) AS AGOSTO_BFO,
                SUM(AGOSTO_CAN) AS AGOSTO_CAN,
                SUM(AGOSTO_CAN * ARTICULOS.CC) AS AGOSTO_LITROS,
                SUM(SEPTIEMBRE_VTA) AS SEPTIEMBRE_VTA,
                SUM(SEPTIEMBRE_BFO) AS SEPTIEMBRE_BFO,
                SUM(SEPTIEMBRE_CAN) AS SEPTIEMBRE_CAN,
                SUM(SEPTIEMBRE_CAN * ARTICULOS.CC) AS SEPTIEMBRE_LITROS,
                SUM(OCTUBRE_VTA) AS OCTUBRE_VTA,
                SUM(OCTUBRE_BFO) AS OCTUBRE_BFO,
                SUM(OCTUBRE_CAN) AS OCTUBRE_CAN,
                SUM(OCTUBRE_CAN * ARTICULOS.CC) AS OCTUBRE_LITROS,
                SUM(NOVIEMBRE_VTA) AS NOVIEMBRE_VTA,
                SUM(NOVIEMBRE_BFO) AS NOVIEMBRE_BFO,
                SUM(NOVIEMBRE_CAN) AS NOVIEMBRE_CAN,
                SUM(NOVIEMBRE_CAN * ARTICULOS.CC) AS NOVIEMBRE_LITROS,
                SUM(DICIEMBRE_VTA) AS DICIEMBRE_VTA,
                SUM(DICIEMBRE_BFO) AS DICIEMBRE_BFO,
                SUM(DICIEMBRE_CAN) AS DICIEMBRE_CAN,
                SUM(DICIEMBRE_CAN * ARTICULOS.CC) AS DICIEMBRE_LITROS
            FROM TMPLSTMESES
            JOIN PROYECTOS ON TMPLSTMESES.PROYECTO = PROYECTOS.CODIGO
            JOIN ARTICULOS ON TMPLSTMESES.ARTICULO = ARTICULOS.CODIGO
            JOIN CLIENTES ON TMPLSTMESES.CLIENTE = CLIENTES.CODIGO
            WHERE TMPLSTMESES.PROYECTO = 1
            AND TMPLSTMESES.CLIENTE IN (SELECT CODIGO FROM CLIENTES WHERE VENDEDOR = :comercial)
            GROUP BY ANO
            ORDER BY ANO
        ";

        $results = DB::select($sql, [
            'comercial' => $comercial
        ]);

        return response()->json(UtilsHelper::utf8ize($results));
    }

    public function obtenerVentasProvinciaAnual(Request $request)
    {
        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;
        $comercial = $request->comercial;

        DB::select('EXECUTE PROCEDURE RELLENA_TMPLST_PROVINCIAS_ANUAL(:comercial, :fecha_desde, :fecha_hasta)', [
            'comercial'   => $comercial,
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
        ]);

        $res = DB::select('SELECT PROVINCIA, ANO_ACTUAL, ANO_ANTERIOR1, ANO_ANTERIOR2 FROM TMPLST_PROVINCIAS_ANUAL');


        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerVentasClientesAnual(Request $request)
    {
        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;
        $comercial = $request->comercial;
        $descripcion = $request->descripcion;

        DB::statement('EXECUTE PROCEDURE RELLENA_TMPLST_CLIENTES_ANUAL(:comercial, :fecha_desde, :fecha_hasta)', [
            'comercial'   => $comercial,
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
        ]);


        $res = DB::select('SELECT CLIENTE, ANO_ACTUAL, ANO_ANTERIOR1, ANO_ANTERIOR2
                              FROM TMPLST_CLIENTES_ANUAL
                              WHERE UPPER(CLIENTE) LIKE UPPER(:descripcion)', [
            'descripcion' => '%' . $descripcion . '%',
        ]);

        return response()->json(UtilsHelper::utf8ize($res));
    }
}
