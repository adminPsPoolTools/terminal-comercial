<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class IncidenciasController extends Controller
{
    public function obtenerPorCliente(Request $request)
    {
        $query = "SELECT cliente,linea,fecha,usuario,CAST(INCIDENCIA AS VARCHAR(10000)) AS INCIDENCIA,resuelta,comunicada,vendedor
            from incidencias_clientes
            where cliente	   = ?
            order by linea";

        $res = DB::select($query, [$request->cliente]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerPorExpediente(Request $request)
    {
        $query  = "select * from incidencias_expedientes where expediente = ? order by linea";
        $res = DB::select($query, [$request->expediente]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerPorClienteYLinea(Request $request)
    {
        $query =  "SELECT * FROM INCIDENCIAS_CLIENTES
            WHERE cliente = :cliente
            AND linea  = :linea";

        $res = DB::select($query, ['cliente' => $request->cliente, 'linea' => $request->linea]);
        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function obtenerPorExpedienteYLinea(Request $request)
    {
        $query =  "SELECT * FROM INCIDENCIAS_CLIENTES
            WHERE expediente = :expediente
            AND linea  = :linea";

        $res = DB::select($query, ['expediente' => $request->expediente, 'linea' => $request->linea]);
        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function obtenerNuevaLinea()
    {
        $sql    = "SELECT MAX(LINEA)+1 AS NUEVA_LINEA FROM INCIDENCIAS_CLIENTES";
        $res = DB::select($sql);
        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function actualizarIncidenciaCliente(Request $request)
    {
        $query = 'UPDATE incidencias_clientes
            SET fecha      = :fecha,
                incidencia = :incidencia,
                resuelta   = :resuelta,
                comunicada = :comunicada,
                vendedor   = :vendedor
            WHERE cliente  = :cliente
            AND linea      = :linea;
            ';

        $bindings = [
            'fecha'      => $request->fecha,
            'incidencia' => $request->incidencia,
            'resuelta'   => $request->resuelta,
            'comunicada' => $request->comunicada,
            'vendedor'   => $request->vendedor,
            'cliente'    => $request->cliente,
            'linea'      => $request->linea
        ];
        DB::select($query, $bindings);
        return response()->json(['msg' => 'Incidencia actualizada']);
    }

    public function actualizarIncidenciaExpediente(Request $request)
    {
        $query = "UPDATE incidencias_expedientes
          SET fecha = :fecha,
              incidencia = :incidencia,
              resuelta = :resuelta,
              comunicada = :comunicada
          WHERE expediente = :expediente
          AND linea = :linea";

        $bindings = [
            'fecha'      => $request->fecha,
            'incidencia' => $request->incidencia,
            'resuelta'   => $request->resuelta,
            'comunicada' => $request->comunicada,
            'expediente' => $request->expediente,
            'linea'      => $request->linea
        ];

        DB::select($query, $bindings);
        return response()->json(['msg' => 'Incidencia actualizada']);
    }

    public function crearIncidenciaCliente(Request $request)
    {
        $query = "INSERT INTO incidencias_clientes (CLIENTE, linea, fecha, incidencia, resuelta, comunicada, vendedor, usuario)
            VALUES (:cliente, :linea, :fecha, :incidencia, :resuelta, :comunicada, :vendedor, :usuario);
            ";

        $bindings = [
            'cliente'    => $request->cliente,
            'linea'      => $request->linea,
            'fecha'      => $request->fecha,
            'incidencia' => $request->incidencia,
            'resuelta'   => $request->resuelta,
            'comunicada' => $request->comunicada,
            'vendedor'   => $request->vendedor,
            'usuario'   => $request->vendedor,
        ];

        DB::select($query, $bindings);
        return response()->json(['msg' => 'Incidencia creada']);
    }

    public function borrarIncidencia(Request $request)
    {
        $query = "DELETE FROM INCIDENCIAS_CLIENTES "
            . "WHERE CLIENTE = :cliente
		 AND linea   = :linea ";

        DB::select($query, ['cliente' => $request->cliente, 'linea' => $request->linea]);
        return response()->json(['msg' => 'Incidencia borrada']);
    }

    public function obtenerDetalleIncidenciaCliente(Request $request)
    {
        $query = "SELECT * FROM incidencias_clientes
                WHERE cliente = :cliente
                AND linea   = :linea";

        $res = DB::select($query, ['cliente' => $request->cliente, 'linea' => $request->linea]);
        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function obtenerDetalleIncidenciaExpediente(Request $request)
    {
        $query = "SELECT * FROM incidencias_expedientes
                WHERE expediente = :expediente
                AND linea   = :linea";

        $res = DB::select($query, ['expediente' => $request->expediente, 'linea' => $request->linea]);
        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function obtenerSelectEstado()
    {
        $query = "SELECT DISTINCT(ESTADO) AS ESTADO
				    FROM INCIDENCIAS_SAT";

        $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function buscarIncidencias(Request $request)
    {
        // Comprobar si el comercial tiene acceso a todas las incidencias
        $resAcceso = DB::select("
        SELECT acceso_todos_clientes_tc
        FROM vendedores
        WHERE codigo = :comercial
    ", ['comercial' => $request->comercial]);

        $acceso = strtoupper(trim(
            $resAcceso[0]->ACCESO_TODOS_CLIENTES_TC
                ?? $resAcceso[0]->acceso_todos_clientes_tc
                ?? 'N'
        ));

        $sql = "SELECT INCIDENCIAS_SAT.CODIGO, INCIDENCIAS_SAT.FECHA, CLIENTES.CODIGO AS C_CODIGO,
                   CLIENTES.DESCRIPCION AS CLIENTE, ARTICULOS.DESCRIPCION AS ARTICULO, INCIDENCIAS_SAT.ESTADO
              FROM INCIDENCIAS_SAT
              LEFT JOIN ARTICULOS ON ARTICULOS.CODIGO = INCIDENCIAS_SAT.O_ARTICULO
              LEFT JOIN CLIENTES  ON CLIENTES.CODIGO  = INCIDENCIAS_SAT.CLIENTE
             WHERE INCIDENCIAS_SAT.FECHA >= :fecha_desde";

        $bindings = [
            'fecha_desde' => $request->fecha_desde,
        ];

        // Si NO tiene acceso total, filtrar por su comercial
        if ($acceso !== 'S') {
            $sql .= " AND (INCIDENCIAS_SAT.USUARIO = :comercial OR CLIENTES.VENDEDOR = :comercial1)";
            $bindings['comercial']  = $request->comercial;
            $bindings['comercial1'] = $request->comercial;
        }

        if ($request->estado !== "Todos") {
            $sql .= " AND INCIDENCIAS_SAT.ESTADO LIKE :estado";
            $bindings['estado'] = $request->estado;
        }

        if (!empty($request->input_codigo_sat)) {
            $codigoSat = $request->input_codigo_sat;
            $sql .= " AND INCIDENCIAS_SAT.CODIGO = '" .  $codigoSat . "'";
            $bindings['codigosat'] = $request->input_codigo_sat;
        }

        if (!empty($request->input_codigo_articulo)) {
            $busquedaArt = $request->input_codigo_articulo;

            $sql .= " AND (
        UPPER(ARTICULOS.CODIGO) LIKE UPPER(:codigoart)
        OR UPPER(ARTICULOS.DESCRIPCION) LIKE UPPER(:descripcionart))";

            $bindings['codigoart'] = '%' . $busquedaArt . '%';
            $bindings['descripcionart'] = '%' . $busquedaArt . '%';
        }

        if (!empty($request->input_cliente)) {
            $busquedaCliente = $request->input_cliente;

            $sql .= " AND (
        UPPER(CLIENTES.CODIGO) LIKE UPPER(:codigocli)
        OR UPPER(CLIENTES.DESCRIPCION) LIKE UPPER(:descripcioncli))";

            $bindings['codigocli'] = '%' . $busquedaCliente . '%';
            $bindings['descripcioncli'] = '%' . $busquedaCliente . '%';
        }

        $sql .= " ORDER BY INCIDENCIAS_SAT.FECHA DESC";

        $res = DB::select($sql, $bindings);

        return response()->json(UtilsHelper::utf8ize($res));
    }
}
