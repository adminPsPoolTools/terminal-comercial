<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class TiquetsController extends Controller
{
    public function obtenerFichaClientes(Request $request)
    {
        $bindings = [];
        if(empty($request->cliente))
        {
            $query = "SELECT tiquets.codigo, estado, fecha, baseimponible, importeconiva, titulo, clientes.descripcion as descripcion_cliente
            from tiquets
            LEFT JOIN CLIENTES            ON clientes.codigo = tiquets.cliente
            LEFT JOIN VENDEDORES          ON VENDEDORES.CODIGO = :comercial1
            LEFT JOIN DIRECCIONESCLIENTES ON DIRECCIONESCLIENTES.CLIENTE = tiquets.CLIENTE AND DIRECCIONESCLIENTES.LINEA = tiquets.LINEADIRECCIONENVIO
            LEFT JOIN PROVINCIAS          ON PROVINCIAS.DESCRIPCION = DIRECCIONESCLIENTES.PROVINCIA

            where fecha >= :fecha_desde
            and ((clientes.vendedor = :comercial2 )
                    or (:comercial3 = 1)
                    or (:comercial4 > 100)
                    or (VENDEDORES.ACCESO_TODOS_CLIENTES_TC = 'S')) ";

            $bindings = [
                'comercial1' => $request->comercial,
                'fecha_desde' => $request->fecha_desde,
                'comercial2' => $request->comercial,
                'comercial3' => $request->comercial,
                'comercial4' => $request->comercial
            ];
        }
        else {
            $query = "SELECT tiquets.codigo, estado, fecha, baseimponible, importeconiva, titulo, clientes.descripcion as descripcion_cliente
             from tiquets
             LEFT JOIN CLIENTES ON clientes.codigo = tiquets.cliente
             LEFT JOIN DIRECCIONESCLIENTES ON DIRECCIONESCLIENTES.CLIENTE = tiquets.CLIENTE AND DIRECCIONESCLIENTES.LINEA = tiquets.LINEADIRECCIONENVIO
             LEFT JOIN PROVINCIAS          ON PROVINCIAS.DESCRIPCION = DIRECCIONESCLIENTES.PROVINCIA
            WHERE tiquets.cliente = :cliente";

            $bindings = [
                'cliente' => $request->cliente
            ];

        }

        if(!empty($titulo))
        {
            $query .=  " AND upper(titulo) like :titulo";
            $bindings['titulo'] = '%'.strtoupper($titulo).'%';
        }
        $query .= " ORDER BY tiquets.codigo desc";

        $res = DB::select($query, $bindings);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    //informe pedido
    public function obtenerLineasTiquetPorPedido(Request $request)
    {
        $sql = "SELECT DISTINCT tiquet
            FROM lintiquets
            WHERE pedido = :pedido
            ORDER BY tiquet";

        $bindings = ['pedido' => $request->pedido];

        $res = DB::select($sql, $bindings);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    //informe albaran
    public function obtenerInformacionAlbaran(Request $request)
    {
        $sql = "SELECT proyectos.razonsocial as razonsocial, proyectos.cif, proyectos.direccion, proyectos.cp,
                   proyectos.poblacion, proyectos.provincia, proyectos.telefono, proyectos.fax, proyectos.email,

                   clientes.codigo as codigo_cliente, clientes.descripcion as descripcion_cliente, clientes.cif as cif_cliente,
                   clientes.direccion as direccion_cliente, clientes.cp as cp_cliente, clientes.poblacion as poblacion_cliente,
                   clientes.provincia as provincia_cliente, clientes.telefonofijo as telefonofijo_cliente,
                   clientes.fax as fax_cliente, clientes.correo as correo_cliente,

                   tiquets.codigo as codigo_tiquet, tiquets.fecha, tiquets.titulo, tiquets.descripcion as descripcion_tiquet,
                   tiquets.baseimponible, tiquets.importeconiva, tiquets.presupuesto, tiquets.pedido, tiquets.factura,
                   tiquets.serie, CAST(tiquets.pdto AS FLOAT) AS PDTO, tiquets.importedto, tiquets.agencia,
                   tiquets.nexpedicion, tiquets.numerobultos, tiquets.pesototal, tiquets.lineadireccionenvio,
                   tiquets.proyecto as proyecto,

                   impuestos.iva,

                   agenciat.descripcion as descripcion_agencia, agenciat.link_seguimiento

            FROM tiquets
            LEFT JOIN clientes ON clientes.codigo = tiquets.cliente
            LEFT JOIN proyectos ON proyectos.codigo = :proyecto
            LEFT JOIN impuestos ON impuestos.codigo = tiquets.impuesto
            LEFT JOIN agenciat ON agenciat.codigo = tiquets.agencia
            WHERE tiquets.codigo = :albaran";

        $bindings = [
            'proyecto' => $request->proyecto,
            'albaran' => $request->albaran
        ];

        $result = DB::select($sql, $bindings);

        return response()->json(UtilsHelper::utf8ize($result[0]));
    }


    public function obtenerArticulosAlbaran(Request $request)
    {
        $sql = "SELECT articulo, descripcion,
        CAST(cantidad AS FLOAT) AS CANTIDAD,
        CAST(pvp AS FLOAT) AS PVP,
        dto,
        CAST(pvpfinal AS FLOAT) AS PVPFINAL,
        CAST(importe AS FLOAT) AS IMPORTE,
        lintiquets.comentario
        FROM lintiquets
        JOIN articulos ON articulos.codigo = lintiquets.articulo
        WHERE tiquet = :albaran";

        $bindings = [
        'albaran' => $request->albaran
        ];

        $result = DB::select($sql, $bindings);
        return response()->json(UtilsHelper::utf8ize($result));
    }

}
