<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class ExpedientesController extends Controller
{

    public function obtenerEstados()
    {
        $query = "SELECT * FROM ESTADOS_EXPEDIENTES"; // cambio 19/06/2026 pero puede que falle para otra cosa y hay que poner la otra sql
        // $query = "SELECT  *
        //           FROM ESTADOS_EXPEDIENTES ee
        //           JOIN ESTADOS_AGENDA ea
        //           ON ee.ESTADO_AGENDA_ASOCIADO = ea.CODIGO
        //           WHERE ea.BLOQUEADO <> 'S'";
        $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));
    }


    public function obtenerPorCodigo(Request $request)
    {
        $query = "SELECT EXPEDIENTES.DESCRIPCION, EXPEDIENTES.DIRECCION, EXPEDIENTES.APCORREOS, EXPEDIENTES.CP, EXPEDIENTES.POBLACION,
                         EXPEDIENTES.COMARCA, EXPEDIENTES.PROVINCIA, EXPEDIENTES.PAIS,
                         EXPEDIENTES.CORREO AS correo, WEB, FECHA_ALTA, COMENTARIO, COMENTARIO_INTERNO_EXPEDIENTE, COMENTARIO_COMERCIAL_EXPEDIENTE,
                         EXPEDIENTES.CODIGO, COMERCIAL, LIBRE1_EXPEDIENTE, LIBRE2_EXPEDIENTE, LIBRE3_EXPEDIENTE, LIBRE4_EXPEDIENTE, LIBRE5_EXPEDIENTE,
                         CAST (LIBRE6_EXPEDIENTE AS VARCHAR(10000)) AS LIBRE6_EXPEDIENTE, CAST (LIBRE7_EXPEDIENTE AS VARCHAR(10000)) AS LIBRE7_EXPEDIENTE,
                         CAST (LIBRE8_EXPEDIENTE AS VARCHAR(10000)) AS LIBRE8_EXPEDIENTE, CAST (LIBRE9_EXPEDIENTE AS VARCHAR(10000)) AS LIBRE9_EXPEDIENTE,
                         CAST (LIBRE10_EXPEDIENTE AS VARCHAR(10000)) AS LIBRE10_EXPEDIENTE, ESTADO
                    FROM expedientes, vendedores
                   where EXPEDIENTES.codigo = ?
                     and expedientes.comercial = vendedores.codigo";

        $res = DB::select($query, [$request->expediente]);

        return response()->json(
            count($res) > 0 ?
                UtilsHelper::utf8ize($res[0]) : null
        );
    }

    public function asignarCliente(Request $request)
    {
        $query = "INSERT INTO EXPEDIENTES_CLIENTES
            VALUES(? , ?, ?)";

        $res = DB::select($query, [$request->expediente, $request->cliente, $request->comentario]);
        return response()->json(true);
    }

    public function borrarCliente(Request $request)
    {
        $query = "DELETE FROM EXPEDIENTES_CLIENTES
            WHERE EXPEDIENTE = :expediente
            AND CLIENTE = :cliente ";

        $res = DB::select($query, [
            'expediente' => $request->expediente,
            'cliente' => $request->cliente
        ]);

        return response()->json(true);
    }

    public function obtenerContactos(Request $request)
    {
        $query = 'SELECT LINEA,NOMBRE,CARGO,TELEFONOFIJO,TELEFONOMOVIL,CORREO,FAX, CAST(COMENTARIO_CONTACTO AS VARCHAR(10000)) AS COMENTARIO_CONTACTO
            FROM EXPEDIENTESCONTACTOS WHERE EXPEDIENTE= :expediente ORDER BY LINEA';

        $res = DB::select($query, ['expediente' => $request->expediente]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerSiguienteId()
    {
        $query = "SELECT GEN_ID(expedientes_codigo_gen,1) AS NUEVO_CODIGO FROM RDB\$DATABASE";
        $res = DB::select($query);
        return response()->json(
            count($res) > 0 ? $res[0] : null
        );
    }

    public function actualizarOCrear(Request $request)
    {

        $query = "update or INSERT INTO EXPEDIENTES
            (CODIGO,DESCRIPCION,DIRECCION,APCORREOS,CP,POBLACION,COMARCA,PROVINCIA,PAIS,CORREO
            ,WEB,COMENTARIO,COMENTARIO_INTERNO_EXPEDIENTE,COMENTARIO_COMERCIAL_EXPEDIENTE,COMERCIAL
            ,COMERCIAL_ALTA,LIBRE1_EXPEDIENTE,LIBRE2_EXPEDIENTE,LIBRE3_EXPEDIENTE,LIBRE4_EXPEDIENTE
            ,LIBRE5_EXPEDIENTE,LIBRE6_EXPEDIENTE,LIBRE7_EXPEDIENTE,LIBRE8_EXPEDIENTE,LIBRE9_EXPEDIENTE
            ,LIBRE10_EXPEDIENTE, ESTADO)

            VALUES (
                :nuevo_codigo,
                :descripcion,
                :direccion,
                :apCorreos,
                :cp,
                :poblacion,
                :comarca,
                :provincia,
                :pais,
                :correo,
                :web,
                :comentario,
                :comentarioInt,
                :comentarioCom,
                :comercialAsig,
                :comercialAlta,
                :libre1,
                :libre2,
                :libre3,
                :libre4,
                :libre5,
                :libre6,
                :libre7,
                :libre8,
                :libre9,
                :libre10,
                :estado
            ) MATCHING (CODIGO)";


        $codigo = $request->codigo;

        $bindings = [
            'nuevo_codigo'   => $codigo,
            'descripcion'    => $request->descripcion,
            'direccion'      => $request->direccion,
            'apCorreos'      => $request->apCorreos,
            'cp'             => $request->cp,
            'poblacion'      => $request->poblacion,
            'comarca'        => $request->comarca,
            'provincia'      => $request->provincia,
            'pais'           => $request->pais,
            'correo'         => $request->correo,
            'web'            => $request->web,
            'comentario'     => $request->comentario,
            'comentarioInt'  => $request->comentarioInt,
            'comentarioCom'  => $request->comentarioCom,
            'comercialAsig'  => $request->comercialAsig,
            'comercialAlta'  => $request->comercialAlta,
            'libre1'         => $request->libre1,
            'libre2'         => $request->libre2,
            'libre3'         => $request->libre3,
            'libre4'         => $request->libre4,
            'libre5'         => $request->libre5,
            'libre6'         => $request->libre6,
            'libre7'         => $request->libre7,
            'libre8'         => $request->libre8,
            'libre9'         => $request->libre9,
            'libre10'        => $request->libre10,
            'estado'         => $request->has('estado') ? $request->estado : null,
        ];

        $res = DB::select($query, $bindings);
        return response()->json(['msg' => 'Valores actualizados']);
    }

    public function obtenerPorCodigoReducido(Request $request)
    {
        $query =  "SELECT * FROM EXPEDIENTES WHERE CODIGO = ?";
        $res = DB::select($query, [$request->codigo]);
        return response()->json(
            count($res) > 0 ? UtilsHelper::utf8ize($res[0]) : null
        );
    }

    public function actualizarOAsignarCliente(Request $request)
    {
        $query = "UPDATE OR INSERT INTO EXPEDIENTES_CLIENTES
            (EXPEDIENTE, CLIENTE)
            VALUES (
                :expediente,
                :cliente,
            ) MATCHING (EXPEDIENTE, CLIENTE)";

        $res = DB::select($query, [
            'expediente' => $request->expediente,
            'cliente'    => $request->cliente,
        ]);

        return response()->json(['msg' => 'Cliente asignado']);
    }

    public function obtenerResultadosSelectExpedientes(Request $request)
    {
        $query = "SELECT CODIGO, DESCRIPCION FROM EXPEDIENTES
         WHERE (
                (BLOQUEADO <> 'S'
                    AND (  COMERCIAL = :comercial1
                        OR COMERCIAL_ALTA = :comercial2
                        OR CAST (:comercial3 as integer) IN (SELECT CODIGO FROM VENDEDORES WHERE ACCESO_TODOS_CLIENTES_TC = 'S')
                        )
                    AND UPPER(DESCRIPCION) LIKE UPPER(:filtro))
                OR CODIGO = 45
                )";

        if ($request->expediente) {
            $query .= " OR CODIGO = :expediente";
        }

        $query .= " ORDER BY CODIGO ASC";

        $bindings = [
            'comercial1' => $request->comercial,
            'comercial2' => $request->comercial,
            'comercial3' => intval($request->comercial),
            'filtro' => "%" . $request->filtro . "%",
            'expediente' => $request->expediente
        ];

        $res = DB::select($query, $bindings);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function buscarExpedientes(Request $request)
    {
        $fecha_desde = $request->fecha_desde;
        $descripcion = $request->descripcion;
        $estado = $request->estado;
        $provincia = $request->provincia;
        $poblacion = $request->poblacion;
        $com_asig = $request->com_asig;
        $cliente_presu = $request->cliente_presu;
        $cliente_asign = $request->cliente_asign;

        $sql = "SELECT e.codigo as codigo, e.fecha_alta, e.descripcion as descripcion, e.comercial, EE.DESCRIPCION AS ESTADO
                FROM expedientes e
                LEFT JOIN expedientes_clientes ON e.codigo = expedientes_clientes.expediente
                LEFT JOIN ESTADOS_EXPEDIENTES EE ON EE.CODIGO = e.ESTADO
                LEFT JOIN CLIENTES ON CLIENTES.CODIGO = EXPEDIENTES_CLIENTES.CLIENTE
                WHERE e.fecha_alta >= :fecha_desde";

        $bindings = ['fecha_desde' => $fecha_desde];

        if (!empty($descripcion)) {
            $sql .= " AND UPPER(e.descripcion) LIKE :descripcion";
            $bindings['descripcion'] = '%' . $descripcion . '%';
        }

        if (!empty($estado) && $estado != "Todos") {
            $sql .= " AND TRIM(e.estado) = :estado";
            $bindings['estado'] = $estado;
        }

        if (!empty($provincia) && $provincia != "Todas") {
            //dd($provincia);
            $provincia_desc = DB::select("SELECT descripcion FROM provincias WHERE codigo = ?", [$provincia]);
            //dd($provincia_desc[0]);
            if (count($provincia_desc) > 0) {
                $sql .= " AND TRIM(e.provincia) = :provincia";
                $bindings['provincia'] = $provincia_desc[0]->DESCRIPCION;
            }
        }

        if (!empty($poblacion) && $poblacion != "Todas" && $provincia !== "Todas") {
            $poblacion_desc = DB::select("SELECT descripcion FROM poblaciones WHERE codigo = ?", [$poblacion]);
            if (count($poblacion_desc) > 0) {
                $sql .= " AND TRIM(e.poblacion) = :poblacion";
                $bindings['poblacion'] = $poblacion_desc[0]->DESCRIPCION;
            }
        }

        if (!empty($com_asig) && $com_asig != 0) {
            $sql .= " AND e.comercial = :com_asig";
            $bindings['com_asig'] = $com_asig;
        }

        if (!empty($cliente_presu)) {
            $sql .= " AND e.codigo IN (
                        SELECT expediente FROM presupuestos
                        WHERE cliente IN (
                            SELECT codigo FROM clientes
                            WHERE CAST(codigo AS VARCHAR(100)) = :cliente_presu
                            OR UPPER(descripcion) LIKE :cliente_presu_like
                            OR UPPER(alias) LIKE :cliente_presu_like1
                        )
                    )";

            $bindings['cliente_presu'] = $cliente_presu;
            $bindings['cliente_presu_like'] = strtoupper('%' . $cliente_presu . '%');
            $bindings['cliente_presu_like1'] = strtoupper('%' . $cliente_presu . '%');
        }

        if (!empty($cliente_asign)) {
            $sql .= " AND expedientes_clientes.cliente IN (
                        SELECT codigo FROM clientes
                        WHERE CAST(codigo AS VARCHAR(100)) = :cliente_asign
                        OR UPPER(descripcion) LIKE :cliente_asign_like
                        OR UPPER(alias) LIKE :cliente_asign_like1
                    )";
            $bindings['cliente_asign'] = $cliente_asign;
            $bindings['cliente_asign_like'] = '%' . strtoupper($cliente_asign) . '%';
            $bindings['cliente_asign_like1'] = '%' . strtoupper($cliente_asign) . '%';
        }

        $sql .= " GROUP BY e.codigo, e.fecha_alta, e.descripcion, e.comercial, ee.descripcion";
        $sql .= " ORDER BY e.codigo DESC";

        $res = DB::select($sql, $bindings);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function subirArchivo(Request $request) {}
}
