<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;
class PedidosController extends Controller
{
    public function obtenerPorExpediente(Request $request)
    {
        $query = "SELECT * FROM PEDCLI WHERE EXPEDIENTE= :expediente ORDER BY CODIGO";

        $res = DB::select($query, ['expediente' => $request->expediente]);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerFichaClientes(Request $request)
    {
        $query = "SELECT pedcli.codigo as codigo, fecha, titulo, servido, baseimponible, total, estado, clientes.descripcion as descripcion_cliente, PEDCLI.CLIENTE

          FROM pedcli
          LEFT JOIN CLIENTES            ON clientes.codigo = pedcli.cliente
          LEFT JOIN VENDEDORES          ON VENDEDORES.CODIGO = :comercial1
          LEFT JOIN DIRECCIONESCLIENTES ON DIRECCIONESCLIENTES.CLIENTE = PEDCLI.CLIENTE AND DIRECCIONESCLIENTES.LINEA = PEDCLI.LINEADIRECCIONENVIO
          LEFT JOIN PROVINCIAS          ON PROVINCIAS.DESCRIPCION = DIRECCIONESCLIENTES.PROVINCIA

	     where fecha >= :fecha_desde
           and ((clientes.vendedor = :comercial2)
                or ( :comercial3 = 1)
                or ( :comercial4 > 100)
                or (VENDEDORES.ACCESO_TODOS_CLIENTES_TC = 'S'))
        ";

           /*AND ((PROVINCIAS.COMERCIAL_ASIGNADO = :comercial5)
                OR (clientes.PROVINCIA IS NOT NULL
                    AND (PEDCLI.LINEADIRECCIONENVIO IS NULL OR PEDCLI.LINEADIRECCIONENVIO = 0) ))*/

        $bindings = [
            'comercial1' => $request->comercial,
            'comercial2' => $request->comercial,
            'comercial3' => $request->comercial,
            'comercial4' => $request->comercial,
            'comercial5' => $request->comercial,
            'fecha_desde' => $request->fecha_desde
        ];

         if(!empty($request->cliente))
        {
            $query = $query . " and pedcli.cliente = :cliente";
            $bindings['cliente'] = $request->cliente;
        }


        if((!empty($request->estado)) && ($request->estado != "Todos"))
        {
            $query = $query . " and trim(estado) = :estado";
            $bindings['estado'] = $request->estado;
        }


        //estado = 1 vacio
        //estado = 2 ENVIADO
        //estado = 3 CONFIRMADO

        if(!empty($request->estado_servido)){

            if ($request->estado_servido == 1)
            {
                $query .= " AND ((PEDCLI.SERVIDO='N') OR (PEDCLI.SERVIDO='P'))";
            }
            if ($request->estado_servido == 2)
            {
                $query .= " AND PEDCLI.SERVIDO = 'N'";
            }
            if ($request->estado_servido == 3)
            {
                $query .= " AND PEDCLI.SERVIDO = 'P'";
            }
            if ($request->estado_servido == 4)
            {
                $query .= " AND PEDCLI.SERVIDO = 'T'";
            }

            //1 Servido nada + parcial
            //2 Servido nada
            //3 Servido parcial
            //4 Servido total


        }

        if(!empty($request->titulo))
        {
            $query .=  " and upper(titulo) like :titulo";
            $bindings['titulo'] = "%".strtoupper($request->titulo)."%";
        }

        $query .= " order by pedcli.codigo desc";

        return response()->json(UtilsHelper::utf8ize(DB::select($query, $bindings)));
    }

    //informe pedido
    public function obtenerInformacionInformePedido(Request $request)
    {
        $sql = "SELECT
                PROYECTOS.RAZONSOCIAL AS RAZONSOCIAL, PROYECTOS.CIF, PROYECTOS.DIRECCION, PROYECTOS.CP,
                PROYECTOS.POBLACION, PROYECTOS.PROVINCIA, PROYECTOS.TELEFONO, PROYECTOS.FAX, PROYECTOS.EMAIL,
                CLIENTES.CODIGO AS CLI_CODIGO, CLIENTES.DESCRIPCION AS CLI_DESCRIPCION, CLIENTES.CIF AS CLI_CIF,
                CLIENTES.DIRECCION AS CLI_DIRECCION, CLIENTES.CP AS CLI_CP, CLIENTES.POBLACION AS CLI_POBLACION,
                CLIENTES.PROVINCIA AS CLI_PROVINCIA, CLIENTES.TELEFONOFIJO AS CLI_TELEFONOFIJO, CLIENTES.FAX AS CLI_FAX,
                CLIENTES.CORREO AS CLI_CORREO, PEDCLI.CODIGO AS PED_CODIGO, PEDCLI.FECHA AS PED_FECHA,
                PEDCLI.FECHASERVIR, PEDCLI.TITULO AS PED_TITULO, PEDCLI.DESCRIPCION AS PED_DESCRIPCION,
                PEDCLI.BASEIMPONIBLE, PEDCLI.TOTAL, PEDCLI.PRESUPUESTO, CAST(PEDCLI.PDTO AS FLOAT) AS PDTO,
                PEDCLI.IMPORTEDTO, PEDCLI.PROYECTO AS PROYECTO, IMPUESTOS.IVA
            FROM PEDCLI
            LEFT JOIN CLIENTES ON CLIENTES.CODIGO = PEDCLI.CLIENTE
            LEFT JOIN PROYECTOS ON PROYECTOS.CODIGO = :proyecto
            LEFT JOIN IMPUESTOS ON IMPUESTOS.CODIGO = PEDCLI.IMPUESTO
            WHERE PEDCLI.CODIGO = :pedido";

        $bindings = [
            'proyecto' => $request->proyecto,
            'pedido'   => $request->pedido
        ];

        $result = DB::select($sql, $bindings);
        $res = count($result) > 0 ? $result[0] : null;
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerLineasPedidoInforme(Request $request)
    {
        $sql = "SELECT linpedcli.articulo, articulos.descripcion,
        CAST(linpedcli.cantidad AS FLOAT) AS CANTIDAD,
        CAST(linpedcli.pvp AS FLOAT) AS PVP,
        linpedcli.dto, linpedcli.pvpfinal,
        CAST(linpedcli.importe AS FLOAT) AS IMPORTE,
        linpedcli.comentario, cantidad_servida,
        proyecto.STOCK, articulos.no_controlar_stock
        FROM linpedcli
        LEFT JOIN articulos ON articulos.codigo = linpedcli.articulo
        LEFT JOIN proyecto ON articulos.codigo = proyecto.articulo
                        AND proyecto.proyecto = :proyecto
        LEFT JOIN calcular_cantidad_servida(linpedcli.pedido, linpedcli.linea) ON 0=0
        WHERE articulos.codigo = linpedcli.articulo
        AND pedido = :pedido
        ORDER BY linpedcli.linea";

        $bindings = [
        'proyecto' => $request->proyecto,
        'pedido' => $request->pedido,
        ];

        $res = DB::select($sql, $bindings);
        return response()->json(UtilsHelper::utf8ize($res));
    }


    public function obtenerSelectEstadosPedido()
    {
        $query = "select distinct(estado) as estado from pedcli order by estado";
        $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));
    }
}
