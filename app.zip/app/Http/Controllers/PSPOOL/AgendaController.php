<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class AgendaController extends Controller
{
    public function obtenerPorExpediente(Request $request)
    {

        $agenda = DB::select("SELECT AGENDA.CODIGO AS CODIGO, AGENDA.FECHA AS FECHA, AGENDA.HORA AS HORA, AGENDA.REALIZADO AS REALIZADO, AGENDA.ALARMA AS ALARMA,
        AGENDA.TITULO AS TITULO, AGENDA.LUGAR AS LUGAR, us2.NOMBRE AS USUARIO_ORIGEN, US1.NOMBRE AS USUARIO, US2.NOMBRE AS USUARIO_ORIGEN, ESTADOS_AGENDA.DESCRIPCION AS ESTADO
        FROM AGENDA
        LEFT JOIN USUARIOS US1   ON AGENDA.USUARIO = us1.CODIGO
        LEFT JOIN USUARIOS US2   ON AGENDA.USUARIO_ORIGEN = us2.CODIGO
        LEFT JOIN ESTADOS_AGENDA ON AGENDA.ESTADO = ESTADOS_AGENDA.CODIGO
        where EXPEDIENTE = ?
        AND AGENDA.FECHA > '2024-01-01'
        order by AGENDA.CODIGO, ORDEN_PRIORIDAD", [$request->expediente]);



        return response()->json(UtilsHelper::utf8ize($agenda));
    }

    public function obtenerCodigoPorExpediente(Request $request)
    {
        $query = "SELECT CODIGO FROM AGENDA WHERE EXPEDIENTE = ? AND AGENDA.FECHA > '01-12-2024'";
        $res = DB::select($query, [$request->expediente]);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerCaracteres()
    {
        $query = "SELECT * FROM CARACTER_AGENDA";
        $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerEstado(Request $request)
    {
        $query = "SELECT ESTADOS_EXPEDIENTES.ESTADO_AGENDA_ASOCIADO AS ULTIMO_ESTADO, PUEDE_MODIFICAR_FECHA, AGENDA.ALARMA
                    FROM ESTADOS_REGISTRO_AGENDA
                    LEFT JOIN AGENDA ON AGENDA.CODIGO = ESTADOS_REGISTRO_AGENDA.AGENDA
                    LEFT JOIN ESTADOS_EXPEDIENTES ON ESTADOS_EXPEDIENTES.CODIGO = ESTADOS_REGISTRO_AGENDA.ESTADO
                    WHERE ESTADOS_REGISTRO_AGENDA.AGENDA = :codigo
                    AND ESTADOS_REGISTRO_AGENDA.EXPEDIENTE = :expediente
                    ORDER BY ESTADOS_REGISTRO_AGENDA.FECHA_ALTA DESC, ESTADOS_REGISTRO_AGENDA.HORA_ALTA DESC";

        $res = DB::select($query, ['expediente' => $request->expediente, 'codigo' => $request->codigo]);
        return response()->json(UtilsHelper::utf8ize(
            count($res) > 0 ?
                $res[0] : null
        ));
    }

    public function obtenerExpedientePorCodigoAgenda(Request $request)
    {
        $query = "SELECT EXPEDIENTE FROM AGENDA WHERE CODIGO= ? ";
        $res = DB::select($query, [$request->codigo]);
        return response()->json(UtilsHelper::utf8ize(
            count($res) > 0 ?
                $res[0] : null
        ));
    }

    public function actualizarOCrear(Request $request)
    {
        $query = 'UPDATE OR
            INSERT INTO agenda (
                codigo, fecha, usuario_origen, usuario, descripcion, agenda_comentario_interno,
                hora, titulo, alarma, activar_alarma_agenda, realizado, expediente, caracter, orden_prioridad
            )
            VALUES (
                :nuevo_codigo,
                :fecha,
                :de_usuario,
                :a_usuario,
                :descripcion,
                :comentarioInterno,
                :hora,
                :titulo,
                :alarma,
                :alarma_fecha,
                :realizado,
                :expediente,
                :urgencia,
                :prioridad
            )
            MATCHING (CODIGO)';


        $bindings = [
            'nuevo_codigo'     => $request->nuevo_codigo,
            'fecha'            => $request->fecha,
            'de_usuario'       => $request->de_usuario,
            'a_usuario'        => $request->a_usuario,
            'descripcion'      => $request->descripcion,
            'comentarioInterno' => $request->comentarioInterno,
            'hora'             => $request->hora,
            'titulo'           => $request->titulo,
            'alarma'           => $request->alarma,
            'alarma_fecha'     => $request->alarma_fecha,
            'realizado'        => $request->realizado,
            'expediente'       => $request->expediente,
            'urgencia'         => $request->urgencia,
            'prioridad'        => $request->prioridad
        ];

        $res = DB::select($query, $bindings);

        //NO PERMITIR MODIFICAR LA FECHA
        $queryBloquearFecha = "UPDATE ESTADOS_REGISTRO_AGENDA
		   SET PUEDE_MODIFICAR_FECHA = 'N'
		    WHERE AGENDA = ?";

        DB::select($queryBloquearFecha, [$request->nuevo_codigo]);

        return response()->json([
            'msg' => empty($request->codigo) ? 'Registro creado' : 'Valores actualizados',
            'nuevo_codigo' => $request->nuevo_codigo
        ]);
    }

    public function obtenerPorCodigo(Request $request)
    {
        $query = "SELECT *
			 FROM agenda
			WHERE codigo = ? ";

        $res = DB::select($query, [$request->codigo]);
        return response()->json(UtilsHelper::utf8ize(
            count($res) > 0 ?
                UtilsHelper::utf8ize($res[0]) : null
        ));
    }

    public function obtenerSiguienteCodigo()
    {
        $query = "SELECT GEN_ID(agenda_codigo_gen, 1) AS NUEVO_CODIGO FROM RDB\$DATABASE";
        $res = DB::select($query);
        return response()->json(
            count($res) > 0 ? UtilsHelper::utf8ize($res[0]) : null
        );
    }

    public function borrar(Request $request)
    {
        $query = "DELETE FROM AGENDA WHERE CODIGO = ? ";
        $res = DB::select($query, [$request->codigo]);
        return response()->json(['msg' => 'Registro eliminado']);
    }

    public function obtenerEstados()
    {
        $query = "SELECT CODIGO, DESCRIPCION, '0' AS ESTADO_AGENDA_ASOCIADO, REALIZAR_POR_USUARIO
              FROM ESTADOS_AGENDA
             ORDER BY CODIGO";

        $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));
    }


    public function obtenerEstadosSeccionAgendasEstados(Request $request)
    {
        // $query = "SELECT ESTADOS_EXPEDIENTES.CODIGO, ESTADOS_EXPEDIENTES.DESCRIPCION, ESTADOS_EXPEDIENTES.ESTADO_AGENDA_ASOCIADO,
        //            ESTADOS_AGENDA.REALIZAR_POR_USUARIO
        //       FROM ESTADOS_EXPEDIENTES
        //       LEFT JOIN ESTADOS_AGENDA ON ESTADOS_AGENDA.CODIGO = ESTADOS_EXPEDIENTES.ESTADO_AGENDA_ASOCIADO
        //      WHERE (? = 101 /* AND (ESTADOS_EXPEDIENTES.CODIGO = 2 OR ESTADOS_EXPEDIENTES.CODIGO = 10 OR ESTADOS_EXPEDIENTES.CODIGO = 8) */)
        //         OR (? <> 101 AND (ESTADOS_EXPEDIENTES.CODIGO = 3 OR ESTADOS_EXPEDIENTES.CODIGO = 7  OR ESTADOS_EXPEDIENTES.CODIGO = 4  OR ESTADOS_EXPEDIENTES.CODIGO = 5 OR ESTADOS_EXPEDIENTES.CODIGO = 6 OR ESTADOS_EXPEDIENTES.CODIGO = 11))
        //      ORDER BY CODIGO";

        /** Santi 09/02/2026 Modifica la sentenci para que no muestre los estados_agenda bloqueados. Reducimos tambien la sentencia */
        $query = "SELECT
                    EE.CODIGO,
                    EE.DESCRIPCION,
                    EE.ESTADO_AGENDA_ASOCIADO,
                    EA.REALIZAR_POR_USUARIO
                FROM ESTADOS_EXPEDIENTES EE
                LEFT JOIN ESTADOS_AGENDA EA
                    ON EA.CODIGO = EE.ESTADO_AGENDA_ASOCIADO
                WHERE
                    (? = 18 OR (? <> 18 AND EE.CODIGO IN (3,4,5,6,7,11)))
                AND (EA.BLOQUEADO <> 'S' OR EA.BLOQUEADO IS NULL)
                ORDER BY EE.CODIGO;";

        $res = DB::select($query, [$request->comercial, $request->comercial]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerEstadoAgendaPorCodigoEstado(Request $request)
    {
        $query = "SELECT * FROM ESTADOS_AGENDA WHERE CODIGO = ?";
        $res = DB::select($query, [$request->codigo]);
        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }


    public function actualizarEstado(Request $request)
    {
        $query = "UPDATE AGENDA
           SET ESTADO = :estado,
           USUARIO = :usuario_realizar_por";
        if ($request->estado_agenda == 39) {
            $query .= " ,ALARMA = 'N'
                             ,FECHA_ACTIVAR_ALARMA_AGENDA = null
                             ,ACTIVAR_ALARMA_AGENDA = 'N'";
        } else if ($request->estado_agenda == 36 || $request->estado_agenda == 37 || $request->estado_agenda == 38) {
            $query .= " ,ALARMA = 'N'
                             ,FECHA_ACTIVAR_ALARMA_AGENDA = :fecha_alarma
                             ,ACTIVAR_ALARMA_AGENDA = 'S'";
        } else {
            $query .= " ,ALARMA = 'S'
                             ,FECHA_ACTIVAR_ALARMA_AGENDA = null
                             ,ACTIVAR_ALARMA_AGENDA = 'N'";
        }

        $query .= " WHERE CODIGO = :codigo";

        $res = DB::select($query, [
            'estado' => $request->estado_agenda,
            'usuario_realizar_por' => $request->usuario_realizar_por,
            'fecha_alarma' => $request->fecha_alarma,
            'codigo' => $request->codigo
        ]);


        return response()->json(['msg' => 'Registro actualizado']);
    }

    public function actualizarCrearEstadoRegistro(Request $request)
    {
        $query = "UPDATE OR INSERT INTO ESTADOS_REGISTRO_AGENDA (AGENDA, ESTADO, USUARIO, FECHA_ALTA, HORA_ALTA, COMENTARIO, EXPEDIENTE, USUARIO_REALIZAR_POR, USUARIO_REALIZAR_POR_ANT, PUEDE_MODIFICAR_FECHA)
        VALUES (:agenda, :estado, :usuario, :fecha_alta, :hora_alta, :comentario, :expediente, :usuario_realizar_por, :usuario_realizar_por_ant, 'S')
        MATCHING (AGENDA, ESTADO, FECHA_ALTA, HORA_ALTA)";

        DB::select($query, [
            'agenda'                    => $request->agenda,
            'estado'                    => $request->estado,
            'usuario'                   => $request->usuario,
            'fecha_alta'                => $request->fecha_alta,
            'hora_alta'                 => $request->hora_alta,
            'comentario'                => $request->comentario,
            'expediente'                => $request->expediente,
            'usuario_realizar_por'       => $request->usuario_realizar_por,
            'usuario_realizar_por_ant'   => $request->usuario_realizar_por_ant,
        ]);


        return response()->json(['msg' => 'Registro actualizado']);
    }

    public function obtenerEstadosDetalle(Request $request)
    {
        $query = "SELECT ERA.FECHA_ALTA AS FECHA_ALTA, ERA.HORA_ALTA AS HORA_ALTA, CAST(ERA.COMENTARIO AS VARCHAR(10000)) AS COMENTARIO,
                     EA.DESCRIPCION AS ESTADO, EE.DESCRIPCION AS ESTADO_EXPEDIENTE,
                     U_REALIZAR_POR_ANT.NOMBRE AS USUARIO_REALIZAR_POR_ANT,
                     U_REALIZAR_POR.NOMBRE AS USUARIO_REALIZAR_POR,
                     U.NOMBRE AS NOMBRE
                FROM ESTADOS_REGISTRO_AGENDA ERA
                LEFT JOIN ESTADOS_AGENDA EA           ON ERA.ESTADO  = EA.CODIGO
                LEFT JOIN ESTADOS_EXPEDIENTES EE      ON ERA.ESTADO  = EE.CODIGO
                LEFT JOIN USUARIOS U                  ON ERA.USUARIO = U.CODIGO
                LEFT JOIN USUARIOS U_REALIZAR_POR     ON ERA.USUARIO_REALIZAR_POR     = U_REALIZAR_POR.CODIGO
                LEFT JOIN USUARIOS U_REALIZAR_POR_ANT ON ERA.USUARIO_REALIZAR_POR_ANT = U_REALIZAR_POR_ANT.CODIGO
               WHERE ERA.AGENDA = :agenda
               ORDER BY FECHA_ALTA DESC , HORA_ALTA DESC";

        $res = DB::select($query, ['agenda' => $request->agenda]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function buscarAgendas(Request $request)
    {
        $fecha_desde = $request->fecha_desde;
        $titulo = $request->titulo;
        $realizado = $request->realizado;
        $con_alarma = $request->con_alarma;
        $estado = $request->estado;
        $recordatorio = $request->recordatorio;
        $usuario = $request->usuario;
        $comercial = $request->comercial;

        $sql = "SELECT AGENDA.CODIGO AS CODIGO, AGENDA.FECHA AS FECHA, AGENDA.HORA AS HORA, AGENDA.REALIZADO AS REALIZADO, AGENDA.ALARMA AS ALARMA, ORDEN_PRIORIDAD,
               AGENDA.TITULO AS TITULO, AGENDA.LUGAR AS LUGAR, AGENDA.USUARIO_ORIGEN AS USUARIO_ORIGEN, COALESCE(AGENDA.EXPEDIENTE, 0) AS EXPEDIENTE,
               AGENDA.FECHA_ACTIVAR_ALARMA_AGENDA,
               USUARIOS.NOMBRE AS USUARIO,
               ESTADOS_AGENDA.DESCRIPCION AS ESTADO,
               MAX(ERA.FECHA_ALTA) AS FECHA_ULTIMO_ESTADO,
               (
                 SELECT FIRST 1 U2.NOMBRE
                 FROM ESTADOS_REGISTRO_AGENDA ERA2
                 LEFT JOIN USUARIOS U2 ON U2.CODIGO = ERA2.USUARIO
                 WHERE ERA2.AGENDA = AGENDA.CODIGO
                 ORDER BY ERA2.FECHA_ALTA DESC, ERA2.HORA_ALTA DESC
               ) AS USUARIO_ULTIMO_ESTADO
          FROM AGENDA
          LEFT JOIN USUARIOS ON AGENDA.USUARIO = USUARIOS.CODIGO
          LEFT JOIN ESTADOS_AGENDA ON AGENDA.ESTADO = ESTADOS_AGENDA.CODIGO
          LEFT JOIN ESTADOS_REGISTRO_AGENDA ERA ON ERA.AGENDA = AGENDA.CODIGO
         WHERE 0=0";

        // Prepare named bindings array
        $bindings = [];

        // Apply conditions based on the inputs
        if (!empty($fecha_desde)) {
            $sql .= " and AGENDA.fecha >= :fecha_desde";
            $bindings['fecha_desde'] = $fecha_desde;
        }

        if (!empty($titulo)) {
            $sql .= " and upper(titulo) like :titulo";
            $bindings['titulo'] = '%' . strtoupper($titulo) . '%';
        }

        if (!empty($realizado)) {
            $sql .= " and realizado = :realizado";
            $bindings['realizado'] = $realizado;
        }

        if (!empty($con_alarma)) {
            $sql .= " and alarma = :con_alarma";
            $bindings['con_alarma'] = $con_alarma;
        }

        if (!empty($estado)) {
            $sql .= " and ESTADOS_AGENDA.CODIGO = :estado";
            $bindings['estado'] = $estado;
        }

        if (!empty($recordatorio)) {
            if ($recordatorio == "S") {
                $sql .= " AND FECHA_ACTIVAR_ALARMA_AGENDA > 'NOW' AND FECHA_ACTIVAR_ALARMA_AGENDA < DATEADD(5 day to current_date)";
            } else {
                $sql .= " AND ((FECHA_ACTIVAR_ALARMA_AGENDA < 'NOW' AND FECHA_ACTIVAR_ALARMA_AGENDA > DATEADD(5 day to current_date)) OR FECHA_ACTIVAR_ALARMA_AGENDA IS NULL)";
            }
        }

        $sql .= " AND AGENDA.usuario = :usuario";


        $bindings['usuario'] = !empty($usuario) && $usuario !== 'undefined' ? $usuario : $comercial;


        $sql .= " GROUP BY AGENDA.CODIGO, AGENDA.FECHA, AGENDA.HORA, AGENDA.REALIZADO, AGENDA.ALARMA, ORDEN_PRIORIDAD, AGENDA.TITULO, AGENDA.LUGAR,
                        AGENDA.USUARIO_ORIGEN, EXPEDIENTE, AGENDA.FECHA_ACTIVAR_ALARMA_AGENDA, USUARIOS.NOMBRE, ESTADOS_AGENDA.DESCRIPCION
                        ORDER BY FECHA_ULTIMO_ESTADO DESC";

        $res = DB::select($sql, $bindings);

        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function contarAlarmasRecordatorios(Request $request)
    {
        $query = "SELECT COUNT(CODIGO) AS N_REG
                FROM AGENDA
                WHERE USUARIO = ? ";

        if ($request->tipo == 'alarma') {
            $query .= "AND ALARMA  = 'S'";
        } else if ($request->tipo == 'recordatorio') {
            /* MIRO LAS AGENDAS CUYA ALARMA SE VAYA A ACTIVAR EN LOS PROXIMOS 5 DIAS */
            $query .= "AND FECHA_ACTIVAR_ALARMA_AGENDA > 'NOW'
                        AND FECHA_ACTIVAR_ALARMA_AGENDA < DATEADD(5 day to current_date)";
        }

        $res = DB::select($query, [$request->comercial]);
        $row = $res[0];

        return response()->json(UtilsHelper::utf8ize($row));
    }
}
