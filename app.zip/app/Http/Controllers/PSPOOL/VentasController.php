<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class VentasController extends Controller
{
    public function obtenerVentasSgfa(Request $request)
    {
        $query = "select sum(hventasarticulo.importebaseventa) as timportebase,
            sum(cantidad)                         as tcantidad,
            articulos.codigo,  articulos.descripcion, secciones.descripcion as dseccion,
            articulos.seccion, secciones.descripcion as dseccion,
            articulos.grupo,   grupos.descripcion as dgrupo,
            articulos.familia, familias.descripcion as dfamilia
            from HVENTASARTICULO
            LEFT JOIN ARTICULOS ON hventasarticulo.articulo = articulos.codigo
            LEFT JOIN SECCIONES ON articulos.seccion        = secciones.codigo
            LEFT JOIN PROYECTOS ON hventasarticulo.proyecto = hventasarticulo.proyecto
            LEFT JOIN CLIENTES  ON hventasarticulo.cliente  = clientes.codigo
            LEFT JOIN GRUPOS    ON articulos.grupo          = grupos.codigo
            LEFT JOIN FAMILIAS  ON articulos.familia       = familias.codigo
            where proyectos.almacen       <> 'V'
            and hventasarticulo.fecha   >= :fecha_desde
            and clientes.codigo          =  :cliente
            and proyectos.codigo         =  :proyecto
            group by articulos.codigo, articulos.descripcion, secciones.descripcion,
            articulos.seccion, secciones.descripcion,
            articulos.grupo, grupos.descripcion,
            articulos.familia, familias.descripcion,
            articulos.unidadescaja
            order by articulos.seccion, articulos.grupo, articulos.familia, articulos.codigo";

            $res = DB::select($query, [
                'fecha_desde' => $request->fecha_desde,
                'cliente' => $request->cliente,
                'proyecto' => $request->proyecto
            ]);

            return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerArticulosVendidos(Request $request)
    {
        $query = "select    sum(hventasarticulo.importebaseventa) as timportebase,
	              sum(cantidad)              as tcantidad,
			      hventasarticulo.articulo as articulo,
			      articulos.descripcion      as darticulo
			      from hventasarticulo
				  left join articulos    on articulos.codigo   = hventasarticulo.articulo
				  left join impuestos    on impuestos.codigo   = articulos.impuesto
			      left join proyectos    on proyectos.codigo   = hventasarticulo.proyecto
				  left join proveedores  on proveedores.codigo = articulos.proveedor
				  left join clientes     on clientes.codigo    = hventasarticulo.cliente
				  left join vendedores   on clientes.vendedor  = vendedores.codigo
				  where proyectos.almacen<>'V'
				  and   proyectos.codigo = :proyecto
				  and fecha >= :fecha_desde
				  and hventasarticulo.cliente = :cliente
                  group by hventasarticulo.articulo,articulos.descripcion,articulos.medida
                  order by articulos.descripcion";

        $res = DB::select($query, [
            'fecha_desde' => $request->fecha_desde,
            'cliente' => $request->cliente,
            'proyecto' => $request->proyecto
         ]);

         return response()->json(UtilsHelper::utf8ize($res));
    }
}
