<?php

namespace App\Http\Controllers\PSPOOL;

use App\Helpers\UtilsHelper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class VendedoresController extends Controller
{
    public function obtenerPorExpediente(Request $request)
    {
        $query = "SELECT vendedores.CODIGO FROM expedientes, vendedores WHERE expedientes.codigo = ? AND expedientes.comercial_alta = vendedores.codigo";
        $res = DB::select($query, [$request->expediente]);
        return response()->json(
            count($res) >0 ? 
            UtilsHelper::utf8ize($res[0]) : null
        );
    }

    public function obtenerComercialesUsanTerminal(Request $request)
    {
        $query = "SELECT codigo, nombre 
                FROM vendedores 
                WHERE USA_TERMINAL_COMERCIAL = 'S'";

        //si se buscan los posibles comerciales de un expediente, incluir al comercial asignado ya aunque no use terminal
        if($request->has('comercialExpediente')){
            $query = $query . ' OR CODIGO = ?';

            $res = DB::select($query, [$request->comercialExpediente]);
            return response()->json(UtilsHelper::utf8ize($res));
        }

        //si no hay comercial asignado 
        $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));
    }
}
