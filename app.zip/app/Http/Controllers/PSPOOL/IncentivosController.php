<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class IncentivosController extends Controller
{
    public function comprobarAutorizacionAccesoIncentivo(Request $request)
    {
        $comercial = $request->comercial;
        $sql = "SELECT COUNT(codigo) AS n_reg
                      FROM vendedores
                      WHERE comentario_vendedor NOT LIKE '%NOVERINCENTIVO%'
                      AND codigo = :comercial";

        $res= DB::select($sql, [
            'comercial'  => $comercial
        ]);
        return response()->json(UtilsHelper::utf8ize($res[0]));
    }

    public function obtenerListadoObjetivos(Request $request)
    {

        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;
        $comercial = $request->comercial;

        $res = [];

        $bindings = [
            'comercial'   => $comercial,
            'comercial1'   => $comercial,
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
        ];

        DB::statement("EXECUTE PROCEDURE RELLENAR_TMPLSTOBJETIVOSMESES(:fecha_desde, :fecha_hasta, :comercial, 'N')", [
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
            'comercial'   => $comercial,
            'status'      => 'N'
        ]);


        $query = 'SELECT
                    t.nombre,
                    t.objetivo_descripcion,
                    t.vendidos,
                    t.diferencia,
                    t.incentivo,
                    t.objetivo,
                    t.PC_INC_ANYO_ANTERIOR,
                    t.IMPORTE_INC_ANYO_ANTERIOR,
                    COALESCE(t.INCENTIVO_EXTRA, 0) AS INCENTIVO_EXTRA,
                    oc.IMPORTE_COMISION_EXTRA,
                     t.mes as
                    mes_nombre
                FROM tmplstobjetivosmeses t
                LEFT JOIN objetivos_comerciales oc
                    ON t.objetivo_descripcion = oc.descripcion
                    AND t.comercial = oc.comercial
                WHERE (t.comercial = :comercial OR :comercial1 = 1)
                    AND oc.FECHA_DESDE <= :fecha_desde
                    AND oc.FECHA_HASTA >= :fecha_hasta
                ORDER BY t.objetivo, CAST(t.mes AS INTEGER)
            ';

        $resMensual = DB::select($query, $bindings);
        $res['mensual'] = $resMensual;

        //Objetivos Extra
        DB::statement("EXECUTE PROCEDURE rellenar_tmplstobjetivosfinal(:fecha_desde, :fecha_hasta, :comercial, 'N')", $bindings);

        $sql = "SELECT SUM(oc.IMPORTE_COMISION_EXTRA) AS IMP_TOTAL
                FROM tmplstobjetivos t
                LEFT JOIN objetivos_comerciales oc ON t.objetivo_descripcion = oc.descripcion AND t.comercial = oc.comercial
                WHERE ((t.comercial = :comercial) OR (:comercial1 = 1))
                AND oc.FECHA_DESDE >= :fecha_desde
                AND oc.FECHA_HASTA <= :fecha_hasta";

        $result = DB::select($sql, $bindings);

        $res['extra']['importeTotal'] = $result[0]->IMP_TOTAL;

        $sql = "SELECT t.nombre, t.objetivo_descripcion, t.vendidos, t.diferencia, t.incentivo, t.objetivo,
                    t.PC_INC_ANYO_ANTERIOR, t.IMPORTE_INC_ANYO_ANTERIOR, COALESCE(t.INCENTIVO_EXTRA, 0) AS INCENTIVO_EXTRA,
                    oc.IMPORTE_COMISION_EXTRA
                FROM tmplstobjetivos t
                LEFT JOIN objetivos_comerciales oc ON t.objetivo_descripcion = oc.descripcion AND t.comercial = oc.comercial
                WHERE ((t.comercial = :comercial) OR (:comercial1 = 1))
                AND oc.FECHA_DESDE <= :fecha_desde
                AND oc.FECHA_HASTA >= :fecha_hasta
                ORDER BY t.objetivo";

        $result = DB::select($sql, $bindings);
        $res['extra']['info'] = $result;


        return response()->json(UtilsHelper::utf8ize($res));
    }


    public function obtenerListadoIncentivos(Request $request)
    {
        $fecha_desde = $request->fecha_desde;
        $fecha_hasta = $request->fecha_hasta;

        $fecha_desde_format = UtilsHelper::formatearFechaDesdeFB($fecha_desde);
        $fecha_hasta_format = UtilsHelper::formatearFechaDesdeFB($fecha_hasta);

        $bindings = [
            'fecha_desde' => $fecha_desde,
            'fecha_hasta' => $fecha_hasta,
        ];

        $res = [];

        //obtener Vendedores
        $sql = "SELECT VENDEDORES.CODIGO AS CVENDEDOR, VENDEDORES.NOMBRE AS VENDEDOR, SUM(TIQUETS.IMPORTECONIVA) AS FACTURACION
            FROM TIQUETS
            LEFT JOIN CLIENTES ON CLIENTES.CODIGO = TIQUETS.CLIENTE
            LEFT JOIN VENDEDORES ON VENDEDORES.CODIGO = CLIENTES.VENDEDOR
            WHERE VENDEDORES.CODIGO IS NOT NULL
            AND VENDEDORES.CODIGO <> 0
            AND VENDEDORES.CODIGO <> 23
            AND TIQUETS.FECHA > :fecha_desde
            AND TIQUETS.FECHA < :fecha_hasta
            GROUP BY VENDEDORES.CODIGO, VENDEDORES.NOMBRE
            ORDER BY 1 ASC";

        $vendedores = DB::select($sql, $bindings);

        //crear un array de arrays, en cada uno se almacena información relativa a un vendedor
        //
        $vendedoresArray = [];
        foreach ($vendedores as $indice => $vendedor) {
            $vendedoresArray[$indice] = ['info' => $vendedor];

            $sql = "SELECT COALESCE(SUM(TIQUETS.IMPORTECONIVA), 0) AS FACTURACION, TIQUETS.FECHA
                    FROM TIQUETS
                    JOIN CLIENTES ON CLIENTES.CODIGO = TIQUETS.CLIENTE
                    WHERE CLIENTES.VENDEDOR = :vendedor
                    AND TIQUETS.FECHA >= :fecha_desde
                    AND TIQUETS.FECHA <= :fecha_hasta
                    GROUP BY TIQUETS.FECHA
                    ";

            $gananciasPorDia = DB::select($sql, [
                'vendedor' => $vendedor->CVENDEDOR,
                'fecha_desde' => $fecha_desde,
                'fecha_hasta' => $fecha_hasta
            ]);

            foreach($gananciasPorDia as $ganancia)
            {
                $vendedoresArray[$indice]['facturacion'][$ganancia->FECHA] = $ganancia->FACTURACION;
            }


        }



        $ranking = [];
        $sql = "SELECT FIRST 3 VENDEDORES.CODIGO AS CVENDEDOR, SUM(TIQUETS.IMPORTECONIVA) AS FACTURACION
                                  FROM TIQUETS
                                  LEFT JOIN CLIENTES   ON CLIENTES.CODIGO = TIQUETS.CLIENTE
                                  LEFT JOIN VENDEDORES ON VENDEDORES.CODIGO = CLIENTES.VENDEDOR
                                 WHERE VENDEDORES.CODIGO IS NOT NULL
                                   AND VENDEDORES.CODIGO <> 0
                                   AND VENDEDORES.CODIGO <> 23
                                   AND TIQUETS.FECHA = :fecha_desde
                                 GROUP BY VENDEDORES.CODIGO
                                 ORDER BY 2 DESC";

        while (strtotime($fecha_desde_format) < strtotime( $fecha_hasta_format)." + 1 days") {

            $topVendedores = DB::select($sql, ['fecha_desde' => UtilsHelper::formatearFechaAFB($fecha_desde_format)]);
            $ranking[$fecha_desde_format] = $topVendedores;

            $fecha_desde_format = date("Y-m-d", strtotime($fecha_desde_format." + 1 days"));
        }



        $res['vendedores'] = $vendedoresArray;
        $res['ranking'] = $ranking;

        //obtener detalle de cada vendedor

        return response()->json(UtilsHelper::utf8ize($res));
    }
}
