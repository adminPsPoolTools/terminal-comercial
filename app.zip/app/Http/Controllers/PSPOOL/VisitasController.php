<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class VisitasController extends Controller
{
    public function crearVisitaComercialAgenda(Request $request)
    {
        $codigo = DB::select("SELECT MAX(CODIGO) + 1 AS N_CODIGO FROM VISITASCOMERCIALES")[0];
        $query =  "INSERT INTO VISITASCOMERCIALES (CODIGO, VENDEDOR, FECHA, HORA, COMENTARIO, EXPEDIENTE, CLIENTE, TIPO)
                VALUES (:codigoVisita, :usuario, 'NOW', '".date("H:i:s")."', :comentario, :expediente, 0, 1)";

        DB::select($query, [
            'codigoVisita' => $codigo->N_CODIGO,
            'usuario' => $request->usuario,
            'comentario' => $request->comentario,
            'expediente' => $request->expediente
        ]);

        return response()->json(['msg' => 'Visita creada']);
    }

    public function actualizarExpedienteVisita(Request $request)
    {
        $query = "UPDATE VISITASCOMERCIALES
            SET EXPEDIENTE = :expediente
            WHERE CODIGO = :codigo";

        DB::select($query, [
            'expediente' => $request->expediente,
            'codigo' => $request->codigo
        ]);

        return response()->json(['msg' => 'Expediente actualizado']);
    }


    public function obtenerVisitasFichaCliente(Request $request)
    {
        $query = "SELECT V.CODIGO, V.cliente, V.vendedor, V.fecha, V.hora, CAST(V.COMENTARIO AS VARCHAR(10000)) AS COMENTARIO,
                         V.tipo, CAST(V.COMENTARIO_MOTIVO AS VARCHAR(10000)) AS COMENTARIO_MOTIVO,

                         D.DIRECCION AS DIRECCION, D.PROVINCIA AS PROVINCIA, D.DESCRIPCION_DIRECCION_CLIENTE,

                         VCM.DESCRIPCION_MOTIVO AS MOTIVO

                    FROM visitascomerciales V
                    LEFT JOIN CLIENTES CL ON CL.CODIGO = V.CLIENTE
                    LEFT JOIN DIRECCIONESCLIENTES D ON D.LINEA = V.LINEADIRECCIONCLIENTE AND D.CLIENTE = V.CLIENTE
                    LEFT JOIN PROVINCIAS ON D.PROVINCIA = PROVINCIAS.DESCRIPCION
                    LEFT JOIN VISITASCOMERCIALES_MOTIVOS VCM ON VCM.CODIGO = V.MOTIVO

                   WHERE V.cliente = :cliente
                     AND ((PROVINCIAS.COMERCIAL_ASIGNADO = :comercial )
                         OR (CL.PROVINCIA IS NOT NULL AND (V.LINEADIRECCIONCLIENTE IS NULL OR V.LINEADIRECCIONCLIENTE = 0)))
                   ORDER BY V.fecha desc, V.hora desc";

        $res = DB::select($query, ['cliente' => $request->cliente, 'comercial' => $request->comercial]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    //select acciones crear visita comercial
    public function obtenerAcciones()
    {
        $query = "SELECT CODIGO, DESCRIPCION_ACCION FROM VISITASCOMERCIALES_ACCIONES ORDER BY DESCRIPCION_ACCION";
        $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));

    }

    public function obtenerAsuntosAcciones()
    {
        $query = "SELECT CODIGO, DESCRIPCION_ASUNTO FROM VISITASCOMERCIALES_ASUNTOS ORDER BY DESCRIPCION_ASUNTO";
        $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerMotivos()
    {
        $query = "SELECT CODIGO, DESCRIPCION_MOTIVO FROM VISITASCOMERCIALES_MOTIVOS ORDER BY DESCRIPCION_MOTIVO";
        $res = DB::select($query);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerVisitasPorCliente(Request $request)
    {
        $query = "select * from visitascomerciales
            where cliente  = :cliente
            order by fecha, hora";

            $res = DB::select($query, ['cliente' => $request->cliente]);
            return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerVisitasPorExpediente(Request $request)
    {
        $query = "select * from visitascomerciales
            where expediente  = :expediente
            order by fecha, hora";

            $res = DB::select($query, ['expediente' => $request->expediente]);
            return response()->json(UtilsHelper::utf8ize($res));
    }

    public function actualizarVisitaComercial(Request $request)
    {
        $query= "UPDATE visitascomerciales
                SET comentario              = :comentario,
                    tipo                    = :tipo,
                    lineadireccioncliente   = :lineaDireccion,
                    motivo                  = :motivo,
                    comentario_motivo       = :comentario_motivo,
                    contacto                = :contacto,
                    proyecto                = :proyecto
                WHERE codigo                = :codigo;
                ";

        $bindings = [
            'comentario'        => $request->comentario,
            'tipo'              => $request->tipo,
            'lineaDireccion'    => $request->lineaDireccion,
            'motivo'            => $request->motivo,
            'comentario_motivo' => $request->comentario_motivo,
            'contacto'          => $request->contacto,
            'proyecto'          => $request->proyecto,
            'codigo'            => $request->codigo
        ];

        DB::update($query, $bindings);
        return response()->json(['msg' => 'Registro actualizado']);

    }

    public function obtenerNuevoCodigo()
    {
        //obtener nuevo código
        $queryCodigo = "SELECT MAX(CODIGO) + 1 AS ULTIMOCODIGO FROM VISITASCOMERCIALES";
        $resCodigo = DB::select($queryCodigo);

        $codigo = $resCodigo[0];
        return response()->json($codigo);
    }


    public function crearVisitaComercial(Request $request)
    {


        if(empty($request->expediente))
        {
            $query = "INSERT INTO visitascomerciales (
                vendedor, cliente, proyecto, fecha, hora, comentario, tipo, LINEADIRECCIONCLIENTE,
                codigo, motivo, comentario_motivo, contacto
            ) VALUES (
                :vendedor, :cliente, :proyecto, :fecha, :hora, :comentario, :tipo, :lineaDireccion,
                :codigo, :motivo, :comentario_motivo, :contacto
            )";

            $bindings = [
                'vendedor'         => $request->vendedor,
                'cliente'          => $request->cliente,
                'proyecto'         => $request->proyecto,
                'fecha'            => $request->fecha,
                'hora'             => $request->hora,
                'comentario'       => $request->comentario,
                'tipo'             => $request->tipo,
                'lineaDireccion'   => $request->lineaDireccion,
                'codigo'           => $request->codigo,
                'motivo'           => $request->motivo,
                'comentario_motivo'=> $request->comentario_motivo,
                'contacto'         => $request->contacto
            ];

            DB::select($query, $bindings);


        }
        else
        {
            $query = "INSERT INTO visitascomerciales (
                vendedor, expediente, cliente, proyecto, fecha, hora, comentario, tipo, codigo, motivo, comentario_motivo, contacto
                ) VALUES (
                    :vendedor, :expediente, :cliente, :proyecto, :fecha, :hora, :comentario, :tipo, :codigo, :motivo, :comentario_motivo, :contacto
                )
                ";

            $bindings = [
                'vendedor'         => $request->vendedor,
                'expediente'       => $request->expediente,
                'cliente'          => $request->cliente,
                'proyecto'         => $request->proyecto,
                'fecha'            => $request->fecha,
                'hora'             => $request->hora,
                'comentario'       => $request->comentario,
                'tipo'             => $request->tipo,
                'codigo'           => $request->codigo,
                'motivo'           => $request->motivo,
                'comentario_motivo'=> $request->comentario_motivo,
                'contacto'         => $request->contacto
            ];

            DB::select($query, $bindings);

        }

        return response()->json(['msg' => 'Registro creado']);
    }

    public function asignarAccionesVisita(Request $request)
    {
        $queryBorrarAnteriores = "DELETE FROM VISITASCOM_ACCIONES_REALIZAR WHERE VISITA_COMERCIAL = ?";
        DB::select($queryBorrarAnteriores, [$request->codigo]);

        //asociar las nuevas acciones
        $query = "UPDATE OR INSERT INTO VISITASCOM_ACCIONES_REALIZAR(VISITA_COMERCIAL, ACCION)
			VALUES (:codigo, :accion)";
        foreach($request->acciones as $accion)
        {
            if(empty($accion)) continue;
            DB::select($query, ['codigo' =>$request->codigo, 'accion' => $accion]);

        }

        return response()->json(['msg' => 'Acciones actualizadas']);
    }

    public function asignarAsuntosVisita(Request $request)
    {
        $queryBorrarAnteriores = "DELETE FROM VISITASCOM_ASUNTOS_TRATADOS WHERE VISITA_COMERCIAL = ?";
        DB::select($queryBorrarAnteriores, [$request->codigo]);

        foreach( $request->asuntos as $asuntoIndividual){
            if(empty($asuntoIndividual)) continue;

            $asunto = explode("-", $asuntoIndividual)[0];
	        $tipo   = explode("-", $asuntoIndividual)[1];

            //SI NO ES UN ASUNTO LO AÑADO A LOS ASUNTOS
            if($tipo == "SECCION")
            {
                $sql = "SELECT DESCRIPCION FROM SECCIONES WHERE CODIGO = ?";
                $res = DB::select($sql, [$asunto]);
                $seccion = $res[0]->DESCRIPCION;

                $sql = "SELECT CODIGO FROM VISITASCOMERCIALES_ASUNTOS WHERE DESCRIPCION_ASUNTO = ? ";
                $res = DB::select($sql, [$seccion]);
                $asunto = $res[0]->CODIGO;

                if(empty($asunto))
                {
                    $sql = "SELECT MAX(CODIGO) + 1 AS NUEVO_CODIGO FROM VISITASCOMERCIALES_ASUNTOS";
                    $res = DB::select($sql);
                    $asunto = $res[0]->NUEVO_CODIGO;

                    $sql = "INSERT INTO VISITASCOMERCIALES_ASUNTOS(CODIGO, DESCRIPCION_ASUNTO)
					VALUES(:asunto, :seccion)";

                    $res = DB::select($sql, ['asunto'  => $asunto, 'seccion' => $seccion]);
                }

            }

            if($tipo == "GRUPO")
	        {
                $sql = "SELECT DESCRIPCION FROM GRUPOS WHERE CODIGO = ? ";
                $res = DB::select($sql, [$asunto]);
                $grupo = $res[0]->DESCRIPCION;

                $sql = "SELECT CODIGO FROM VISITASCOMERCIALES_ASUNTOS WHERE DESCRIPCION_ASUNTO = ?";
                $res = DB::select($sql, [$grupo]);
                $asunto = $res[0]->CODIGO;

                if(empty($asunto))
		        {
                    $sql = "SELECT MAX(CODIGO) + 1 AS NUEVO_CODIGO FROM VISITASCOMERCIALES_ASUNTOS";
                    $resCodigo = DB::select($sql);
                    $asunto = $resCodigo[0]->NUEVO_CODIGO;
                    $sql = "INSERT INTO VISITASCOMERCIALES_ASUNTOS(CODIGO, DESCRIPCION_ASUNTO)
					VALUES(:asunto, :grupo)";
                    DB::select($sql, ['asunto' => $asunto, 'grupo' => $grupo]);

                }
            }

            //actualizar la visita
            $query = "UPDATE OR INSERT INTO VISITASCOM_ASUNTOS_TRATADOS(VISITA_COMERCIAL, ASUNTO)
                VALUES (:codigo, :asunto)
                MATCHING(VISITA_COMERCIAL, ASUNTO)";

            DB::select($query, ['codigo' => $request->codigo, 'asunto'=> $asunto]);
        }
    }

    public function borrarVisita(Request $request)
    {
        $query = "DELETE FROM visitascomerciales "
		. "WHERE CODIGO = ?";

        DB::select($query, [$request->codigo]);
        return response()->json(['msg' => 'Registro eliminado']);
    }

    public function obtenerDetalleVisita(Request $request)
    {
        $query = "SELECT * FROM VISITASCOMERCIALES WHERE CODIGO = ?";
        $res = DB::select($query, [$request->codigo]);
        return response()->json(UtilsHelper::utf8ize(count($res) > 0 ? $res[0] : null));
    }

    public function obtenerAccionesVisitaPorCodigo(Request $request)
    {
        $query = "SELECT VCAR.ACCION, VCA.DESCRIPCION_ACCION
            FROM VISITASCOM_ACCIONES_REALIZAR VCAR
            LEFT JOIN VISITASCOMERCIALES_ACCIONES VCA ON VCAR.ACCION = VCA.CODIGO
            WHERE VCAR.VISITA_COMERCIAL = ?";

        $res = DB::select($query, [$request->codigo]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function obtenerAsuntosVisitaPorCodigo(Request $request)
    {
        $query =  "SELECT VCAT.ASUNTO, VCA.DESCRIPCION_ASUNTO
          FROM VISITASCOM_ASUNTOS_TRATADOS VCAT
          LEFT JOIN VISITASCOMERCIALES_ASUNTOS VCA ON VCA.CODIGO = VCAT.ASUNTO
         WHERE VCAT.VISITA_COMERCIAL = ?";

        $res = DB::select($query, [$request->codigo]);
        return response()->json(UtilsHelper::utf8ize($res));
    }

}
