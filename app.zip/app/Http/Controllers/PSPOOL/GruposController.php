<?php

namespace App\Http\Controllers\PSPOOL;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\UtilsHelper;

class GruposController extends Controller
{
    public function obtenerGruposPorSeccion(Request $request)
    {
        $query = "SELECT * FROM GRUPOS
         WHERE BLOQUEADO != 'S'";

        if(!empty($request->seccion)){
            $query .= " AND SECCION = :seccion ";
        }

        $query .= " ORDER BY DESCRIPCION ";

        $res = DB::select($query, ['seccion' => $request->seccion]);
        return response()->json(UtilsHelper::utf8ize($res));
    }
}
