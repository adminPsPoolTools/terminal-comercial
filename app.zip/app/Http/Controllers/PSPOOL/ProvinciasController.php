<?php

namespace App\Http\Controllers\PSPOOL;

use App\Helpers\UtilsHelper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProvinciasController extends Controller
{
    public function obtenerProvincias(Request $request)
    {
        $query = "SELECT CODIGO, DESCRIPCION FROM PROVINCIAS ";
        $bindings = [];
        if(!empty($request->comercial))
        {
            $query .= " LEFT JOIN COMERCIALES_PROVINCIAS ON PROVINCIAS.CODIGO = COMERCIALES_PROVINCIAS.PROVINCIA
		        WHERE ('S' = (SELECT TODAS_PROVINCIAS FROM VENDEDORES WHERE CODIGO = ?))
			    OR (PROVINCIAS.COMERCIAL_ASIGNADO    = ?)
				OR (COMERCIALES_PROVINCIAS.COMERCIAL = ?)
				OR (99 = ?)";

                $bindings = [ $request->comercial, $request->comercial, $request->comercial, $request->comercial];

            if(!empty($request->clientep))
            {
                $query .= " OR (DESCRIPCION = ?)";
                array_push($bindings, $request->clientep);
            }
        }

        $query .= " GROUP BY PROVINCIAS.CODIGO, PROVINCIAS.DESCRIPCION";
        $query .= " ORDER BY PROVINCIAS.DESCRIPCION";

        $res = DB::select($query, $bindings);
        return response()->json(UtilsHelper::utf8ize($res));
    }

    public function buscarPorCP(Request $request)
    {
        $query = "SELECT POBLACIONES.DESCRIPCION AS DESCRIPCION_POBLACION, PROVINCIAS.DESCRIPCION AS DESCRIPCION_PROVINCIA
		   FROM CODIGOSPOSTALES, POBLACIONES, PROVINCIAS, COMUNIDADES, PAISES
		  WHERE CODIGOSPOSTALES.POBLACION = POBLACIONES.CODIGO
            AND POBLACIONES.PROVINCIA     = PROVINCIAS.CODIGO
		    AND PROVINCIAS.COMUNIDAD      = COMUNIDADES.CODIGO
            AND COMUNIDADES.PAIS          = PAISES.CODIGO
		    AND CP						 = :cp";

        $res = DB::select($query, [$request->cp]);
        return response()->json(UtilsHelper::utf8ize($res));
    }


    public function obtenerPoblaciones(Request $request)
    {

        $query = "SELECT poblaciones.CODIGO, poblaciones.DESCRIPCION
                 from poblaciones
                 left join provincias on poblaciones.provincia = provincias.codigo
                where 0=0";

        if(!empty($request->comercial)) $query .= " AND provincias.comercial_asignado = :comercial ";
        if(!empty($request->provincia)) $query .= " AND poblaciones.provincia = :provincia ";
        $query .= " GROUP BY poblaciones.CODIGO, poblaciones.DESCRIPCION";
        $query .= " ORDER BY poblaciones.DESCRIPCION";

        $res = DB::select($query, [
            'comercial' => $request->comercial,
            'provincia' => $request->provincia,
        ]);

        return response()->json(UtilsHelper::utf8ize($res));

    }

    //Buscar poblacion ficha clientes
    public function buscarPoblacion(Request $request)
    {
        $query = "SELECT CODIGOSPOSTALES.CP AS CPOSTAL, PROVINCIAS.DESCRIPCION AS DESCRIPCION_PROVINCIA
		 FROM CODIGOSPOSTALES, POBLACIONES, PROVINCIAS, COMUNIDADES, PAISES
		 WHERE CODIGOSPOSTALES.POBLACION      = POBLACIONES.CODIGO
           AND POBLACIONES.PROVINCIA     	  = PROVINCIAS.CODIGO
		   AND PROVINCIAS.COMUNIDAD      	  = COMUNIDADES.CODIGO
           AND COMUNIDADES.PAIS          	  = PAISES.CODIGO
		   AND UPPER(POBLACIONES.DESCRIPCION) = UPPER(?)";

        $res = DB::select($query, [$request->poblacion]);
        return response()->json(UtilsHelper::utf8ize($res));

    }

    //buscar provincia ficha clientes
    public function buscarProvincia(Request $request)
    {
        $query = "SELECT PROVINCIAS.DESCRIPCION AS DESCRIPCION_PROVINCIA
		 FROM CODIGOSPOSTALES, POBLACIONES, PROVINCIAS, COMUNIDADES, PAISES
		 WHERE CODIGOSPOSTALES.POBLACION = POBLACIONES.CODIGO
           AND POBLACIONES.PROVINCIA     = PROVINCIAS.CODIGO
		   AND PROVINCIAS.COMUNIDAD      = COMUNIDADES.CODIGO
           AND COMUNIDADES.PAIS          = PAISES.CODIGO
		   AND POBLACIONES.DESCRIPCION	 = ?";

        $res = DB::select($query, [$request->poblacion]);
        return response()->json(UtilsHelper::utf8ize(count($res)> 0 ? $res[0] : null));
    }

    public function buscarPais(Request $request)
    {
        $query = "SELECT PAISES.DESCRIPCION AS DESCRIPCION_PAIS
		   FROM PROVINCIAS, COMUNIDADES, PAISES
		  WHERE PROVINCIAS.COMUNIDAD = COMUNIDADES.CODIGO
            AND COMUNIDADES.PAIS     = PAISES.CODIGO
		    AND PROVINCIAS.DESCRIPCION LIKE ? ";

        $res = DB::select($query, [$request->provincia]);
        return response()->json(UtilsHelper::utf8ize(count($res)> 0 ? $res[0] : null));
    }
}
