<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

use App\Helpers\ResponseHelper as Response;
use App\Helpers\UtilsHelper as Utils;

use App\Models\Albaran;
use App\Models\Config;
use App\Models\DireccionCliente;
use App\Models\Impuesto;
use App\Models\Lintiquet;
use App\Models\Pais;
use App\Models\User;

class AlbaranController extends Controller
{
    public function create(Request $request)
    {
        $json = $request->json()->all();

        //print_r($json);
        Log::info(print_r($json, true));

        try
        {
            //VALIDACIÓN A MANO
            if(!isset($json["DIRECCION_ENVIO"])) return Response::error("Falta la dirección de envio", 400);
            if(!isset($json["LINEAS"]))          return Response::error("Faltan las lineas del albarán", 400);
            if( count($json["LINEAS"]) == 0)     return Response::error("Lineas sin artículos", 400);
            if( isset($json["NUMERO_MANUAL"]) 
               && strlen($json["NUMERO_MANUAL"]) > 50) return Response::error("La longitud máxima del número manual es 50", 400);

            $cliente = auth()->user();

            //dd($cliente);
            //SI ME VIENE UN ID DE CLIENTE, VOY A COMPROBAR QUE EXISTE
            if(isset($json["ID_CLIENTE"]))
            {
                $tmpCliente = User::find($json["ID_CLIENTE"]);

                if ($tmpCliente) $cliente = $tmpCliente;
            }

            //$cCliente = isset($json["ID_CLIENTE"]) ? $json["ID_CLIENTE"] : auth()->user()->CODIGO;

            //VALIDO QUE EL CODIGO DEL ALBARAN NO ESTE REPETIDO
            if(isset($json["ID_ALBARAN"]) && !empty($json["ID_ALBARAN"]))
            {
                $tiquet = Albaran::where('CODIGO_PEDIDO_WEBT', $json["ID_ALBARAN"])
                                ->where('PROYECTO', env("PROYECTO_PEDIDOS", 1))
                                ->where('CLIENTE', $cliente->CODIGO)
                                ->first();

                if($tiquet) return Response::send([
                    "Message" => "El albarán ya fué creado anteriormente",
                    "Numero de albarán" => $tiquet->CODIGO
                ]);
            }

            /* $nombre    = isset($json["DIRECCION_ENVIO"]["NOMBRE"])        ? utf8_decode($json["DIRECCION_ENVIO"]["NOMBRE"])        : "";
            $apellidos = isset($json["DIRECCION_ENVIO"]["APELLIDOS"])     ? utf8_decode($json["DIRECCION_ENVIO"]["APELLIDOS"])     : "";
            $direccion = isset($json["DIRECCION_ENVIO"]["DIRECCION"])     ? utf8_decode($json["DIRECCION_ENVIO"]["DIRECCION"])     : "";
            $poblacion = isset($json["DIRECCION_ENVIO"]["POBLACION"])     ? utf8_decode($json["DIRECCION_ENVIO"]["POBLACION"])     : "";
            $cp        = isset($json["DIRECCION_ENVIO"]["CODIGO_POSTAL"]) ?             $json["DIRECCION_ENVIO"]["CODIGO_POSTAL"]  : "";
            $provincia = isset($json["DIRECCION_ENVIO"]["PROVINCIA"])     ? utf8_decode($json["DIRECCION_ENVIO"]["PROVINCIA"])     : "";
            $telefono  = isset($json["DIRECCION_ENVIO"]["TELEFONO"])      ?             $json["DIRECCION_ENVIO"]["TELEFONO"]       : ""; */

            $nombre        = (!empty($json["DIRECCION_ENVIO"]["NOMBRE"])         && isset($json["DIRECCION_ENVIO"]["NOMBRE"]))         ? $json["DIRECCION_ENVIO"]["NOMBRE"]         : "";
            $apellidos     = (!empty($json["DIRECCION_ENVIO"]["APELLIDOS"])      && isset($json["DIRECCION_ENVIO"]["APELLIDOS"]))      ? $json["DIRECCION_ENVIO"]["APELLIDOS"]      : "";
            $direccion     = (!empty($json["DIRECCION_ENVIO"]["DIRECCION"])      && isset($json["DIRECCION_ENVIO"]["DIRECCION"]))      ? $json["DIRECCION_ENVIO"]["DIRECCION"]      : "";
            $poblacion     = (!empty($json["DIRECCION_ENVIO"]["POBLACION"])      && isset($json["DIRECCION_ENVIO"]["POBLACION"]))      ? $json["DIRECCION_ENVIO"]["POBLACION"]      : "";
            $cp            = (!empty($json["DIRECCION_ENVIO"]["CODIGO_POSTAL"])  && isset($json["DIRECCION_ENVIO"]["CODIGO_POSTAL"]))  ? $json["DIRECCION_ENVIO"]["CODIGO_POSTAL"]  : "";
            $provincia     = (!empty($json["DIRECCION_ENVIO"]["PROVINCIA"])      && isset($json["DIRECCION_ENVIO"]["PROVINCIA"]))      ? $json["DIRECCION_ENVIO"]["PROVINCIA"]      : "";
            $telefonoFijo  = (!empty($json["DIRECCION_ENVIO"]["TELEFONO"])       && isset($json["DIRECCION_ENVIO"]["TELEFONO"]))       ? $json["DIRECCION_ENVIO"]["TELEFONO"]       : "";
            $telefonoMovil = (!empty($json["DIRECCION_ENVIO"]["TELEFONO_MOVIL"]) && isset($json["DIRECCION_ENVIO"]["TELEFONO_MOVIL"])) ? $json["DIRECCION_ENVIO"]["TELEFONO_MOVIL"] : "";
            $pais          = (!empty($json["DIRECCION_ENVIO"]["PAIS"])           && isset($json["DIRECCION_ENVIO"]["PAIS"]))           ? $json["DIRECCION_ENVIO"]["PAIS"]           : "";
            $ISOPais       = (!empty($json["DIRECCION_ENVIO"]["ISO_PAIS"])       && isset($json["DIRECCION_ENVIO"]["ISO_PAIS"]))       ? $json["DIRECCION_ENVIO"]["ISO_PAIS"]       : "";

            if (isset($ISOPais)) //SI TENGO LA ISO VAMOS A PRIORIZAR USAR EL PAIS DE LA TABLA PAISES
            {
                $objPais = Pais::where("ISO_PAIS", $ISOPais)->first();   

                if ($objPais) $pais = $objPais->DESCRIPCION;
            }


            //PRIMERO BUSCO LA LINEA DE LA DIRECCION DEL CLIENTE
            $dirCliente = DireccionCliente::where("CLIENTE", $cliente->CODIGO)
                                          //->whereRaw("UPPER(NOMBRE)                    = UPPER('". str_replace("'", "''", $nombre .' '. $apellidos) ."')")
                                          ->where("NOMBRE", utf8_decode(str_replace("'", "''", $nombre .' '. $apellidos)))
                                          //->whereRaw("UPPER(DIRECCION)                 = UPPER('". str_replace("'", "''", $direccion) ."')")
                                          ->where("DIRECCION", utf8_decode(str_replace("'", "''", $direccion)))
                                          //->whereRaw("UPPER(PROVINCIA)                 = UPPER('". str_replace("'", "''", $provincia) ."')")
                                          ->where("PROVINCIA", utf8_decode(str_replace("'", "''", $provincia)))
                                          //->whereRaw("UPPER(POBLACION)                 = UPPER('". str_replace("'", "''", $poblacion) ."')")
                                          ->where("POBLACION", utf8_decode(str_replace("'", "''", $poblacion)))
                                          //->whereRaw("UPPER(PAIS_DIRECCIONES_CLIENTES) = UPPER('". str_replace("'", "''", $pais) ."')")
                                          ->where("PAIS_DIRECCIONES_CLIENTES", utf8_decode(str_replace("'", "''", $pais)))
                                          ->where("CP", $cp)
                                          ->where("TELEFONOFIJO",  $telefonoFijo)
                                          ->where("TELEFONOMOVIL", $telefonoMovil);
                                          /* ->toSQL()->dd(); */
                                          /* ->first(); */
            //$dirCliente->toSQL()->dd();
            //dump($dirCliente->toSql());

            $dirCliente = $dirCliente->first();

            //dd($dirCliente);

            //SI NO LA ENCUENTRO LA CREO
            if(!$dirCliente)
            {
                $dirCliente = DireccionCliente::create([
                    "CLIENTE"                   => $cliente->CODIGO,
                    "LINEA"                     => DireccionCliente::siguienteLinea($cliente->CODIGO), 
                    "DIRECCION"                 => utf8_decode($direccion),
                    "POBLACION"                 => utf8_decode($poblacion),
                    "PAIS_DIRECCIONES_CLIENTES" => utf8_decode($pais),
                    "CP"                        => $cp,
                    "PROVINCIA"                 => utf8_decode($provincia),
                    "TELEFONOFIJO"              => $telefonoFijo,
                    "TELEFONOMOVIL"             => $telefonoMovil,
                    "NOMBRE"                    => utf8_decode($nombre .' '. $apellidos) 
                ]);

                //dd($dirCliente);
            }

            //GENERO UN CODIGO DE ALBARAN
            $res = DB::select('SELECT GEN_ID(PEDCLI_CODIGO_GEN, 1) as N_CODIGO FROM RDB$DATABASE')[0];

            $cTiquet = $res->N_CODIGO;

            $pvpTotal = 0;

            //INSERTAMOS EL ALBARAN
            $tiquet = new Albaran;

            $tiquet->CODIGO   = $cTiquet;
            $tiquet->CLIENTE  = $cliente->CODIGO;
            $tiquet->FECHA    = date("m-d-Y");
            $tiquet->TITULO   = "Albaran WEB (".$json["ID_ALBARAN"].")";
            $tiquet->PROYECTO = env("PROYECTO_PEDIDOS", 1); 
            $tiquet->LINEADIRECCIONENVIO = $dirCliente->LINEA;
            $tiquet->COMENTARIO_ENVIO = utf8_decode(isset($json["COMENTARIO_ENVIO"]) ? $json["COMENTARIO_ENVIO"] : "");
            $tiquet->FORMADEPAGO  = $cliente->FORMADEPAGO;
            $tiquet->ESTADO       = utf8_decode(isset($json["ESTADO"]) ? $json["ESTADO"] : "");
            $tiquet->NUMEROMANUAL = isset($json['NUMERO_MANUAL']) ? $json['NUMERO_MANUAL'] : "";
            
            if(isset($json["ID_ALBARAN"]) && !empty($json["ID_ALBARAN"])) $tiquet->CODIGO_PEDIDO_WEBT = $json["ID_ALBARAN"];

            if (config('app.b2b') && isset($json["IMPUESTO"]))
            {
                $iva = $json["IMPUESTO"];
                $impuesto = null;

                if(is_numeric($iva)) $impuesto = Impuesto::where("IVA", $iva)->first(); 
    
                if (!$impuesto || $json["IMPUESTO"] == "0") $impuesto = Impuesto::find("99");

                $tiquet->IMPUESTO = $impuesto->CODIGO;
            }

            $tiquet->save();

            if (config('app.asignar_agencia_auto')) $this->asignarAgencia($cTiquet);

            //INSERTAMOS LAS LINEAS DEL ALBARAN
            foreach ($json["LINEAS"] as $linea)
            {
                $linArticulo = isset($linea["ARTICULO"]) ? $linea["ARTICULO"] : "";
            
                //PRIMERO MIRO QUE EL ARTICULO NO ESTÉ BLOQUEADO Y EXISTA, SI NO LO CANCELO TODO
                //$articulo = Articulo::find($linArticulo);
                //$articulo = $this->buscarArticulo($linArticulo, env("PROYECTO_STOCK", 1));
                $articulo = Utils::buscarArticulo($linArticulo, config("app.proyecto_stock", 1));

                //dd($articulo);

                if(!$articulo || $articulo->bloqueado())
                {
                    $tiquet->delete();
                    return Response::error("El artículo ".$linArticulo." no está disponible", '400');
                }

                $lintiquet = new Lintiquet;

                $cantidad = round(isset($linea["CANTIDAD"]) ? $linea["CANTIDAD"] : 0);
                

                $lintiquet->TIQUET     = $tiquet->CODIGO;
                $lintiquet->LINEA      = "0";
                //$lintiquet->ARTICULO   = $linea["ARTICULO"];
                $lintiquet->ARTICULO   = $articulo->CODIGO;
                $lintiquet->CANTIDAD   = ($cantidad > 0) ? $cantidad : 0;
                $lintiquet->COMENTARIO = isset($linea["COMENTARIO"]) ? utf8_decode($linea["COMENTARIO"]) : "";

                if (config('app.b2b') && isset($linea['PVP']))
                {
                    $pvp = $linea['PVP'];  

                    $pvpTotal += $pvp;
                    
                    $importe = $cantidad * $pvp;

                    $lintiquet->IMPORTE  = $importe;
                    $lintiquet->PVP      = $pvp;
                    $lintiquet->PVPFINAL = $pvp;

                    if (isset($linea['DESCUENTO']))
                    {
                        $dto = $linea['DESCUENTO'];

                        $lintiquet->DTO = number_format($dto, 2);
                        $lintiquet->PVPFINAL = $pvp - ($pvp * $dto / 100);
                    }
                }
                
                $lintiquet->save();
            }

            if (config('app.b2b') && isset($json['IMPORTE_PORTES']))
            {
                $impPortes = $json['IMPORTE_PORTES'];

                $lintiquet = new Lintiquet;
                $lintiquet->TIQUET = $tiquet->CODIGO;
                $lintiquet->LINEA = "0";
                $lintiquet->ARTICULO = "PORTES".((date("i") <> "00") ? round(date("i")) : "");
                $lintiquet->CANTIDAD = 1;
                $lintiquet->PVP      = $impPortes;
                $lintiquet->PVPFINAL = $impPortes;
                $lintiquet->IMPORTE  = $impPortes;

                $lintiquet->save();

                //dump($lintiquet);
            }

            //POR ULTIMO RECALCULAMOS LOS PVPS
            if ($pvpTotal == 0) $res = DB::select("EXECUTE PROCEDURE RECALCULAR_PVP_TIQUET(".$cTiquet.", 0)");
            
            $res = DB::select("EXECUTE PROCEDURE RECALCULAR_COSTES_TIQUET(".$cTiquet.", 0)");

            //CREAMOS LA CARPETA SI PROCEDE
            if(isset($json['CREAR_CARPETA']) && ($json['CREAR_CARPETA'] == 'S' || $json['CREAR_CARPETA'] == true))
            {
                mkdir(Config::directorioImagenes(). '/albaranes_venta/' . $cTiquet .'/');
            }
        }
        catch(\Exception $err)
        {
            //dd($err);
            if(isset($tiquet)) $tiquet->delete();

            return Response::error(utf8_encode($err->getMessage()), '500');
        }

        return Response::send([
            "Message" => "Albaran creado correctamente",
            "Numero de albarán" => $cTiquet
        ]);
    }

    public function asignarAgencia($cTiquet)
    {
        $cAgencia = 0;
        $tiquet = Albaran::find($cTiquet);

        if (!$tiquet) return;

        $res = DB::select("SELECT AGENCIA FROM AGENCIAS_DOCUMENTO(2, $cTiquet)")[0];

        if (empty($res) || empty($res->AGENCIA)) return;

        $cAgencia = $res->AGENCIA;

        $tiquet->AGENCIA = $cAgencia;

        $tiquet->save();
    }
}
