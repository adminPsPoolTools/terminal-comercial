<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Helpers\ResponseHelper as Response;
use App\Models\Categoria;

class CategoriasController extends Controller
{
    /**
     * Index mostrará todas las categorias
     * 
     * @return Collection<Categoria>
     * 
     */
    public function index(){

        $response = CategoriasController::obtenerCategorias();

        return Response::send($response);
    }

    /**
     * Show mostrará la categoria que se pase por parámetro
     * 
     * @param Categoria $categoria
     * @return Collection<Categoria>
     * 
     */
    public function show(Categoria $categoria){
        Response::error("Llamada no disponible actualmente", 500);
    }

    public static function obtenerCategorias()
    {
        $categorias = Categoria::selectRaw("CODIGO, CATEGORIASWEB_CATEGORIASWEB.CATEGORIA_PADRE, MAX(DESCRIPCION) AS NOMBRE, MAX(DESCRIPCION_COMPLETA) AS DESCRIPCION")
                               ->leftJoin("CATEGORIASWEB_CATEGORIASWEB", "CATEGORIASWEB_CATEGORIASWEB.CATEGORIA_HIJO", "=", "CATEGORIASWEB.CODIGO") 
                               ->whereRaw("BLOQUEADO <> 'S'")
                               ->where("CODIGO", "<>", "0")
                               //->whereNotNull("CATEGORIASWEB_CATEGORIASWEB.CATEGORIA_PADRE")
                               ->where("CATEGORIASWEB.PROYECTO", env("PROYECTO"))
                               ->groupBy("CODIGO", "CATEGORIASWEB_CATEGORIASWEB.CATEGORIA_PADRE")
                               ->orderBy("CODIGO")
                               ->get();

        $response = array(
            "cantidad_categorias" => $categorias->count()
        );

        $cats = array();

        foreach ($categorias as $categoria)
        {
            //dd($categoria);
            array_push($cats, $categoria->toArray());
        }

        $response['categorias'] = $cats;

        return $response;
    }
}
