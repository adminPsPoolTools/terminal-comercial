<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

use App\Models\Articulo;
use App\Models\Config;
use App\Helpers\ResponseHelper as Response;
use App\Helpers\ArrayHelper;
use App\Helpers\UtilsHelper as Utils;

class ArticulosController extends Controller
{
    public function index()
    {
        //dd(ArticulosController::obtenerArticulos());
        $fechaHora = isset($_GET['fechahora']) ? $_GET['fechahora'] : null;
        $sku       = isset($_GET['sku'])       ? $_GET['sku']       : null;

        //die($fechaHora);

        return Response::send(ArticulosController::obtenerArticulos(null, $fechaHora, $sku));
    }

    public static function obtenerArticulos($campos = null, $fechaHora = null, $sku = null)
    {
        $articulos = Articulo::selectRaw("ARTICULOS.CODIGO, ARTICULOS.DESCRIPCION, ARTICULOS.DESCRIPCION_WEB, ARTICULOS.COMENTARIO_WEB, ARTICULOS.COMENTARIO_WEB_CORTO,
                                          AI.TRADUCCION_DESCRIPCION AS DESCRIPCION_EN, ARTICULOS.PRECIO, 
                                          ARTICULOS.IMPUESTO, COALESCE(ARTICULOS.DESCATALOGADO, 'N') AS DESCATALOGADO, COALESCE(ARTICULOS.OCULTO, 'N') AS OCULTO, 
                                          ARTICULOS.REFERENCIA_FABRICANTE, ARTICULOS.UNIDADESCAJA, ARTICULOS.PESO, ARTICULOS.MEDIDA, ARTICULOS.UDS_PACK, ARTICULOS.SLUG, 
                                          ARTICULOS.FAMILIA, ARTICULOS.PROVEEDOR, ARTICULOS.MARCA, ARTICULOS.COLECCION,
                                          
                                          P_STOCK.STOCK, PROYECTO.PVP, PROYECTO.PVP_CAJA, PROYECTO.PVP_PACK, PROYECTO.PVP_RECOMENDADO, PROYECTO.PVP_MINIMO, 
                                          PROYECTO.BLOQUEADO AS P_BLOQUEADO, P_STOCK.BLOQUEADO AS STOCK_BLOQUEADO,
                                          CODIGOS_CATWEB")
                             ->leftJoin("ARTICULOS_IDIOMAS AS AI", function($join){
                                $join->on("ARTICULOS.CODIGO", "=", "AI.ARTICULO")
                                     ->whereRaw("AI.IDIOMA = (SELECT CODIGO FROM IDIOMAS WHERE UPPER(ISO_IDIOMA) = 'EN')");
                             })
                             ->leftJoin("IDIOMAS", "IDIOMAS.CODIGO", "AI.IDIOMA")
                             ->leftJoin("PROYECTO as P_STOCK", function ($join){
                                $join->on("ARTICULOS.CODIGO", "=", "P_STOCK.ARTICULO")
                                     ->where("P_STOCK.PROYECTO", "=", explode(',', config("app.proyecto_stock", 1))[0]);
                             })
                             ->leftJoin("PROYECTO", function ($join){
                                $join->on("ARTICULOS.CODIGO", "=", "PROYECTO.ARTICULO")
                                     ->where("PROYECTO.PROYECTO", "=", env("PROYECTO", 1));
                             })
                             ->leftJoin(DB::raw('CODIGOS_CATWEB_ARTICULO(PROYECTO.PROYECTO, ARTICULOS.CODIGO)'), DB::raw("0"), DB::raw("0"))
                             ->leftJoin("MARCAS", "MARCAS.CODIGO", "ARTICULOS.MARCA")
                             ->leftJoin("MARCAS_COLECCIONES", "MARCAS_COLECCIONES.MARCA", "MARCAS.CODIGO")
                             ->leftJoin("MARCAS_COLECCIONES_CLIENTES", function ($join){
                                $join->on("MARCAS_COLECCIONES_CLIENTES.MARCA", "MARCAS.CODIGO")
                                     ->where("MARCAS_COLECCIONES_CLIENTES.CLIENTE", auth()->user()->CODIGO);
                             })
                             //->where("P_STOCK.STOCK", ">", "0")
                             ->where(function ($query){
                                $query->where("MARCAS_COLECCIONES.BLOQUEADO_API", "<>", "S")
                                      ->orWhereNull("MARCAS_COLECCIONES.BLOQUEADO_API");
                             })
                             ->where(function ($query){
                                $query->where("MARCAS_COLECCIONES_CLIENTES.BLOQUEADO_API", "<>", "S")
                                      ->orWhereNull("MARCAS_COLECCIONES_CLIENTES.BLOQUEADO_API");
                             })
                             ->whereRaw("ARTICULOS.CODIGO NOT IN (SELECT ARTICULO FROM LINCONJUNTOS)");

        if (!config('app.mostrar_bloqueados'))
        {
            $articulos = $articulos->whereRaw("PROYECTO.BLOQUEADO <> 'S'")
                                   ->whereRaw("P_STOCK.BLOQUEADO <> 'S'");
        }

        if (config('app.con_categoriasweb'))
        {
            $articulos = $articulos->leftJoin("CATEGORIASWEB_ARTICULO", "CATEGORIASWEB_ARTICULO.ARTICULO", "ARTICULOS.CODIGO")
                                   ->whereNotNull("CATEGORIASWEB_ARTICULO.ARTICULO");
        }

        if ($fechaHora)
        {
            $fechaUltimaModificacion = date("m-d-Y H:i:s", strtotime($fechaHora));

            $articulos = $articulos->whereRaw('ARTICULOS.FECHA_ULTIMA_MODIFICACION >= \''. $fechaUltimaModificacion . '\'');
        }

        if($sku) $articulos = $articulos->where('ARTICULOS.CODIGO', $sku);

        //$articulos->toSQL()->dd();

        $articulos = $articulos->groupBy("ARTICULOS.CODIGO", "ARTICULOS.DESCRIPCION", "ARTICULOS.DESCRIPCION_WEB", "ARTICULOS.COMENTARIO_WEB", "ARTICULOS.COMENTARIO_WEB_CORTO",
                                          "DESCRIPCION_EN", "ARTICULOS.PRECIO", "ARTICULOS.IMPUESTO", "DESCATALOGADO", "OCULTO", 
                                          "ARTICULOS.REFERENCIA_FABRICANTE", "ARTICULOS.UNIDADESCAJA", "ARTICULOS.PESO", "ARTICULOS.MEDIDA", "ARTICULOS.UDS_PACK", "ARTICULOS.SLUG", 
                                          "ARTICULOS.FAMILIA", "ARTICULOS.PROVEEDOR", "ARTICULOS.MARCA", "ARTICULOS.COLECCION",
                                          
                                          "P_STOCK.STOCK", "PROYECTO.PVP", "PROYECTO.PVP_CAJA", "PROYECTO.PVP_PACK", "PROYECTO.PVP_RECOMENDADO", "PROYECTO.PVP_MINIMO", 
                                          "P_BLOQUEADO", "STOCK_BLOQUEADO", "CODIGOS_CATWEB")
                               ->orderBy("ARTICULOS.CODIGO")
                               /* ->toSQL()->dd(); */
                               ->get();

        $response = array(
            "cantidad_articulos" => $articulos->count()
        );
        
        $arts = array();

        //dd($articulos);

        foreach ($articulos as $articulo)
        {
            $arrayArticulos = [
                "CODIGO"                 => $articulo->CODIGO, 
                "FAMILIA"                => $articulo->FAMILIA,
                "DESCRIPCION"            => (Config::obtenerAPIEnviarDatosWeb() && !empty(trim($articulo->DESCRIPCION_WEB))) ? $articulo->DESCRIPCION_WEB : $articulo->DESCRIPCION, 
                "DESCRIPCION_EN"         => $articulo->DESCRIPCION_EN, 
                "CODIGOS_CATWEB"         => $articulo->CODIGOS_CATWEB, 
                "PRECIO"                 => round($articulo->PVP, 2), 
                "PRECIO_RECOMENDADO"     => round($articulo->PVP_RECOMENDADO, 2),
                "PRECIO_MINIMO"          => round($articulo->PVP_MINIMO, 2),
                "IMPUESTO"               => $articulo->IMPUESTO, 
                "DESCATALOGADO"          => trim($articulo->DESCATALOGADO), 
                "STOCK"                  => $articulo->stockVendible(), 
                "EANS"                   => $articulo->eans(), 
                "REF_FABRICANTE"         => $articulo->REFERENCIA_FABRICANTE, 
                "UDS_CAJA"               => round($articulo->UNIDADESCAJA), 
                "UDS_PACK"               => round($articulo->UDS_PACK), 
                "PESO"                   => round($articulo->PESO, 2), 
                "MEDIDA"                 => $articulo->MEDIDA, 
                "MARCA"                  => $articulo->marca(), 
                "IMAGENES"               => $articulo->imagenes(),
                "ARTICULOS_RELACIONADOS" => $articulo->articulosRelacionados(),
                "CONJUNTOS_RELACIONADOS" => $articulo->conjuntosRelacionados(),
            ];

            if (config('app.b2b'))
            {
                $proximoStock = $articulo->proximoStockDisponible();

                $fechaProximaDisponibilidad = strtotime((!empty($proximoStock->FECHA_DISPONIBILIDAD)) ? $proximoStock->FECHA_DISPONIBILIDAD : $articulo->fechaProximaDisponibilidadProveedor());
                $fechaProximaDisponibilidad = date("Y-m-d", $fechaProximaDisponibilidad);

                //$arrayArticulos['DISPONIBILIDAD'] = $articulo->disponibilidad()->DISPONIBILIDAD;
                //$arrayArticulos['PROXIMO_STOCK_DISPONIBLE'] = ($proximoStock->STOCK_DISPONIBLE ?? 0);
                $arrayArticulos['FECHA_PROXIMA_DISPONIBILIDAD'] = $fechaProximaDisponibilidad;
            } 
            
            if(Config::obtenerAPIEnviarDatosWeb()) $arrayArticulos['COMENTARIO']       = $articulo->COMENTARIO_WEB;
            if(Config::obtenerAPIEnviarDatosWeb()) $arrayArticulos['COMENTARIO_CORTO'] = $articulo->COMENTARIO_WEB_CORTO;
            if(!empty($articulo->SLUG))            $arrayArticulos["URL"]              = Utils::webUrl($articulo->SLUG, $articulo->CODIGO);
            if(config('app.mostrar_bloqueados'))   $arrayArticulos['BLOQUEADO']        = ($articulo->P_BLOQUEADO == 'S' || $articulo->STOCK_BLOQUEADO == 'S');
            if(config('app.mostrar_ocultos'))      $arrayArticulos['OCULTO']           = ($articulo->OCULTO == 'S');

            array_push($arts, $arrayArticulos);
        }

        if($campos) $arts = ArrayHelper::filtrar($arts, $campos);
        
        $response['articulos'] = $arts;

        return $response;
    }

}
