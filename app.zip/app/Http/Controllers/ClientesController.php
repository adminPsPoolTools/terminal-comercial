<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Helpers\ArrayHelper;
use App\Helpers\ResponseHelper as Response;

use App\Models\Cliente;

class ClientesController extends Controller
{
    public function index()
    {
        $clientes = $this->obtenerClientes();

        return Response::send($clientes);
    }

    public function obtenerClientes($campos = null)
    {
        $clientes = Cliente::selectRaw("CODIGO, DESCRIPCION, ALIAS, CORREO, CP, DIRECCION, POBLACION, PROVINCIA, PAIS, TELEFONOFIJO, TELEFONOMOVIL, CIF, RIESGO,
                                        CONTACTO, NO_CREDITO, TARIFA, BLOQUEADO")
            ->leftJoin("CLIENTES_PROYECTOS", "CLIENTES_PROYECTOS.CLIENTE", "CLIENTES.CODIGO")
            ->where("CLIENTES_PROYECTOS.PROYECTO", env('PROYECTO', 1))
            ->get();

        if (!config('app.mostrar_bloqueados')) {
            $clientes = $clientes->whereRaw("BLOQUEADO <> 'S'");
        }

        $response = array(
            "cantidad_clientes" => $clientes->count()
        );

        $clints = array();

        foreach ($clientes as $cliente) {
            $arrayClientes = [
                "CODIGO"           => $cliente->CODIGO,
                "NOMBRE_FISCAL"    => $cliente->DESCRIPCION,
                "NOMBRE_COMERCIAL" => $cliente->ALIAS,
                "EMAIL"            => $cliente->CORREO,
                "CODIGO_POSTAL"    => $cliente->CP,
                "DIRECCION"        => $cliente->DIRECCION,
                "POBLACION"        => $cliente->POBLACION,
                "PROVINCIA"        => $cliente->PROVINCIA,
                "PAIS"             => $cliente->PAIS,
                "TELEFONO_FIJO"    => $cliente->TELEFONOFIJO,
                "TELEFONO_MOVIL"   => $cliente->TELEFONO_MOVIL,
                "CIF"              => $cliente->CIF,
                "RIESGO"           => $cliente->riesgo(),
                "PERMITIR_RIESGO"  => $cliente->NO_CREDITO == "N" || $cliente->riesgo() <= 0,
                "CONTACTO"         => ($cliente->CONTACTO) ? $cliente->CONTACTO : $cliente->obtenerContacto(),
                "TARIFAS"          => $cliente->tarifas(),
                "DIRECCIONES"      => $cliente->direcciones()
            ];

            if (config('app.mostrar_bloqueados')) {
                $arrayClientes['BLOQUEADO'] = ($cliente->P_BLOQUEADO == 'S' || $cliente->STOCK_BLOQUEADO == 'S');
            }

            array_push($clints, $arrayClientes);

            //dd($cliente->direcciones());
        }

        if ($campos) $clints = ArrayHelper::filtrar($clints, $campos);

        $response['clientes'] = $clints;

        /* print_r($response);
        dd(); */

        return $response;
    }
}
