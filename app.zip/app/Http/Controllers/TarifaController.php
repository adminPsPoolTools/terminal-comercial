<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Helpers\ArrayHelper;
use App\Helpers\ResponseHelper as Response;

use App\Models\Tarifa;

class TarifaController extends Controller
{
    public function index()
    {
        $tarifas = $this->obtenerTarifas();

        return Response::send($tarifas);
    }

    public function obtenerTarifas()
    {
        $tarifas = Tarifa::select("CODIGO", "TIPO")
                         ->where("DURANTE_PERIODO", "<>", "S") 
                         ->get();

        $response = array(
            "cantidad_tarifas" => $tarifas->count()
        );

        $tarif = array();

        foreach ($tarifas as $tarifa)
        {
            $arrayTarifas = [
                "tipo"      => $tarifa->TIPO, 
                "id_tarifa" => $tarifa->CODIGO,
                "familia"   => $tarifa->familias(),
                "articulos" => $tarifa->articulos()
            ];
            
            array_push($tarif, $arrayTarifas);
        }

        //if($campos) $tarif = ArrayHelper::filtrar($tarif, $campos);
        
        $response['tarifas'] = $tarif;

        /* print_r($response);
        dd(); */

        return $response;
    }
}
