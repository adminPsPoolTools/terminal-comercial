<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;

use App\Models\Articulo;
use App\Models\ConjuntoArticulos;

use App\Helpers\ResponseHelper as Response;

class CatalogoController extends Controller
{
    public function catalogo()
    {
        $fechaHora   = isset($_GET['fechahora'])   ? $_GET['fechahora']   : null;
        $sku         = isset($_GET['sku'])         ? $_GET['sku']         : null;
        $soloFichero = isset($_GET['soloFichero']) ? $_GET['soloFichero'] : false;

        $extraString = "";

        switch (config("app.tipo_catalogo"))
        {
            case 'FICHEROS':
                if (!empty($fechaHora) || !empty($sku))
                {
                    $result = $this->generarFicheroCatalogoCompleto($fechaHora, $sku);
                    break;
                }
                
                //PRIMERO COMPRUEBO SI EL FICHERO EXISTE
                /* $filename = 'catalogos/catalogo_'.date("Ymd").'.json';
                $filenameAnterior = 'catalogos/catalogo_'.date("Ymd", strtotime('-1 day')).'.json';

                if (Storage::exists($filename)) 
                {
                    $result = (array) json_decode(Storage::get($filename));
                    $extraString = "Catálogo del ".date("d-m-Y H:i:s", Storage::lastModified($filename));                    
                }
                else
                {
                    if(!empty($soloFichero))
                    {
                        $result = $this->generarFicheroCatalogoCompleto($fechaHora, $sku);    
    
                        Storage::put($filename, json_encode($result));

                        die("Fichero generado");
                    }

                    $result = (array) json_decode(Storage::get($filenameAnterior));
                    $extraString = "Catálogo del ".date("d-m-Y H:i:s", Storage::lastModified($filenameAnterior)); 
                    //$extraString = "Catálogo del ".date("d-m-Y H:i:s");
                } */

                try {
                    $res = $this->obtenerFicheroDisponible($soloFichero, $fechaHora, $sku);

                    $result      = $res["result"];
                    $extraString = $res["extraString"];

                } catch (\Exception $th) {
                    
                    return Response::error($th->getMessage(), 404);
                }

                break;

            case 'JSON':
            default:
                
                $result = $this->generarFicheroCatalogoCompleto($fechaHora, $sku);        
                break;
        }

        return Response::send($result, $extraString);
    }

    /* public function catalogo()
    {
        $result = array();

        $result = array_merge($result, CategoriasController::obtenerCategorias());
        $result = array_merge($result, ArticulosController::obtenerArticulos([
            "CODIGO", "DESCRIPCION", "DESCRIPCION_EN", "PRECIO", "IMPUESTO", "DESCATALOGADO", "REFERENCIA_FABRICANTE", "UNIDADESCAJA", "PESO",
            "MEDIDA", "UDS_PACK", "STOCK", "PVP", "PVP_CAJA", "PVP_PACK", "PVP_RECOMENDADO", "CODIGOS_CATWEB", "MARCA"
        ]));
        $result = array_merge($result, ConjuntosController::obtenerConjuntos([
            "CODIGO", "DESCRIPCION", "DESCRIPCION_EN", "REFERENCIA_FABRICANTE_CONJUNTO", "LINEAS", "MARCA"
        ]));

        return Response::send($result, 200);
    } */

    public function generarFicheroCatalogoCompleto($fechaHora = null, $sku = null)
    {
        $result = array();

        $result = array_merge($result, CategoriasController::obtenerCategorias(["CODIGO", "CATEGORIA_PADRE", "NOMBRE", "DESCRIPCION"]));

        $result = array_merge($result, ArticulosController::obtenerArticulos(["CODIGO", "DESCRIPCION", "DESCRIPCION_EN", "CODIGOS_CATWEB", "PRECIO", "PRECIO_RECOMENDADO", "PRECIO_MINIMO","IMPUESTO", "DESCATALOGADO", "BLOQUEADO", "STOCK", "EANS", "REF_FABRICANTE", "UDS_CAJA", "UDS_PACK", "PESO", "MEDIDA", "MARCA", "COMENTARIO", "COMENTARIO_CORTO", "ARTICULOS_RELACIONADOS", "CONJUNTOS_RELACIONADOS", "DISPONIBILIDAD","PROXIMO_STOCK_DISPONIBLE", "FECHA_PROXIMA_DISPONIBILIDAD", "IMAGENES", "URL"], $fechaHora, $sku));
       
        $result = array_merge($result, ConjuntosController::obtenerConjuntos(["sku", "descripcion", "descripcion_en", "descripcion_multiplicador1", "descripcion_multiplicador2", "descripcion_multiplicador3", "comentario_conjunto", "comentario_corto", "bloqueado", "articulos_relacionados", "conjuntos_relacionados", "referencia_fabricante", "marca", "url", "lineas"], $fechaHora, $sku)); 
        
        return $result;
    }

    public function consultarDisponibilidad($codigo)
    {
        //PRIMERO COMPRUEBO QUE NO SEA UN STRING
        if (!preg_match('/^[0-9]+$/', $codigo)) {
            // La variable contiene letras u otros caracteres
            return Response::error("El código tiene que ser numérico, no puede contener letras", 400);
        }


        //SI NO MIRO EL CONJUNTO
        $conjunto = ConjuntoArticulos::find($codigo);

        if($conjunto)
        {
            $arrayLineas = $conjunto->linconjuntos()/* ->toArray() */;

            $lineasConjuntoArray = [];

            foreach ($arrayLineas as $linconjunto)
            {
                $lineaConjunto = [
                    "CODIGO"         => $linconjunto->ARTICULO,
                    "PREDETERMINADO" => $linconjunto->PREDETERMINADO == 'S',
                    "FAMILIA"        => $linconjunto->FAMILIA,
                    "MULTIPLICADOR1" => $linconjunto->MULTI1,
                    "MULTIPLICADOR2" => $linconjunto->MULTI2,
                    "MULTIPLICADOR3" => $linconjunto->MULTI3,
                    "CATEGORIAS_WEB" => $linconjunto->CODIGOS_CATWEB,
                    /* "PRECIO" => round($linconjunto->PVP, 2), */
                    /* "PRECIO_RECOMENDADO" => round($linconjunto->PVP_RECOMENDADO, 2),
                    "PRECIO_MINIMO" => round($linconjunto->PVP_MINIMO, 2), */
                    "PRECIO" => $linconjunto->PVP,
                    "PRECIO_RECOMENDADO" => $linconjunto->PVP_RECOMENDADO,
                    "PRECIO_MINIMO" => $linconjunto->PVP_MINIMO,
                    "IMPUESTO" => $linconjunto->IMPUESTO,
                    "DESCATALOGADO" => $linconjunto->DESCATALOGADO,
                    "OCULTO" => $linconjunto->OCULTO,
                    "STOCK" => $linconjunto->articulo->stockVendible(),
                    "EANS" => $linconjunto->eans(),
                    "REF_FABRICANTE" => utf8_encode($linconjunto->REFERENCIA_FABRICANTE),
                    /* "UDS_CAJA" => round($linconjunto->UNIDADESCAJA, 2),
                    "UDS_PACK" => round($linconjunto->UDS_PACK, 2),
                    "PESO" => round($linconjunto->PESO, 2), */
                    "UDS_CAJA" => $linconjunto->UNIDADESCAJA,
                    "UDS_PACK" => $linconjunto->UDS_PACK,
                    "PESO" => $linconjunto->PESO,
                    "MEDIDA" => $linconjunto->MEDIDA
                ];

                if(config('app.mostrar_ocultos')) $lineaConjunto['OCULTO'] = ($linconjunto->OCULTO == 'S');

                if (config('app.b2b'))
                {
                    $articulo = $linconjunto->articulo;
                    $proximoStock = $articulo->proximoStockDisponible();

                    $fechaProximaDisponibilidad = strtotime((!empty($proximoStock->FECHA_DISPONIBILIDAD)) ? $proximoStock->FECHA_DISPONIBILIDAD : $articulo->fechaProximaDisponibilidadProveedor());
                    $fechaProximaDisponibilidad = date("Y-m-d", $fechaProximaDisponibilidad);

                    $lineaConjunto['DISPONIBILIDAD'] = $articulo->disponibilidad()->DISPONIBILIDAD;
                    $lineaConjunto['PROXIMO_STOCK_DISPONIBLE'] = ($proximoStock->STOCK_DISPONIBLE ?? 0);
                    $lineaConjunto['FECHA_PROXIMA_DISPONIBILIDAD'] = $fechaProximaDisponibilidad;
                }

                array_push($lineasConjuntoArray, $lineaConjunto);
            }

            $data = array(
                "CODIGO"        => $conjunto->CODIGO,
                "DESCRIPCION"   => $conjunto->DESCRIPCION,
                "DESCRIPCION_EN"=> $conjunto->descripcionIngles(),
                "DESCRIPCION_MULTIPLICADOR1" => $conjunto->DESC_MULTIPLICADOR1 ?? "",
                "DESCRIPCION_MULTIPLICADOR2" => $conjunto->DESC_MULTIPLICADOR2 ?? "",
                "LINEAS"        => $lineasConjuntoArray,
            );

            //dd($data);

            $response = array(
                "data" => $data
            );

            return Response::send($response);
        }

        //MIRO SI ES UN ARTICULO
        $articulo = Articulo::find($codigo);

        
        if($articulo)
        {
            $data = array(
                "CODIGO"         => $articulo->CODIGO,
                "DESCRIPCION"    => $articulo->DESCRIPCION,
                "DESCRIPCION_EN" => $articulo->descripcionIngles(),
                "DESCATALOGADO"  => $articulo->DESCATALOGADO ?? "N",
                "MARCA"          => $articulo->marca(),
                "STOCK"          => $articulo->stockVendible()
            );

            if(config('app.mostrar_ocultos')) $data['OCULTO'] = ($articulo->OCULTO == 'S');

            if(config('app.b2b'))
            {
                $proximoStock = $articulo->proximoStockDisponible();

                $fechaProximaDisponibilidad = strtotime((!empty($proximoStock->FECHA_DISPONIBILIDAD)) 
                                            ? $proximoStock->FECHA_DISPONIBILIDAD 
                                            : $articulo->fechaProximaDisponibilidadProveedor());
                                            
                $fechaProximaDisponibilidad = date("Y-m-d", $fechaProximaDisponibilidad);

                $data['DISPONIBILIDAD']               = $articulo->disponibilidad()->DISPONIBILIDAD;
                $data['PROXIMO_STOCK_DISPONIBLE']     = ($proximoStock->STOCK_DISPONIBLE ?? 0);
                $data['FECHA_PROXIMA_DISPONIBILIDAD'] = $fechaProximaDisponibilidad;
            }

            $response = array("data" => $data);

            return Response::send($response);
        }

        return Response::error("No se ha encontrado el producto", 404);
    }

    public function catalogoConURL()
    {
        $result = array();
        $fechaHora = isset($_GET['fechahora']) ? $_GET['fechahora'] : null;
        $sku       = isset($_GET['sku'])       ? $_GET['sku']       : null;

        $result = array_merge($result, CategoriasController::obtenerCategorias());
        $result = array_merge($result, ArticulosController::obtenerArticulos(null, $fechaHora, $sku));
        $result = array_merge($result, ConjuntosController::obtenerConjuntos(null, $fechaHora, $sku));

        return Response::send($result);
    }

    public function obtenerFicheroDisponible($soloFichero = false, $fechaHora, $sku)
    {
        $diasRetroceder = 0;
        $encontrado = false;
    
        while (!$encontrado)
        {
            $filename = 'catalogos/catalogo_' . date("Ymd", strtotime("-$diasRetroceder day")) . '.json';
    
            if (Storage::exists($filename))
            {
                $result = (array) json_decode(Storage::get($filename));
                $extraString = "Catálogo del " . date("d-m-Y H:i:s", Storage::lastModified($filename));
                $encontrado = true;
            } 
            else 
            {
                $diasRetroceder++;

                if(!empty($soloFichero) && $soloFichero)
                {
                    $result = $this->generarFicheroCatalogoCompleto($fechaHora, $sku);    

                    Storage::put($filename, json_encode($result));

                    $files = Storage::files("catalogo");

                    // Obtener la fecha límite para los archivos (una semana atrás)
                    $oneWeekAgo = now()->subDays(7);

                    foreach ($files as $file)
                    {
                        // Obtener la última fecha de modificación del archivo
                        $lastModified = \Carbon\Carbon::createFromTimestamp(Storage::lastModified($file));

                        // Comparar y eliminar si es más antiguo que una semana
                        if ($lastModified->lessThan($oneWeekAgo))
                        { 
                            Log::info("Fichero borrado: $file");
                            Storage::delete($file);
                        }
                    }
                    
                    die("Fichero generado");
                }
    
                // Evitar bucle infinito, se puede definir un límite de días para retroceder
                if ($diasRetroceder > 365) {
                    // Por ejemplo, dejar de buscar después de un año
                    throw new \Exception("No se ha encontrado ningún fichero de catálogo en el último año.");
                }
            }
        }
    
        // Si se encontró un archivo, la función continuará aquí
        // Puedes añadir el resto del código que necesites
    
        return [
            'result' => $result,
            'extraString' => $extraString
        ];
    }
}
