<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Helpers\ResponseHelper as Response;
use App\Helpers\ArrayHelper;
use App\Helpers\UtilsHelper as Utils;

use App\Models\ConjuntoArticulos;
use App\Models\Config;

class ConjuntosController extends Controller
{
    /**
     * Index mostrará todos los conjuntos
     * 
     * @return Response response
     * 
     */
    public function index()
    {
        $fechahora = isset($_GET['fechahora']) ? $_GET['fechahora'] : null;
        $sku       = isset($_GET['sku'])       ? $_GET['sku']       : null; 

        return Response::send(ConjuntosController::obtenerConjuntos(null, $fechahora, $sku));
    }

    public static function obtenerConjuntos($campos = null, $fechahora = null, $sku = null)
    {
        $conjuntos = ConjuntoArticulos::selectRaw("CONJUNTO_ARTICULOS.CODIGO, CONJUNTO_ARTICULOS.DESCRIPCION, CONJUNTO_ARTICULOS.DESCRIPCION_CONJUNTO_WEB,
                                                   CONJUNTO_ARTICULOS.COMENTARIO_CONJUNTO_WEB, CONJUNTO_ARTICULOS.COMENTARIO_CONJUNTO_WEB_CORTO, SLUG,

                                                   MULTIPLICADOR1.DESCRIPCION AS DESC_MULTI1, MULTIPLICADOR2.DESCRIPCION AS DESC_MULTI2, MULTIPLICADOR3.DESCRIPCION AS DESC_MULTI3,

                                                   CAI.TRADUCCION_DESCRIPCION AS DESCRIPCION_EN, REFERENCIA_FABRICANTE_CONJUNTO, MARCAS.DESCRIPCION AS MARCA,
                                                   PROYECTO.BLOQUEADO AS P_BLOQUEADO, P_STOCK.BLOQUEADO AS STOCK_BLOQUEADO")

                                      ->leftJoin("CONJUNTO_ARTICULOS_IDIOMAS AS CAI", function($join){
                                            $join->on("CONJUNTO_ARTICULOS.CODIGO", "=", "CAI.CONJUNTO")
                                                 ->whereRaw("CAI.IDIOMA = (SELECT CODIGO FROM IDIOMAS WHERE UPPER(ISO_IDIOMA) = 'EN')");
                                      })
                                      ->leftJoin("LINCONJUNTOS", "LINCONJUNTOS.CONJUNTO", "CODIGO")  
                                      ->leftJoin("PROYECTO as P_STOCK", function ($join){
                                            $join->on("LINCONJUNTOS.ARTICULO", "=", "P_STOCK.ARTICULO")
                                                 ->where("P_STOCK.PROYECTO", "=", explode(',', config("app.proyecto_stock", 1))[0]);
                                      })
                                      ->leftJoin("PROYECTO", function ($join){
                                            $join->on("LINCONJUNTOS.ARTICULO", "=", "PROYECTO.ARTICULO")
                                                 ->where("PROYECTO.PROYECTO", "=", env("PROYECTO"));
                                      })
                                      ->leftJoin("MARCAS", "MARCAS.CODIGO", "CONJUNTO_ARTICULOS.MARCA_CONJUNTO")
                                      ->leftJoin("MARCAS_COLECCIONES", "MARCAS_COLECCIONES.MARCA", "MARCAS.CODIGO")
                                      ->leftJoin("MARCAS_COLECCIONES_CLIENTES", function ($join){
                                            $join->on("MARCAS_COLECCIONES_CLIENTES.MARCA", "MARCAS.CODIGO")
                                                 ->where("MARCAS_COLECCIONES_CLIENTES.CLIENTE", auth()->user()->CODIGO);
                                      })
                                      ->leftJoin("TIPO_MULTIPLICADORES as MULTIPLICADOR1", "MULTIPLICADOR1.CODIGO", "CONJUNTO_ARTICULOS.TIPO_MULTIPLICADOR1")
                                      ->leftJoin("TIPO_MULTIPLICADORES as MULTIPLICADOR2", "MULTIPLICADOR2.CODIGO", "CONJUNTO_ARTICULOS.TIPO_MULTIPLICADOR2")
                                      ->leftJoin("TIPO_MULTIPLICADORES as MULTIPLICADOR3", "MULTIPLICADOR3.CODIGO", "CONJUNTO_ARTICULOS.TIPO_MULTIPLICADOR3")
                                      ->whereRaw("CONJUNTO_ARTICULOS.BLOQUEADO <> 'S'")
                                      ->where(function ($query){
                                            $query->where("MARCAS_COLECCIONES.BLOQUEADO_API", "<>", "S")
                                                  ->orWhereNull("MARCAS_COLECCIONES.BLOQUEADO_API");
                                       })
                                       ->where(function ($query){
                                            $query->where("MARCAS_COLECCIONES_CLIENTES.BLOQUEADO_API", "<>", "S")
                                                  ->orWhereNull("MARCAS_COLECCIONES_CLIENTES.BLOQUEADO_API");
                                       });

        if (!config('app.mostrar_bloqueados'))
        {
            $conjuntos = $conjuntos->whereRaw("PROYECTO.BLOQUEADO <> 'S'")
                                   ->whereRaw("P_STOCK.BLOQUEADO <> 'S'");
        }

        if (config('app.con_categoriasweb'))
        {
            $conjuntos = $conjuntos->leftJoin("CATEGORIASWEB_ARTICULO", "CATEGORIASWEB_ARTICULO.ARTICULO", "LINCONJUNTOS.ARTICULO")
                                   ->whereNotNull("CATEGORIASWEB_ARTICULO.ARTICULO");
        }

        if($fechahora)
        {
            $fechaUltimaModificacion = date("m-d-Y", strtotime($fechahora));

            $conjuntos = $conjuntos->whereRaw('CONJUNTO_ARTICULOS.FECHA_ULTIMA_MODIFICACION >= \''. $fechaUltimaModificacion . '\'');
        }        
        
        if($sku) $conjuntos = $conjuntos->where('CONJUNTO_ARTICULOS.CODIGO', $sku);
        

        $conjuntos = $conjuntos->groupBy("CODIGO", "DESCRIPCION", "DESCRIPCION_CONJUNTO_WEB", "COMENTARIO_CONJUNTO_WEB", "COMENTARIO_CONJUNTO_WEB_CORTO", 
                                         "DESC_MULTI1", "DESC_MULTI2", "DESC_MULTI3", "DESCRIPCION_EN", "REFERENCIA_FABRICANTE_CONJUNTO", "SLUG", "MARCA", 
                                         "P_BLOQUEADO", "STOCK_BLOQUEADO")
                               ->orderBy("CODIGO")
                               ->get();

        $response = array("cantidad_conjuntos" => $conjuntos->count());
        
        $conj = array();

        foreach ($conjuntos as $conjunto)
        {
            $arrConjunto = [
                "sku" => $conjunto->CODIGO,
                "descripcion" => (Config::obtenerAPIEnviarDatosWeb() && !empty(trim($conjunto->DESCRIPCION_CONJUNTO_WEB))) ? $conjunto->DESCRIPCION_CONJUNTO_WEB : $conjunto->DESCRIPCION,
                "descripcion_en" => $conjunto->DESCRIPCION_EN,
                "descripcion_multiplicador1" => $conjunto->DESC_MULTI1 ?? "",
                "descripcion_multiplicador2" => $conjunto->DESC_MULTI2 ?? "",
                "descripcion_multiplicador3" => $conjunto->DESC_MULTI3 ?? "",
                "marca" => $conjunto->MARCA,
                "referencia_fabricante"  => $conjunto->REFERENCIA_FABRICANTE_CONJUNTO,
                "articulos_relacionados" => $conjunto->articulosRelacionados(),
                "conjuntos_relacionados" => $conjunto->conjuntosRelacionados()
            ];

            if(Config::obtenerAPIEnviarDatosWeb()) $arrConjunto["comentario_conjunto"] = $conjunto->COMENTARIO_CONJUNTO_WEB;
            if(Config::obtenerAPIEnviarDatosWeb()) $arrConjunto['comentario_corto']    = $conjunto->COMENTARIO_CONJUNTO_WEB_CORTO;
            if(!empty($conjunto->SLUG))            $arrConjunto["url"]                 = Utils::webUrl($conjunto->SLUG, $conjunto->CODIGO);
            if(config('app.mostrar_bloqueados'))   $arrConjunto['bloqueado']           = ($conjunto->P_BLOQUEADO == 'S' || $conjunto->STOCK_BLOQUEADO == 'S');

            $lineasConjuntoArray = [];

            //MIRO SI EL CONJUNTO TIENE IMAGENES EN SU CARPETA, PORQUE ESTAS SON LAS QUE VAN A PREVALECER A LAS DEL ARTICULO
            $imgsConjunto = ConjuntosController::obtenerImagenesConjunto($conjunto->CODIGO);
            //dd($imgsConjunto);

            foreach ($conjunto->linconjuntos() as $linconjunto)
            {
                $articulo      = $linconjunto->articulo;
                $proximoStock  = $articulo->proximoStockDisponible($articulo->stock());

                $fechaProximaDisponibilidad = strtotime((!empty($proximoStock->FECHA_DISPONIBILIDAD)) ? $proximoStock->FECHA_DISPONIBILIDAD : $articulo->fechaProximaDisponibilidadProveedor());
                $fechaProximaDisponibilidad = date("Y-m-d", $fechaProximaDisponibilidad);

                $lineaConjunto = [
                    "CODIGO" => $linconjunto->ARTICULO,
                    "PREDETERMINADO" => $linconjunto->PREDETERMINADO == 'S',
                    "FAMILIA" => $linconjunto->FAMILIA,
                    "MULTIPLICADOR1" => $linconjunto->MULTI1,
                    "MULTIPLICADOR2" => $linconjunto->MULTI2,
                    "MULTIPLICADOR3" => $linconjunto->MULTI3,
                    "CATEGORIAS_WEB" => $linconjunto->CODIGOS_CATWEB,
                    /* "PRECIO" => round($linconjunto->PVP, 2), */
                    /* "PRECIO_RECOMENDADO" => round($linconjunto->PVP_RECOMENDADO, 2),
                    "PRECIO_MINIMO" => round($linconjunto->PVP_MINIMO, 2), */
                    "PRECIO" => $linconjunto->PVP,
                    "PRECIO_RECOMENDADO" => $linconjunto->PVP_RECOMENDADO,
                    "PRECIO_MINIMO" => $linconjunto->PVP_MINIMO,
                    "IMPUESTO" => $linconjunto->IMPUESTO,
                    "DESCATALOGADO" => $linconjunto->DESCATALOGADO,
                    "STOCK" => $articulo->stockVendible(),
                    "EANS" => $linconjunto->eans(),
                    "REF_FABRICANTE" => utf8_encode($linconjunto->REFERENCIA_FABRICANTE),
                    /* "UDS_CAJA" => round($linconjunto->UNIDADESCAJA, 2),
                    "UDS_PACK" => round($linconjunto->UDS_PACK, 2),
                    "PESO" => round($linconjunto->PESO, 2), */
                    "UDS_CAJA" => $linconjunto->UNIDADESCAJA,
                    "UDS_PACK" => $linconjunto->UDS_PACK,
                    "PESO" => $linconjunto->PESO,
                    "MEDIDA" => $linconjunto->MEDIDA,
                    //"DISPONIBILIDAD"               => $articulo->disponibilidad()->DISPONIBILIDAD,
                    //"PROXIMO_STOCK_DISPONIBLE"     => ($proximoStock->STOCK_DISPONIBLE ?? 0),
                    "FECHA_PROXIMA_DISPONIBILIDAD" => $fechaProximaDisponibilidad,
                    "IMAGENES" => ConjuntosController::obtenerImagenes($linconjunto->ARTICULO, $imgsConjunto),
                    
                ];

                if (config('app.b2b'))
                {
                    $articulo = $linconjunto->articulo;
                    $proximoStock = $articulo->proximoStockDisponible();

                    $fechaProximaDisponibilidad = strtotime((!empty($proximoStock->FECHA_DISPONIBILIDAD)) ? $proximoStock->FECHA_DISPONIBILIDAD : $articulo->fechaProximaDisponibilidadProveedor());
                    $fechaProximaDisponibilidad = date("Y-m-d", $fechaProximaDisponibilidad);

                    //$lineaConjunto['DISPONIBILIDAD'] = $articulo->disponibilidad()->DISPONIBILIDAD;
                    //$lineaConjunto['PROXIMO_STOCK_DISPONIBLE'] = ($proximoStock->STOCK_DISPONIBLE ?? 0);
                    $lineaConjunto['FECHA_PROXIMA_DISPONIBILIDAD'] = $fechaProximaDisponibilidad;
                }

                array_push($lineasConjuntoArray, $lineaConjunto);
            }

            $arrConjunto['lineas'] = $lineasConjuntoArray;

            array_push($conj, $arrConjunto);
        }
        
        if($campos) $conj = ArrayHelper::filtrar($conj, $campos);

        $response['conjuntos'] = $conj;

        /* print_r($response);
        die; */

        return $response;
    }

    static function obtenerImagenesConjunto($conjunto)
    {
        $result = array();
    
        $DIRECTORIO_IMAGENES = Config::directorioImagenes(); 
    
        $carpetaImagenes = $DIRECTORIO_IMAGENES."conjunto_articulos\\".$conjunto."\\fotos\\";
        //die($carpetaImagenes);
    
        if(file_exists($carpetaImagenes))
        {
            $dirImagenes = scandir($carpetaImagenes, SCANDIR_SORT_DESCENDING);
    
            foreach ($dirImagenes as $img)
            {
                if ($img != '.' && $img != '..' && $img != 'Thumbs.db' && !is_dir($img))
                {
                    $extension = pathinfo($carpetaImagenes.$img, PATHINFO_EXTENSION);
    
                    if($extension == "jpg" || $extension == "png" || $extension == "jpeg")
                    {
                        //echo $carpetaImagenes.$img;
                        $filename = pathinfo($carpetaImagenes.$img, PATHINFO_FILENAME);
                        array_push($result, ConjuntosController::obtenerURLBase($conjunto).basename($img));   
                    }        
                }
            }
        }
    
        return $result;
    }

    static function obtenerImagenes($articulo, $imgsConjunto = [])
    {
        $result = array();
        //dd($imgsConjunto);

        if (!empty($imgsConjunto))
        {
            foreach ($imgsConjunto as $img)
            {
                if (ConjuntosController::extraerNumero($img) == $articulo) array_push($result, $img);
            }
        }
        else
        {
            $DIRECTORIO_IMAGENES = Config::directorioImagenes(); 

            $carpetaImagenes = $DIRECTORIO_IMAGENES."carpeta_articulos\\".$articulo."\\fotos\\";
        
            if(file_exists($carpetaImagenes))
            {
                $dirImagenes = scandir($carpetaImagenes, SCANDIR_SORT_DESCENDING);
        
                foreach ($dirImagenes as $img)
                {
                    if ($img != '.' && $img != '..' && $img != 'Thumbs.db' && !is_dir($img))
                    {
                        $extension = pathinfo($carpetaImagenes.$img, PATHINFO_EXTENSION);
        
                        if(in_array($extension, ["jpg", "png", "jpeg"]))
                        {
                            $filename = pathinfo($carpetaImagenes.$img, PATHINFO_FILENAME);
                            array_push($result, ConjuntosController::obtenerURLBase($articulo).basename($img));   
                        }        
                    }
                }
            }
        }
    
        return $result;
    }

    static function obtenerURLBase($id)
    {
        $result = config('app.web_url');
        $result = str_replace(':id_articulo', $id, $result);
        
        return $result;
    }

    static function extraerNumero($url) {
        // Patrón para buscar el número después de la última barra
        $patron = '/\/(\d+)-\d+\.\w+$/';
        
        // Realizar la búsqueda con expresiones regulares
        preg_match($patron, $url, $coincidencias);
        
        // Si se encontró una coincidencia, devolver el número
        if (isset($coincidencias[1])) {
            return $coincidencias[1];
        } else {
            // Si no se encontró ninguna coincidencia, devolver null o lanzar una excepción según tu preferencia
            return null;
            // o lanzar una excepción: throw new Exception('No se pudo encontrar ningún número en la URL proporcionada.');
        }
    }
}
