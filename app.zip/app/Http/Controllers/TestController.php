<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Ssheduardo\Redsys\Facades\Redsys;

class TestController extends Controller
{
    public function index()
    {
        //PRUEBA DEL SISTEMA DE PAGO
        try {
            $key  = config('redsys.key');
            $code = config('redsys.merchantcode');

            //Redsys::setAmount(rand(10, 600));
            Redsys::setAmount(1);
            Redsys::setOrder(time());
            Redsys::setMerchantcode($code); //Reemplazar por el código que proporciona el banco
            Redsys::setCurrency('978');
            Redsys::setTransactiontype('0');
            Redsys::setTerminal('1');

            Redsys::setCVV2('272');
            Redsys::setMerchantDirectPayment(true);
            Redsys::setMerchantData('4918500246738555');
            Redsys::setExpiryDate('2409');

            Redsys::setMethod('T'); //Solo pago con tarjeta, no mostramos iupay
            Redsys::setNotification(config('redsys.url_notification')); //Url de notificacion
            Redsys::setUrlOk(config('redsys.url_ok')); //Url OK
            Redsys::setUrlKo(config('redsys.url_ko')); //Url KO
            Redsys::setVersion('HMAC_SHA256_V1');
            Redsys::setTradeName('Tienda S.L');
            Redsys::setTitular('Pablo Navarro');
            Redsys::setProductDescription('Compras varias');
            Redsys::setEnviroment(config('redsys.enviroment')); //Entorno test

            $signature = Redsys::generateMerchantSignature($key);
            Redsys::setMerchantSignature($signature);

            //print_r(Redsys::getParameters());
            //$form = Redsys::createForm();
            //$form = Redsys::executeRedirection(true);
            $result = json_decode(Redsys::send());

            $datos = Redsys::getMerchantParameters($result->Ds_MerchantParameters);

            print_r($datos);

        } catch (Exception $e) {
            echo $e->getMessage();
        }
        //return view('redsys', compact('form'));
    }
}
