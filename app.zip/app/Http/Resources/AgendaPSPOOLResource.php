<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class AgendaPSPOOLResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'CODIGO' =>$this->CODIGO,
            'FECHA' => $this->FECHA,
            'HORA' => $this->HORA,
            'REALIZADO' => $this->REALIZADO,
            'ALARMA' => $this->ALARMA,
            'TITULO' => $this->TITULO,
            'LUGAR'  => $this->LUGAR,
            'USUARIO_ORIGEN'  => $this->usuarioOrigen()->NOMBRE,
            'USUARIO'  => $this->usuario->NOMBRE,
            'ESTADO'  => $this->estado->DESCRIPCION
        ];
    }
}
