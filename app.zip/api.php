<?php
//rutas PSPOOL api
require "pspool_api.php";
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AlbaranController;
use App\Http\Controllers\ArticulosController;
use App\Http\Controllers\CatalogoController;
use App\Http\Controllers\CategoriasController;
use App\Http\Controllers\ClientesController;
use App\Http\Controllers\ConjuntosController;
use App\Http\Controllers\PedidoController;
use App\Http\Controllers\TarifaController;
use App\Http\Controllers\TestController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

/* Route::get('/categorias', function (Request $request) {
    return "Llamando a categorias ";
}); */
Route::resource('categorias', CategoriasController::class)
     ->only(['index']);

Route::resource('/conjuntos', ConjuntosController::class)
     ->only(['index']);

Route::resource('/articulos', ArticulosController::class)
     ->only(['index']);

if (config('app.b2b') && config('app.tipo_b2') == "B2S")
{
     if (config('app.llamada_clientes')) Route::resource('/clientes', ClientesController::class)->only(['index']);
     if (config('app.llamada_tarifas'))  Route::resource('/tarifas',  TarifaController::class)  ->only(['index']);
}

Route::/* middleware('horario')-> */get('/catalogo', [CatalogoController::class, 'catalogo'])
     ->name('catalogo');

Route::get('/consultarDisponibilidad/{codigo}', [CatalogoController::class, 'consultarDisponibilidad']);
Route::get('/consultarDisponibilidad', function(){
    return "Falta el parametro \"CODIGO\" por GET";
});

Route::get('/obtenerCatalogoURL', [CatalogoController::class, 'catalogoConURL']);

Route::get('/test', [TestController::class, 'index']);

if (config('app.llamada_pedidos'))
{
     Route::get('/pedido', [PedidoController::class,  'index']);
     Route::post('/pedido', [PedidoController::class,  'create']);
     Route::get('/pedido/{codigo}', [PedidoController::class, 'show']);
     Route::delete('/pedido/{codigo}', [PedidoController::class, 'delete']);
}

//dd(env('LLAMADA_ALBARANES'));

if (config('app.llamada_albaranes')) Route::post('/albaran', [AlbaranController::class, 'create']);

Route::get('/test-env', function () {

     /* $environment = App::environment();

     return print_r($environment, true); */

     return print_r($_ENV, true);
     /* return [
         'llamada_albaranes' => env('LLAMADA_ALBARANES', 'Variable no encontrada'),
         'llamada_pedidos'   => env('LLAMADA_PEDIDOS', 'Variable no encontrada'),
     ]; */
 });


 //PSPOOL