<?php

use App\Http\Controllers\PSPOOL\AgendaController;
use App\Http\Controllers\PSPOOL\ClientesController;
use App\Http\Controllers\PSPOOL\ExpedientesController;
use App\Http\Controllers\PSPOOL\PedidosController;
use App\Http\Controllers\PSPOOL\PresupuestosController;
use App\Http\Controllers\PSPOOL\ProvinciasController;
use App\Http\Controllers\PSPOOL\UsuariosController;
use App\Http\Controllers\PSPOOL\VendedoresController;
use App\Http\Controllers\PSPOOL\VisitasController;
use App\Http\Controllers\PSPOOL\ContactosController;
use App\Http\Controllers\PSPOOL\TiquetsController;
use App\Http\Controllers\PSPOOL\IncidenciasController;
use App\Http\Controllers\PSPOOL\VentasController;
use App\Http\Controllers\PSPOOL\DireccionesController;
use App\Http\Controllers\PSPOOL\SeccionesController;
use App\Http\Controllers\PSPOOL\GruposController;
use App\Http\Controllers\PSPOOL\ProyectosController;
use App\Http\Controllers\PSPOOL\LoginController;
use App\Http\Controllers\PSPOOL\ArticulosController;
use App\Http\Controllers\PSPOOL\GastosController;
use App\Http\Controllers\PSPOOL\ListadosController;
use App\Http\Controllers\PSPOOL\IncentivosController;
use App\Http\Controllers\PSPOOL\RecursosHumanosController;
use App\Http\Controllers\PSPOOL\ArchivosController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


//LOGIN
Route::get('loginEmpleados', [LoginController::class, 'loginEmpleados']);
Route::get('loginVendedores', [LoginController::class, 'loginVendedores']);

//AGENDA
Route::get("obtenerAgenda", [AgendaController::class, 'obtenerPorExpediente']);
Route::get("obtenerCodigoPorExpediente", [AgendaController::class, 'obtenerCodigoPorExpediente']);
Route::get('obtenerCaracterAgenda', [AgendaController::class, 'obtenerCaracteres']);
Route::get('obtenerEstadoAgenda', [AgendaController::class, 'obtenerEstado']);
Route::get('obtenerExpedienteAsociadoAgenda', [AgendaController::class, 'obtenerExpedientePorCodigoAgenda']);
Route::post('actualizarOCrearAgenda', [AgendaController::class, 'actualizarOCrear']);
Route::get('obtenerAgendaPorCodigo', [AgendaController::class, 'obtenerPorCodigo']);
Route::get('obtenerNuevoCodigoAgenda', [AgendaController::class, 'obtenerSiguienteCodigo']);
Route::delete('borrarAgenda', [AgendaController::class, 'borrar']);
Route::get('obtenerEstadosAgenda', [AgendaController::class, 'obtenerEstados']);
Route::get('obtenerEstadosSeccionAgendasEstados', [AgendaController::class, 'obtenerEstadosSeccionAgendasEstados']);
Route::get('obtenerEstadoAgendaPorCodigoEstado', [AgendaController::class, 'obtenerEstadoAgendaPorCodigoEstado']);
Route::put('actualizarEstadoAgenda', [AgendaController::class, 'actualizarEstado']);
Route::post('actualizarCrearEstadoRegistro', [AgendaController::class, 'actualizarCrearEstadoRegistro']);
Route::get('obtenerEstadosDetalleAgenda', [AgendaController::class, 'obtenerEstadosDetalle']);
Route::get('buscarAgendas', [AgendaController::class, 'buscarAgendas']);
Route::get('contarAlarmasRecordatorios', [AgendaController::class, 'contarAlarmasRecordatorios']);


//VENDEDORES
Route::get('obtenerVendedorPorExpediente', [VendedoresController::class, 'obtenerPorExpediente']);
Route::get('obtenerVendedoresTerminalComercial', [VendedoresController::class, 'obtenerComercialesUsanTerminal']);

//EXPEDIENTES
Route::get('obtenerExpediente', [ExpedientesController::class, 'obtenerPorCodigo']);
Route::get('obtenerEstadosExpediente', [ExpedientesController::class, 'obtenerEstados']);
Route::post('asignarClienteExpediente', [ExpedientesController::class, 'asignarCliente']);
Route::post('eliminarClienteExpediente', [ExpedientesController::class, 'borrarCliente']);
Route::get('obtenerContactosExpediente', [ExpedientesController::class, 'obtenerContactos']);
Route::get('obtenerNuevoId', [ExpedientesController::class, 'obtenerSiguienteId']);
Route::post('actualizarCrearExpediente', [ExpedientesController::class, 'actualizarOCrear']);
Route::get('obtenerExpedienteBasico', [ExpedientesController::class, 'obtenerPorCodigoReducido']);
Route::get('actualizarOAsignarCliente', [ExpedientesController::class, 'actualizarOAsignarCliente']);
Route::get('obtenerResultadosSelectExpedientes', [ExpedientesController::class, 'obtenerResultadosSelectExpedientes']);
Route::get('buscarExpedientes', [ExpedientesController::class, 'buscarExpedientes']);

//CLIENTES
Route::get('obtenerClientePorExpediente', [ClientesController::class, 'obtenerPorExpediente']);
Route::get('filtrarPorNombre', [ClientesController::class, 'filtrarPorNombre']);
Route::get('obtenerDireccionesCliente', [ClientesController::class, 'obtenerDirecciones']);
Route::get('obtenerClientePorCodigo', [ClientesController::class, 'obtenerPorCodigo']);
Route::get('obtenerCorreosRelacionadosCliente', [ClientesController::class, 'obtenerCorreosRelacionados']);
Route::get('calcularRiesgo', [ClientesController::class, 'calcularRiesgo']);
Route::post('crearActualizarCliente', [ClientesController::class, 'actualizarOCrear']);


//Ficha clientes
Route::get('obtenerTiposCliente', [ClientesController::class, 'obtenerTipos']);
Route::get('obtenerCategoriasCliente', [ClientesController::class, 'obtenerCategorias']);
Route::get('obtenerTemasInteresClienteChecks', [ClientesController::class, 'obtenerTemasInteres']);
Route::get('obtenerDetalleFichaCliente', [ClientesController::class, 'obtenerDetalleFichaCliente']);
Route::get('obtenerDetalleRiesgoCliente', [ClientesController::class, 'obtenerDetalleRiesgoCliente']);
Route::get('obtenerClienteContratoWeb', [ClientesController::class, 'obtenerClienteContratoWeb']);
Route::get('obtenerContactoPorDefecto', [ClientesController::class, 'obtenerContactoPorDefecto']);
Route::get('obtenerTemasInteresCliente', [ClientesController::class, 'obtenerTemasInteresCliente']);
Route::get('obtenerHorariosCliente', [ClientesController::class, 'obtenerHorarios']);
Route::get('obtenerContactosCliente', [ClientesController::class, 'obtenerContactos']);
Route::get('borrarHorarioClientes', [ClientesController::class, 'borrarHorario']);
Route::post('crearActualizarHorarioCliente', [ClientesController::class, 'crearActualizarHorario']);
Route::get('obtenerHorasHorarioCliente', [ClientesController::class, 'obtenerHorasHorario']);
Route::delete('borrarHorasHorarioCliente', [ClientesController::class, 'borrarHorasHorario']);
Route::post('grabarHorasHorarioCliente', [ClientesController::class, 'grabarHorasHorario']);
Route::get('obtenerInfoDatosFiscalesClientes', [ClientesController::class, 'obtenerInfoDatosFiscales']);


//CONTACTOS
Route::get('obtenerContactosPorCliente', [ContactosController::class, 'obtenerContactosPorCliente']);
Route::get('obtenerContactosPorExpediente', [ContactosController::class, 'obtenerContactosPorExpediente']);
Route::post('crearActualizarExpedientesContactos', [ContactosController::class, 'crearActualizarExpedientesContactos']);
Route::delete('borrarClientesContactos', [ContactosController::class, 'borrarClientesContactos']);
Route::get('obtenerDetalleContacto', [ContactosController::class, 'obtenerDetalleContacto']);
Route::post('grabarContactoConOSinCliente', [ContactosController::class, 'grabarContactoConOSinCliente']);
Route::post('crearActualizarClientesContactos', [ContactosController::class, 'crearActualizarClientesContactos']);
Route::get('obtenerContactosFichaCliente', [ContactosController::class, 'obtenerContactosFichaClientes']);
Route::get('obtenerLlamadasFichaClientes', [ContactosController::class, 'obtenerLlamadasFichaClientes']);

//PRESUPUESTOS
Route::get('obtenerPresupuestosExpediente', [PresupuestosController::class, 'obtenerPorExpediente']);
Route::get('obtenerPresupuestosFichaCliente', [PresupuestosController::class, 'obtenerPresupuestosFichaCliente']);
Route::get('obtenerSelectEstadosPresupuesto', [PresupuestosController::class, 'obtenerSelectEstadosPresupuesto']);

//SOLICITUDES PRESUPUESTOS
Route::get('obtenerSolicitudesPresupuestosFichaCliente', [PresupuestosController::class, 'obtenerSolicitudesFichaCliente']);
Route::get('obtenerOpcionesCaracterSolicitudPresupuesto', [PresupuestosController::class, 'obtenerOpcionesCaracterSolicitud']);
Route::get('obtenerOpcionesCategoriaSolicitudPresupuesto', [PresupuestosController::class, 'obtenerOpcionesCategoriaSolicitud']);
Route::get('obtenerSolicitudPresupuestoPorCodigo', [PresupuestosController::class, 'obtenerSolicitudPorCodigo']);
Route::get('obtenerDescripcionCaracterSolicitudPresupuesto', [PresupuestosController::class, 'obtenerDescripcionCaracterSolicitud']);
Route::get('obtenerSiguienteCodigoSolicitudPresupuesto', [PresupuestosController::class, 'obtenerSiguienteCodigoSolicitud']);
Route::put('actualizarSolicitudPresupuesto', [PresupuestosController::class, 'actualizarSolicitud']);
Route::post('crearSolicitudPresupuesto', [PresupuestosController::class, 'crearSolicitud']);
Route::delete('borrarSolicitudPresupuesto', [PresupuestosController::class, 'borrarSolicitud']);


//informe presupuesto
Route::get('obtenerInformacionPresupuesto', [PresupuestosController::class, 'obtenerInformacionPresupuesto']);
Route::get('obtenerTrazaPresupuestosClientes', [PresupuestosController::class, 'obtenerTrazaPresupuestosClientes']);
Route::get('obtenerArticulosPresupuesto', [PresupuestosController::class, 'obtenerArticulosPresupuesto']);
Route::post('actualizarEstadoPresupuesto', [PresupuestosController::class, 'actualizarEstadoPresupuesto']);
Route::get('cargarDetalleEstadoPresupuesto', [PresupuestosController::class, 'cargarDetalleEstadoPresupuesto']);

//PEDIDOS
Route::get('obtenerPedidosExpediente', [PedidosController::class, 'obtenerPorExpediente']);
Route::get('obtenerPedidosFichaCliente', [PedidosController::class, 'obtenerFichaClientes']);
Route::get('obtenerInformacionInformePedido', [PedidosController::class, 'obtenerInformacionInformePedido']);
Route::get('obtenerLineasPedidoInforme', [PedidosController::class, 'obtenerLineasPedidoInforme']);
Route::get('obtenerSelectEstadosPedido', [PedidosController::class, 'obtenerSelectEstadosPedido']);

//USUARIOS
Route::get('obtenerUsuariosCodigoNombre', [UsuariosController::class,  'obtenerCodigoNombre']);
Route::get('obtenerUsuariosVendedores', [UsuariosController::class, 'obtenerUsuariosVendedores']);


//VISITAS
Route::post('crearVisitaComercialAgenda', [VisitasController::class, 'crearVisitaComercialAgenda']);
Route::post('actualizarExpedienteVisita', [VisitasController::class, 'actualizarExpedienteVisita']);
Route::get('obtenerVisitasFichaCliente', [VisitasController::class, 'obtenerVisitasFichaCliente']);
Route::get('obtenerAccionesVisitas', [VisitasController::class, 'obtenerAcciones']);
Route::get('obtenerAsuntosAccionesVisitas', [VisitasController::class, 'obtenerAsuntosAcciones']);
Route::get('obtenerMotivosVisitas', [VisitasController::class, 'obtenerMotivos']);
Route::get('obtenerVisitasPorCliente', [VisitasController::class, 'obtenerVisitasPorCliente']);
Route::get('obtenerVisitasPorExpediente', [VisitasController::class, 'obtenerVisitasPorExpediente']);
Route::post('actualizarVisitaComercial', [VisitasController::class, 'actualizarVisitaComercial']);
Route::post('crearVisitaComercial', [VisitasController::class, 'crearVisitaComercial']);
Route::get('obtenerNuevoCodigoVisita', [VisitasController::class, 'obtenerNuevoCodigo']);
Route::post('asignarAccionesVisita', [VisitasController::class, 'asignarAccionesVisita']);
Route::post('asignarAsuntosVisita', [VisitasController::class, 'asignarAsuntosVisita']);
Route::delete('borrarVisita', [VisitasController::class, 'borrarVisita']);
Route::get('obtenerDetalleVisita', [VisitasController::class, 'obtenerDetalleVisita']);
Route::get('obtenerAccionesVisitaPorCodigo', [VisitasController::class, 'obtenerAccionesVisitaPorCodigo']);
Route::get('obtenerAsuntosVisitaPorCodigo', [VisitasController::class, 'obtenerAsuntosVisitaPorCodigo']);

//TIQUETS
Route::get('obtenerAlbaranesFichaClientes', [TiquetsController::class, 'obtenerFichaClientes']);
Route::get('obtenerLineasTiquetPorPedido', [TiquetsController::class, 'obtenerLineasTiquetPorPedido']);
Route::get('obtenerInformacionAlbaran', [TiquetsController::class, 'obtenerInformacionAlbaran']);
Route::get('obtenerArticulosAlbaran', [TiquetsController::class, 'obtenerArticulosAlbaran']);


//INCIDENCIAS
Route::get('obtenerIncidenciasPorCliente', [IncidenciasController::class, 'obtenerPorCliente']);
Route::get('obtenerIncidenciasPorExpediente', [IncidenciasController::class, 'obtenerPorExpediente']);
Route::get('obtenerIncidenciaPorClienteYLinea', [IncidenciasController::class, 'obtenerPorClienteYLinea']);
Route::put('actualizarIncidenciaCliente', [IncidenciasController::class, 'actualizarIncidenciaCliente']);
Route::get('obtenerNuevaLineaIncidencia', [IncidenciasController::class, 'obtenerNuevaLinea']);
Route::post('crearIncidenciaCliente', [IncidenciasController::class, 'crearIncidenciaCliente']);
Route::get('obtenerIncidenciaPorExpedienteYLinea', [IncidenciasController::class, 'obtenerPorExpedienteYLinea']);
Route::delete('borrarIncidencia', [IncidenciasController::class, 'borrarIncidencia']);
Route::get('obtenerDetalleIncidenciaCliente', [IncidenciasController::class, 'obtenerDetalleIncidenciaCliente']);
Route::get('obtenerDetalleIncidenciaExpediente', [IncidenciasController::class, 'obtenerDetalleIncidenciaExpediente']);
Route::get('obtenerSelectEstadoIncidencia', [IncidenciasController::class, 'obtenerSelectEstado']);
Route::get('buscarIncidencias', [IncidenciasController::class, 'buscarIncidencias']);

//VENTAS
Route::get('obtenerVentasSgfa', [VentasController::class, 'obtenerVentasSgfa']);
Route::get('obtenerArticulosVendidos', [VentasController::class, 'obtenerArticulosVendidos']);

//DIRECCIONES
Route::get('obtenerDireccionesPorClienteExpediente', [DireccionesController::class, 'obtenerDireccionesPorClienteExpediente']);
Route::post('crearActualizarDireccion', [DireccionesController::class, 'crearActualizarDireccion']);
Route::post('crearActualizarDireccionExpediente', [DireccionesController::class, 'crearActualizarDireccionExpediente']);
Route::delete('borrarDireccionCliente', [DireccionesController::class, 'borrarDireccionCliente']);
Route::get('obtenerDetalleDireccionCliente', [DireccionesController::class, 'obtenerDetalleDireccionCliente']);
Route::get('obtenerDireccionPorClienteYLinea', [DireccionesController::class, 'obtenerPorClienteYLinea']);


//SECCIONES
Route::get('obtenerSecciones', [SeccionesController::class, 'obtenerSecciones']);
Route::get('obtenerGruposPorSeccion', [GruposController::class, 'obtenerGruposPorSeccion']);


//PROYECTOS
Route::get('obtenerOpcionesProyectoSolicitudPresupuesto', [ProyectosController::class, 'obtenerOpcionesSolicitudPresupuesto']);


//ARTICULOS
Route::get('buscarArticulos', [ArticulosController::class, 'buscarArticulos']);
Route::get('obtenerDisponibilidadArticulo', [ArticulosController::class, 'obtenerDisponibilidad']);
Route::get('obtenerDetalleArticulo', [ArticulosController::class, 'obtenerDetalle']);
Route::get('obtenerCategoriasPorSelectSGF', [ArticulosController::class, 'obtenerCategoriasPorSelectSGF']);


//GASTOS
Route::get('obtenerTiposGasto', [GastosController::class, 'obtenerTiposGasto']);
Route::get('obtenerTiposMediosCobro', [GastosController::class, 'obtenerTiposMediosCobro']);
Route::get('buscarGastos', [GastosController::class, 'buscarGastos']);
Route::get('obtenerDetalleGasto', [GastosController::class, 'obtenerDetalle']);
Route::post('actualizarOCrearGasto', [GastosController::class, 'actualizarOCrear']);

//LISTADOS
Route::get('obtenerVentasClientesProvincias', [ListadosController::class, 'obtenerVentasClientesProvincias']);
Route::get('obtenerVentasSecciones', [ListadosController::class, 'obtenerVentasSecciones']);
Route::get('obtenerNuevosClientes', [ListadosController::class, 'obtenerNuevosClientes']);
Route::get('obtenerVentasProvincias', [ListadosController::class, 'obtenerVentasProvincias']);
Route::get('obtenerRankingVentas', [ListadosController::class, 'obtenerRankingVentas']);
Route::get('obtenerRankingVisitas', [ListadosController::class, 'obtenerRankingVisitas']);
Route::get('obtenerControlVisitas', [ListadosController::class, 'obtenerControlVisitas']);
Route::get('obtenerControlVisitasExtendido', [ListadosController::class, 'obtenerControlVisitasExtendido']);
Route::get('obtenerFacturasClientes', [ListadosController::class, 'obtenerFacturasClientes']);
Route::get('obtenerListadoClientes', [ListadosController::class, 'obtenerListadoClientes']);
Route::get('obtenerListadoVentasClientesArticulos', [ListadosController::class, 'obtenerListadoVentasClientesArticulos']);
Route::get('obtenerVentasComparativaAnual', [ListadosController::class, 'obtenerVentasComparativaAnual']);
Route::get('obtenerVentasProvinciaAnual', [ListadosController::class, 'obtenerVentasProvinciaAnual']);
Route::get('obtenerVentasClientesAnual', [ListadosController::class, 'obtenerVentasClientesAnual']);

//INCENTIVOS Y OBJETIVOS
Route::get('comprobarAutorizacionAccesoIncentivo', [IncentivosController::class, 'comprobarAutorizacionAccesoIncentivo']);
Route::get('obtenerListadoObjetivos', [IncentivosController::class, 'obtenerListadoObjetivos']);
Route::get('obtenerListadoIncentivos', [IncentivosController::class, 'obtenerListadoIncentivos']);


//RECURSOS HUMANOS
Route::get('obtenerEntradasSalidas', [RecursosHumanosController::class, 'obtenerEntradasSalidas']);
Route::get('obtenerEstadoActual', [RecursosHumanosController::class, 'obtenerEstadoActual']);
Route::get('insertarEstadoFichar', [RecursosHumanosController::class, 'insertarEstado']);
Route::get('comprobarUsuario', [RecursosHumanosController::class, 'comprobarUsuario']);
Route::get('mandarAlarmaEstablecida', [RecursosHumanosController::class, 'mandarAlarmaEstablecida']);
Route::get('mandarErrorAlarma', [RecursosHumanosController::class, 'mandarErrorAlarma']);
Route::get('obtenerAlarmasEmpleado', [RecursosHumanosController::class, 'obtenerAlarmas']);
Route::get('obtenerChivatos', [RecursosHumanosCOntroller::class, 'obtenerChivatos']);
Route::get('obtenerContadoresEmpleados', [RecursosHumanosController::class, 'obtenerContadores']);
Route::get('buscarProyectos', [RecursosHumanosController::class, 'buscarProyectos']);
Route::get('obtenerTicadoHoy20190510', [RecursosHumanosController::class, 'obtenerTicadoHoy20190510']);
Route::get('obtenerTicadoHoy20190513', [RecursosHumanosController::class, 'obtenerTicadoHoy20190513']);
Route::get('obtenerTicadoHoy', [RecursosHumanosController::class, 'obtenerTicadoHoy']);
Route::get('obtenerUltimaVersion', [RecursosHumanosController::class, 'obtenerUltimaVersion']);


//PROVINCIAS y localizaciones
Route::get('obtenerProvincias', [ProvinciasController::class, 'obtenerProvincias']);
Route::get('obtenerPoblacionesCP', [ProvinciasController::class, 'buscarPorCP']);
Route::get('obtenerPoblaciones', [ProvinciasController::class, 'obtenerPoblaciones']);
Route::get('buscarPoblacion', [ProvinciasController::class, 'buscarPoblacion']);
Route::get('buscarProvincia', [ProvinciasController::class, 'buscarProvincia']);
Route::get('buscarPais', [ProvinciasController::class, 'buscarPais']);


//GESTIÓN ARCHIVOS
Route::post('subirArchivo', [ArchivosController::class, 'guardarArchivo']);
Route::get('obtenerArchivos', [ArchivosController::class, 'obtenerArchivos']);
Route::get('obtenerArchivo', [ArchivosController::class, 'obtenerArchivo']);
Route::get('obtenerImagenesDirectorio', [ArchivosController::class, 'obtenerImagenesDirectorio']);
